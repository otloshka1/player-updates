// Симуляция торговли: лимитки с очередью, маркеты по книге, позиция, PnL, комиссии.
'use strict';

class Sim {
  constructor(player, opts) {
    this.p = player;
    this.makerFee = opts.makerFee; // доля, напр. 0.0002
    this.takerFee = opts.takerFee;
    this.orders = [];      // {id, side, idx, qty, filled, ahead}
    this.stops = [];       // {id, side, idx, qty} — стопы: B при росте до уровня, S при падении
    this.pendings = [];    // {id, side, idx, qty} — отложки: маркет при касании уровня с любой стороны
    this._lastTradeIdx = null;
    this.fills = [];       // {t, side, price, qty, fee, taker, note}
    this.pos = 0;          // знак: + лонг, - шорт
    this.avg = 0;
    this.trades = [];      // закрытые сделки: {t, side, pnl, pct}
    this._trip = null;     // текущая открытая сделка
    this.pingMs = 0;       // задержка входа в позицию, мс сим-времени (0 = мгновенно)
    this._inflight = [];   // отправленные маркет-ордера, ждущие исполнения
    this.realized = 0;
    this.feesPaid = 0;
    this.wins = 0; this.losses = 0;
    this._oid = 1;
    this.log = [];
  }

  get lastPrice() { return this.p.lastPrice; }

  unrealized() {
    if (!this.pos || !this.lastPrice) return 0;
    return (this.lastPrice - this.avg) * this.pos;
  }

  /** Лимитный ордер кликом по стакану. Кроссующий — исполняется как маркет до своей цены. */
  placeLimit(side, idx, qty) {
    const b = this.p.book;
    if (qty <= 0) return;
    if (side === 'B' && b.bestAsk !== -1 && idx >= b.bestAsk) {
      this.market('B', qty, idx); return;
    }
    if (side === 'S' && b.bestBid !== -1 && idx <= b.bestBid) {
      this.market('S', qty, idx); return;
    }
    // очередь: впереди нас весь текущий объём уровня (в записи — реальный)
    let ahead = b.real ? b.qtyAt(side === 'B' ? 'B' : 'S', idx) : qty; // hist: консервативно ~свой объём
    this.orders.push({ id: this._oid++, side, idx, qty, filled: 0, ahead });
    this._note(`лимит ${side === 'B' ? 'BUY' : 'SELL'} ${qty} @ ${this._fmt(idx)}`);
  }

  /** Стоп-заявка: B — триггер при росте цены до уровня, S — при падении. */
  placeStop(side, idx, qty) {
    if (qty <= 0) return;
    this.stops.push({ id: this._oid++, side, idx, qty });
    this._note(`стоп ${side === 'B' ? 'BUY' : 'SELL'} ${qty} @ ${this._fmt(idx)}`);
  }

  /** Отложенная заявка: активируется маркетом, когда цена касается уровня. */
  placePending(side, idx, qty) {
    if (qty <= 0) return;
    this.pendings.push({ id: this._oid++, side, idx, qty });
    this._note(`отложка ${side === 'B' ? 'BUY' : 'SELL'} ${qty} @ ${this._fmt(idx)}`);
  }

  /** Стоп-лосс на весь объём позиции. Всегда один: новый заменяет старый. */
  placeSL(idx) {
    if (this.pos === 0) { this._note('стоп-лосс: нет позиции'); return; }
    if (this.stops.length) {
      this.stops.length = 0;
      this._note('стоп-лосс перенесён');
    }
    this.placeStop(this.pos > 0 ? 'S' : 'B', idx, Math.abs(this.pos));
  }

  /** Тейк-профит на весь объём позиции: лимитная заявка на выход. */
  placeTP(idx) {
    if (this.pos === 0) { this._note('тейк-профит: нет позиции'); return; }
    this.placeLimit(this.pos > 0 ? 'S' : 'B', idx, Math.abs(this.pos));
  }

  /** Одна клавиша на выход: клик в сторону профита — тейк, в сторону убытка — стоп. */
  placeExit(idx) {
    if (this.pos === 0) { this._note('выход: нет позиции'); return; }
    const cur = this.p.book.idx(this.lastPrice);
    const profitSide = this.pos > 0 ? idx > cur : idx < cur;
    if (profitSide) this.placeTP(idx);
    else this.placeSL(idx);
  }

  cancel(id) {
    const i = this.orders.findIndex(o => o.id === id);
    if (i >= 0) {
      const o = this.orders[i];
      this.orders.splice(i, 1);
      this._note(`отмена ${o.side === 'B' ? 'BUY' : 'SELL'} @ ${this._fmt(o.idx)}`);
      return;
    }
    const j = this.stops.findIndex(s => s.id === id);
    if (j >= 0) {
      const s = this.stops[j];
      this.stops.splice(j, 1);
      this._note(`отмена стопа ${s.side === 'B' ? 'BUY' : 'SELL'} @ ${this._fmt(s.idx)}`);
      return;
    }
    const k = this.pendings.findIndex(o => o.id === id);
    if (k >= 0) {
      const o = this.pendings[k];
      this.pendings.splice(k, 1);
      this._note(`отмена отложки ${o.side === 'B' ? 'BUY' : 'SELL'} @ ${this._fmt(o.idx)}`);
    }
  }
  cancelAt(idx) {
    for (const o of this.orders.filter(o => o.idx === idx)) this.cancel(o.id);
    for (const s of this.stops.filter(s => s.idx === idx)) this.cancel(s.id);
    for (const o of this.pendings.filter(o => o.idx === idx)) this.cancel(o.id);
  }
  cancelAll() {
    while (this.orders.length) this.cancel(this.orders[0].id);
    while (this.stops.length) this.cancel(this.stops[0].id);
    while (this.pendings.length) this.cancel(this.pendings[0].id);
    this._inflight.length = 0;
  }

  /** Маркет-ордер: в записи идём по книге, в истории — по оценке L1. limitIdx — не хуже этой цены. */
  market(side, qty, limitIdx = null) {
    const b = this.p.book;
    if (qty <= 0 || !this.lastPrice) return;
    let remaining = qty, costTicks = 0, filledQty = 0;
    if (b.real) {
      const map = side === 'B' ? b.asks : b.bids;
      let i = side === 'B' ? b.bestAsk : b.bestBid;
      if (i === -1) return;
      let guard = 5000;
      while (remaining > 1e-12 && guard-- > 0) {
        if (limitIdx !== null && (side === 'B' ? i > limitIdx : i < limitIdx)) break;
        const avail = map.get(i) || 0;
        if (avail > 0) {
          const take = Math.min(avail, remaining);
          costTicks += take * i; filledQty += take; remaining -= take;
        }
        i += side === 'B' ? 1 : -1;
        if (i < 0) break;
      }
    } else {
      const i = side === 'B' ? b.bestAsk : b.bestBid;
      if (i === -1) return;
      costTicks = qty * i; filledQty = qty; remaining = 0;
    }
    if (filledQty <= 1e-12) return;
    const price = (costTicks / filledQty) * this.p.tick;
    this._fill(side, price, filledQty, true, 'маркет');
  }

  /** Маркет с пингом: вход срабатывает через pingMs сим-времени. */
  marketDelayed(side, qty) {
    if (qty <= 0) return;
    if (this.pingMs <= 0) { this.market(side, qty); return; }
    this._inflight.push({ side, qty, at: this.p.simTime + this.pingMs });
    this._note(`ордер отправлен ${side === 'B' ? 'BUY' : 'SELL'} ${qty} (пинг ${this.pingMs} мс)`);
  }

  flatten() {
    this.cancelAll();
    this._inflight.length = 0;
    if (this.pos > 0) this.market('S', this.pos);
    else if (this.pos < 0) this.market('B', -this.pos);
  }

  /** Вызывается движком на каждый принт ленты. */
  onTrade(ev) {
    const idx = this.p.book.idx(ev.p);
    const prevIdx = this._lastTradeIdx;
    this._lastTradeIdx = idx;
    // отправленные с пингом ордера: исполняем маркетом, когда пинг истёк
    if (this._inflight.length) {
      const ready = this._inflight.filter((o) => this.p.simTime >= o.at);
      if (ready.length) {
        this._inflight = this._inflight.filter((o) => this.p.simTime < o.at);
        for (const o of ready) this.market(o.side, o.qty);
      }
    }
    if (!this.orders.length && !this.stops.length && !this.pendings.length) return;
    // отложки: цена коснулась уровня (с любой стороны) — исполняем маркетом
    if (this.pendings.length && prevIdx !== null) {
      const lo = Math.min(prevIdx, idx), hi = Math.max(prevIdx, idx);
      const fired = this.pendings.filter(o => o.idx >= lo && o.idx <= hi);
      if (fired.length) {
        this.pendings = this.pendings.filter(o => !fired.includes(o));
        for (const o of fired) {
          this._note(`сработала отложка ${o.side === 'B' ? 'BUY' : 'SELL'} @ ${this._fmt(o.idx)}`);
          this.market(o.side, o.qty);
        }
      }
    }
    // стопы: цена дошла до уровня — исполняем маркетом
    if (this.stops.length) {
      const fired = this.stops.filter(s =>
        (s.side === 'B' && idx >= s.idx) || (s.side === 'S' && idx <= s.idx));
      if (fired.length) {
        this.stops = this.stops.filter(s => !fired.includes(s));
        for (const s of fired) {
          this._note(`сработал стоп ${s.side === 'B' ? 'BUY' : 'SELL'} @ ${this._fmt(s.idx)}`);
          this.market(s.side, s.qty);
        }
      }
    }
    if (!this.orders.length) return;
    const done = [];
    for (const o of this.orders) {
      if (o.side === 'B') {
        if (ev.m !== 1) continue;            // биды снимают только агрессивные продажи
        if (idx < o.idx) {                   // пробили насквозь — полный филл
          this._fillOrder(o, o.qty - o.filled); done.push(o.id);
        } else if (idx === o.idx) {
          let q = ev.q;
          if (o.ahead > 0) { const eat = Math.min(o.ahead, q); o.ahead -= eat; q -= eat; }
          if (q > 0) {
            const take = Math.min(q, o.qty - o.filled);
            this._fillOrder(o, take);
            if (o.filled >= o.qty - 1e-12) done.push(o.id);
          }
        }
      } else {
        if (ev.m !== 0) continue;            // аски снимают только агрессивные покупки
        if (idx > o.idx) {
          this._fillOrder(o, o.qty - o.filled); done.push(o.id);
        } else if (idx === o.idx) {
          let q = ev.q;
          if (o.ahead > 0) { const eat = Math.min(o.ahead, q); o.ahead -= eat; q -= eat; }
          if (q > 0) {
            const take = Math.min(q, o.qty - o.filled);
            this._fillOrder(o, take);
            if (o.filled >= o.qty - 1e-12) done.push(o.id);
          }
        }
      }
    }
    if (done.length) this.orders = this.orders.filter(o => !done.includes(o.id));
  }

  /** На обновление книги: очередь впереди не может быть больше остатка уровня. */
  onBookChange() {
    const b = this.p.book;
    if (!b.real) return;
    for (const o of this.orders) {
      const lvl = b.qtyAt(o.side, o.idx);
      if (lvl < o.ahead) o.ahead = lvl;
    }
  }

  _fillOrder(o, qty) {
    o.filled += qty;
    this._fill(o.side, o.idx * this.p.tick, qty, false, 'лимит');
  }

  _fill(side, price, qty, taker, note) {
    const realizedBefore = this.realized; // для PnL сделки (включая комиссии)
    const fee = price * qty * (taker ? this.takerFee : this.makerFee);
    this.feesPaid += fee;
    this.realized -= fee;
    const signed = side === 'B' ? qty : -qty;
    const before = this.pos;
    const increased = Math.abs(before + signed) > Math.abs(before);
    if (before === 0 || Math.sign(before) === Math.sign(signed)) {
      this.avg = (Math.abs(before) * this.avg + qty * price) / (Math.abs(before) + qty);
      this.pos = before + signed;
    } else {
      const closing = Math.min(Math.abs(before), qty);
      const pnl = (price - this.avg) * closing * Math.sign(before);
      this.realized += pnl;
      if (Math.abs(before) <= qty + 1e-12 && before + signed === 0 || Math.sign(before + signed) !== Math.sign(before)) {
        // позиция закрыта (или перевёрнута) — фиксируем исход
        pnl >= 0 ? this.wins++ : this.losses++;
      }
      this.pos = before + signed;
      if (Math.sign(this.pos) !== Math.sign(before) && this.pos !== 0) this.avg = price;
      if (this.pos === 0) this.avg = 0;
    }
    // ---- учёт сделок (раунд-трипов) для списка «Сделки»
    if (before === 0 && this.pos !== 0) {
      this._trip = { side: this.pos > 0 ? 'ЛОНГ' : 'ШОРТ',
                     openR: realizedBefore, notional: price * Math.abs(this.pos) };
    } else if (this._trip) {
      if (Math.sign(this.pos) === Math.sign(before) && Math.abs(this.pos) > Math.abs(before)) {
        this._trip.notional += price * (Math.abs(this.pos) - Math.abs(before)); // доливка
      }
      if (this.pos === 0 || Math.sign(this.pos) !== Math.sign(before)) {
        const pnl = this.realized - this._trip.openR;
        const pct = this._trip.notional > 0 ? (pnl / this._trip.notional) * 100 : 0;
        this.trades.push({ t: this.p.simTime, side: this._trip.side, pnl, pct });
        if (this.trades.length > 300) this.trades.splice(0, 100);
        this._trip = this.pos !== 0
          ? { side: this.pos > 0 ? 'ЛОНГ' : 'ШОРТ', openR: this.realized,
              notional: price * Math.abs(this.pos) }
          : null;
      }
    }
    this.fills.push({ t: this.p.simTime, side, price, qty, fee, taker, note });
    if (this.onFill) this.onFill(side, increased);
    this._note(`${side === 'B' ? 'КУПЛЕНО' : 'ПРОДАНО'} ${qty} @ ${price.toFixed(this._dec())} (${note}${taker ? ', тейкер' : ', мейкер'})`);
  }

  _dec() { return Math.max(0, -Math.floor(Math.log10(this.p.tick) + 1e-9)); }
  _fmt(idx) { return (idx * this.p.tick).toFixed(this._dec()); }
  _note(msg) {
    const d = new Date(this.p.simTime);
    this.log.push(`[${d.toTimeString().slice(0, 8)}] ${msg}`);
    if (this.log.length > 200) this.log.splice(0, this.log.length - 200);
  }
}

window.TradingSim = Sim;
