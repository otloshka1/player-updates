// Связка UI: сессии, импорт, запись, управление плеером, торговая панель.
'use strict';

const $ = (id) => document.getElementById(id);
const SPEEDS = [0.25, 0.5, 1, 2, 4, 8, 16];

// ---- настройки: сохраняются в localStorage между сессиями
const DEFAULT_SETTINGS = {
  feeMaker: 0.02, feeTaker: 0.05, bigLot: 5000, hideValue: 0, tapeFilter: 0,
  volUnit: 'usd', group: 1, autoCenter: true, usdSel: null,
  usdPresets: [35, 100, 500, 1000, 2000],
  chartW: 340, sound: true, pingMs: 0,
  hardFill: false, fillChance: 8,
  scaleUsd: 0,
  dens1Usd: 200000, dens1Clr: '#f5a623',
  dens2Usd: 500000, dens2Clr: '#c544f0',
  ladderTheme: 'dark', clrCluster: '', clrDigits: '',
  magnetMode: 2,
  colors: { bid: '#28c8e0', ask: '#f23645', accent: '#3b82f6', pnl: '#2ebd85', bg: '#0c0e12' },
  binds: {
    close: 'KeyC', center: 'KeyR', pendMod: 'ShiftLeft',
    exitMod: 'AltLeft', cancelAll: 'Escape',
    buy: 'Digit1', sell: 'Digit2', zoomMod: 'KeyG',
    limitLong: 'Digit3', limitShort: 'Digit4',
  },
};

// готовые темы стакана; null = использовать цвета основной темы
const LADDER_THEMES = {
  dark: { bg: null, zoneAsk: null, zoneBid: null, bar: null, digits: null },
  light: {
    bg: '#b9bcc2', zoneAsk: 'rgba(226, 80, 92, 0.30)',
    zoneBid: 'rgba(86, 134, 232, 0.30)', bar: '#f0a030', digits: '#14161a',
  },
  zones: {
    bg: null, zoneAsk: 'rgba(242, 54, 69, 0.10)',
    zoneBid: 'rgba(60, 130, 230, 0.13)', bar: '#f0a030', digits: '#dfe4ee',
  },
};
let S = loadSettings();

function loadSettings() {
  const def = JSON.parse(JSON.stringify(DEFAULT_SETTINGS));
  try {
    const saved = JSON.parse(localStorage.getItem('playerSettings') || '{}');
    // миграция старых биндов: «стоп» стал «отложкой», «лимитка» убрана
    if (saved.binds && saved.binds.stopMod && !saved.binds.pendMod) {
      saved.binds.pendMod = saved.binds.stopMod;
    }
    if (saved.binds) { delete saved.binds.stopMod; delete saved.binds.limitMod; }
    // миграция: раздельные SL/TP объединены в одну клавишу выхода
    if (saved.binds && saved.binds.slMod && !saved.binds.exitMod) {
      saved.binds.exitMod = saved.binds.slMod;
    }
    if (saved.binds) { delete saved.binds.slMod; delete saved.binds.tpMod; }
    Object.assign(def.binds, saved.binds || {});
    Object.assign(def.colors, saved.colors || {});
    delete saved.binds;
    delete saved.colors;
    Object.assign(def, saved);
    if (!Array.isArray(def.usdPresets) || def.usdPresets.length !== 5) {
      def.usdPresets = [...DEFAULT_SETTINGS.usdPresets];
    }
  } catch (e) { /* битые настройки — берём дефолт */ }
  return def;
}
function saveSettings() {
  try { localStorage.setItem('playerSettings', JSON.stringify(S)); } catch (e) {}
}

const held = new Set();      // зажатые клавиши (e.code)
let capturingBind = null;    // какой бинд сейчас назначается

// слоты стаканов: каждый со своим плеером, симулятором и канвасом.
// player/sim/view — алиасы АКТИВНОГО слота (для торговли, биндов, графика).
let slots = [];
let activeSlot = -1;
let player = null;
let sim = null;
let view = null;
let chart = null;
let recorders = [];
let usdMult = 1;
const MAX_SLOTS = 4;

function forEachView(fn) { for (const s of slots) fn(s.view); }

/** Применить все настройки вида к конкретному стакану. */
function applyViewSettings(v) {
  v.group = S.group;
  v.unitUsd = S.volUnit === 'usd';
  v.autoCenterEnabled = S.autoCenter;
  v.scaleUsd = S.scaleUsd;
  v.dens1Usd = S.dens1Usd;
  v.dens1Clr = S.dens1Clr;
  v.dens2Usd = S.dens2Usd;
  v.dens2Clr = S.dens2Clr;
  v.clrPrintBuy = S.clrPrintBuy || '';
  v.clrPrintSell = S.clrPrintSell || '';
  const t = { ...(LADDER_THEMES[S.ladderTheme] || LADDER_THEMES.dark) };
  if (S.clrCluster) t.bar = S.clrCluster;
  if (S.clrDigits) t.digits = S.clrDigits;
  v.theme = t;
  v.getLevels = () => chart.drawings;
}
const symbolsByEx = {};  // ex -> Map(symbol -> {tick, step})
const EX_NAMES = { fut: 'Binance фьюч', spot: 'Binance спот', bybit: 'Bybit', okx: 'OKX' };
let lastFrame = 0;
let tapeAt = 0;
let draggingTimeline = false;

// ---------------------------------------------------------------- инициализация

window.addEventListener('DOMContentLoaded', async () => {
  chart = new ChartUI.ChartView($('chart-canvas'));
  chart.resize();
  window.addEventListener('resize', () => { forEachView((v) => v.resize()); chart.resize(); });
  const ro = new ResizeObserver(() => { forEachView((v) => v.resize()); chart.resize(); });
  ro.observe($('slots'));
  ro.observe(document.querySelector('.chart-panel'));

  initTabs();
  initControls();
  initTrading();
  initKeys();
  initImport();
  initImportFile();
  initRecord();
  initSituations();
  applySettingsToUI();

  const y = new Date(Date.now() - 86400000);
  $('imp-date').value = y.toISOString().slice(0, 10);

  await loadSymbols();
  await refreshSessions();
  requestAnimationFrame(loop);
});

async function loadSymbols(ex = 'fut') {
  try {
    if (!symbolsByEx[ex]) {
      const r = await fetch('/api/symbols?ex=' + ex);
      const list = await r.json();
      const map = new Map();
      for (const s of list) map.set(s.symbol, s);
      symbolsByEx[ex] = map;
    }
    const dl = $('symbols-dl');
    dl.innerHTML = '';
    for (const sym of symbolsByEx[ex].keys()) {
      const o = document.createElement('option');
      o.value = sym;
      dl.appendChild(o);
    }
  } catch (e) {
    setText('imp-status', 'нет связи с биржей (список символов недоступен)');
  }
}

// ---------------------------------------------------------------- слоты стаканов

function createSlot() {
  if (slots.length >= MAX_SLOTS) return slots[slots.length - 1];
  const root = document.createElement('div');
  root.className = 'slot';
  const head = document.createElement('div');
  head.className = 'slot-head';
  head.innerHTML = '<span class="slot-sym">—</span>';
  const close = document.createElement('button');
  close.className = 'slot-close';
  close.textContent = '✕';
  close.title = 'Закрыть стакан';
  const wrap = document.createElement('div');
  wrap.className = 'dom-wrap';
  const canvas = document.createElement('canvas');
  wrap.appendChild(canvas);
  head.appendChild(close);
  root.appendChild(head);
  root.appendChild(wrap);
  $('slots').appendChild(root);

  const slot = {
    root, head, canvas,
    view: new DomUI.DomView(canvas),
    player: null, sim: null,
    klines: null, histBase: {},
  };
  applyViewSettings(slot.view);
  slot.view.resize();
  close.onclick = (e) => { e.stopPropagation(); closeSlot(slots.indexOf(slot)); };
  head.onclick = () => setActiveSlot(slots.indexOf(slot));
  bindSlotCanvas(slot);
  slots.push(slot);
  return slot;
}

function setActiveSlot(i) {
  if (i < 0 || i >= slots.length) return;
  activeSlot = i;
  const s = slots[i];
  player = s.player;
  sim = s.sim;
  view = s.view;
  slots.forEach((sl, k) => sl.root.classList.toggle('active', k === i));
  if (player) {
    chart.reset();
    chart.setSymbol(player.meta.symbol);
    chart.setBase(s.klines);
    chart.sessionStart = player.meta.start;
    chart.histBase = s.histBase;
    ensureHist(chart.tfSec);
    const modeTxt = player.meta.mode === 'rec' ? 'запись 1:1'
      : (player.meta.l1 ? 'история + реальный L1' : 'история (стакан ≈)');
    setText('session-title', `${player.meta.symbol} · ${player.meta.date || ''} · ${modeTxt}`);
  }
  renderTabs();
  updateHud();
}

function closeSlot(i) {
  if (i < 0 || i >= slots.length) return;
  const s = slots[i];
  s.root.remove();
  slots.splice(i, 1);
  if (!slots.length) {
    player = null; sim = null; view = null;
    activeSlot = -1;
    setText('session-title', 'сессия не открыта');
    renderTabs();
    return;
  }
  setActiveSlot(Math.min(i, slots.length - 1));
}

function renderTabs() {
  const el = $('ticker-tabs');
  el.innerHTML = '';
  slots.forEach((s, i) => {
    const b = document.createElement('button');
    b.className = 'ticker-tab' + (i === activeSlot ? ' active' : '');
    b.textContent = s.player ? s.player.meta.symbol : '—';
    b.onclick = () => setActiveSlot(i);
    el.appendChild(b);
  });
}

/** Клики и колесо для конкретного стакана. Клик также активирует слот. */
function bindSlotCanvas(slot) {
  const c = slot.canvas;
  const act = (e, isRight) => {
    if (slots.indexOf(slot) !== activeSlot) setActiveSlot(slots.indexOf(slot));
    if (!slot.player || !slot.sim) return;
    const r = c.getBoundingClientRect();
    const hit = slot.view.hitTest(e.clientX - r.left, e.clientY - r.top);
    if (hit.col === 'orders') {
      for (let k = 0; k < slot.view.group; k++) slot.sim.cancelAt(hit.idx + k);
      return;
    }
    if (hit.col !== 'size' && hit.col !== 'price') return;
    if (held.has(S.binds.pendMod)) {
      slot.sim.placePending(isRight ? 'S' : 'B', hit.idx, qty());
      return;
    }
    if (held.has(S.binds.exitMod)) { slot.sim.placeExit(hit.idx); return; }
    const b = slot.player.book;
    const mid = (b.bestAsk !== -1 && b.bestBid !== -1)
      ? (b.bestAsk + b.bestBid) / 2 : slot.player.lastIdx;
    const upper = hit.idx >= mid;
    if (!isRight) {
      if (upper) slot.sim.marketDelayed('B', qty());
      else slot.sim.placeLimit('B', hit.idx, qty());
    } else {
      if (upper) slot.sim.placeLimit('S', hit.idx, qty());
      else slot.sim.marketDelayed('S', qty());
    }
  };
  c.addEventListener('click', (e) => act(e, false));
  c.addEventListener('contextmenu', (e) => { e.preventDefault(); act(e, true); });
  c.addEventListener('wheel', (e) => {
    e.preventDefault();
    if (held.has(S.binds.zoomMod)) {
      // сжатие меняется на 1 за щелчок колеса
      setGroupValue(slot.view.group + (e.deltaY > 0 ? 1 : -1));
      return;
    }
    slot.view.scroll(Math.sign(e.deltaY) * -3);
  }, { passive: false });
  c.addEventListener('mousemove', (e) => {
    const r = c.getBoundingClientRect();
    slot.view.hover = { x: e.clientX - r.left, y: e.clientY - r.top };
  });
  c.addEventListener('mouseleave', () => { slot.view.hover = null; });
}

// ---------------------------------------------------------------- настройки

const KEY_NAMES = {
  ShiftLeft: '⇧ Shift', ShiftRight: '⇧ Shift R', AltLeft: '⌥ Alt',
  AltRight: '⌥ Alt R', MetaLeft: '⌘ Cmd', ControlLeft: 'Ctrl',
  Space: 'Пробел', Backquote: '`',
};
function keyLabel(code) {
  return KEY_NAMES[code] || code.replace(/^(Key|Digit)/, '');
}

function renderBinds() {
  document.querySelectorAll('.bind').forEach((b) => {
    b.textContent = capturingBind === b.dataset.bind ? '…' : keyLabel(S.binds[b.dataset.bind]);
    b.classList.toggle('capturing', capturingBind === b.dataset.bind);
  });
}

function applySettingsToUI() {
  $('fee-maker').value = S.feeMaker;
  $('fee-taker').value = S.feeTaker;
  $('ping-ms').value = S.pingMs || 0;
  $('ping-ms').onchange = () => {
    S.pingMs = Math.max(0, parseFloat($('ping-ms').value) || 0);
    for (const s of slots) if (s.sim) s.sim.pingMs = S.pingMs;
    saveSettings();
  };
  $('hard-fill').checked = !!S.hardFill;
  $('fill-chance').value = S.fillChance || 8;
  const applyHardFill = () => {
    S.hardFill = $('hard-fill').checked;
    S.fillChance = Math.max(1, Math.min(100, parseFloat($('fill-chance').value) || 8));
    for (const s of slots) if (s.sim) {
      s.sim.hardFill = S.hardFill;
      s.sim.fillChance = S.fillChance / 100;
    }
    saveSettings();
  };
  $('hard-fill').onchange = applyHardFill;
  $('fill-chance').onchange = applyHardFill;
  $('big-lot').value = S.bigLot;
  $('hide-value').value = S.hideValue || 0;
  $('tape-filter').value = S.tapeFilter;
  $('vol-unit').value = S.volUnit;
  $('set-group').value = S.group;
  setGroupValue(S.group);
  $('auto-center').checked = S.autoCenter;
  // шкала и фильтры плотностей
  $('scale-usd').value = S.scaleUsd;
  $('dens1-usd').value = S.dens1Usd;
  $('dens2-usd').value = S.dens2Usd;
  $('dens1-clr').value = S.dens1Clr;
  $('dens2-clr').value = S.dens2Clr;
  applyDensity();
  for (const id of ['scale-usd', 'dens1-usd', 'dens2-usd', 'dens1-clr', 'dens2-clr']) {
    $(id).onchange = () => {
      S.scaleUsd = parseFloat($('scale-usd').value) || 0;
      S.dens1Usd = parseFloat($('dens1-usd').value) || 0;
      S.dens2Usd = parseFloat($('dens2-usd').value) || 0;
      S.dens1Clr = $('dens1-clr').value;
      S.dens2Clr = $('dens2-clr').value;
      applyDensity();
      saveSettings();
    };
  }
  renderBinds();
  refreshUsdPresets();

  document.querySelectorAll('.bind').forEach((b) => {
    b.onclick = () => {
      capturingBind = capturingBind === b.dataset.bind ? null : b.dataset.bind;
      renderBinds();
    };
  });
  $('auto-center').onchange = () => {
    S.autoCenter = $('auto-center').checked;
    forEachView((v) => { v.autoCenterEnabled = S.autoCenter; });
    saveSettings();
  };
  $('btn-left').onclick = () => {
    document.querySelector('main').classList.toggle('no-left');
    forEachView((v) => v.resize());
    chart.resize();
  };

  // ---- тема стакана
  $('ladder-theme').value = S.ladderTheme;
  applyLadderTheme();
  const syncLadderPickers = () => {
    const t = LADDER_THEMES[S.ladderTheme] || LADDER_THEMES.dark;
    $('clr-cluster').value = S.clrCluster || t.bar || '#f0a030';
    $('clr-digits').value = S.clrDigits || t.digits || '#cfd6e4';
  };
  syncLadderPickers();
  $('ladder-theme').onchange = () => {
    S.ladderTheme = $('ladder-theme').value;
    applyLadderTheme();
    syncLadderPickers();
    saveSettings();
  };
  $('clr-cluster').oninput = () => { S.clrCluster = $('clr-cluster').value; applyLadderTheme(); saveSettings(); };
  $('clr-digits').oninput = () => { S.clrDigits = $('clr-digits').value; applyLadderTheme(); saveSettings(); };
  $('clr-print-buy').value = S.clrPrintBuy || S.colors.bid;
  $('clr-print-sell').value = S.clrPrintSell || S.colors.ask;
  $('clr-print-buy').oninput = () => { S.clrPrintBuy = $('clr-print-buy').value; applyLadderTheme(); saveSettings(); };
  $('clr-print-sell').oninput = () => { S.clrPrintSell = $('clr-print-sell').value; applyLadderTheme(); saveSettings(); };
  $('btn-ladder-reset').onclick = () => {
    S.clrCluster = ''; S.clrDigits = ''; S.clrPrintBuy = ''; S.clrPrintSell = '';
    applyLadderTheme(); syncLadderPickers(); saveSettings();
    $('clr-print-buy').value = S.colors.bid;
    $('clr-print-sell').value = S.colors.ask;
  };

  // ---- обновления
  $('btn-update-check').onclick = async () => {
    setText('update-status', 'проверяю…');
    try {
      const st = await (await fetch('/api/update/check')).json();
      if (!st.enabled) {
        setText('update-status', `Версия ${st.current}. Источник обновлений не настроен.`);
        return;
      }
      if (st.error) { setText('update-status', '⚠ ' + st.error); return; }
      if (!st.hasUpdate) { setText('update-status', `У вас последняя версия (${st.current}).`); return; }
      if (!confirm(`Доступна версия ${st.latest} (у вас ${st.current}). Установить?\n${st.notes || ''}`)) return;
      setText('update-status', 'скачиваю и устанавливаю…');
      const ap = await (await fetch('/api/update/apply', { method: 'POST' })).json();
      setText('update-status', ap.ok
        ? `Обновлено до ${ap.version}. Перезапустите плеер.` : '⚠ ' + (ap.error || 'ошибка'));
    } catch (e) {
      setText('update-status', '⚠ ' + e.message);
    }
  };

  // ---- цвета интерфейса
  applyColors();
  document.querySelectorAll('.clr').forEach((inp) => {
    inp.value = S.colors[inp.dataset.clr];
    inp.oninput = () => {
      S.colors[inp.dataset.clr] = inp.value;
      applyColors();
      saveSettings();
    };
  });
  $('btn-colors-reset').onclick = () => {
    S.colors = { ...DEFAULT_SETTINGS.colors };
    document.querySelectorAll('.clr').forEach((inp) => { inp.value = S.colors[inp.dataset.clr]; });
    applyColors();
    saveSettings();
  };

  // ---- звук
  $('snd-on').checked = S.sound;
  $('snd-on').onchange = () => { S.sound = $('snd-on').checked; saveSettings(); };

  // ---- сплиттер стакан/график
  setChartW(S.chartW);
  const sp = $('splitter');
  let spDrag = null;
  sp.addEventListener('mousedown', (e) => {
    spDrag = { x: e.clientX, w: S.chartW };
    sp.classList.add('dragging');
    e.preventDefault();
  });
  window.addEventListener('mousemove', (e) => {
    if (!spDrag) return;
    setChartW(spDrag.w + (spDrag.x - e.clientX));
  });
  window.addEventListener('mouseup', () => {
    if (spDrag) { spDrag = null; sp.classList.remove('dragging'); saveSettings(); }
  });
  window.addEventListener('keydown', (e) => { held.add(e.code); }, true);
  window.addEventListener('keyup', (e) => { held.delete(e.code); }, true);
  window.addEventListener('blur', () => held.clear());
}

// история до начала сессии для ТФ от 1м (кэшируется на сервере)
const TF_NAMES = { 60: '1m', 300: '5m', 900: '15m', 1800: '30m', 3600: '1h', 14400: '4h', 86400: '1d' };
function ensureHist(sec) {
  if (!player) return;
  if (sec < 60) { ensureHist(60); return; } // секундные ТФ берут минутный контекст
  if (!TF_NAMES[sec] || (sec in chart.histBase)) return;
  chart.histBase[sec] = null; // защита от повторной загрузки
  const ex = player.meta.exchange || 'fut';
  fetch(`/api/histklines?symbol=${encodeURIComponent(player.meta.symbol)}`
        + `&tf=${TF_NAMES[sec]}&end=${player.meta.start}&ex=${ex}`)
    .then((r) => (r.ok ? r.json() : []))
    .then((arr) => { chart.histBase[sec] = arr || []; })
    .catch(() => { chart.histBase[sec] = []; });
}

function applyLadderTheme() { forEachView(applyViewSettings); }
function applyDensity() { forEachView(applyViewSettings); }

function applyColors() {
  const r = document.documentElement.style;
  r.setProperty('--bid', S.colors.bid);
  r.setProperty('--ask', S.colors.ask);
  r.setProperty('--accent', S.colors.accent);
  r.setProperty('--pnl-green', S.colors.pnl);
  r.setProperty('--bg', S.colors.bg);
}

function setChartW(w) {
  // резерв: стакан (мин. 280) + правая панель + сплиттер + левая, если видна
  const leftVisible = !document.querySelector('main').classList.contains('no-left');
  const reserve = 280 + 226 + 6 + (leftVisible ? 248 : 0);
  const maxW = Math.max(220, window.innerWidth - reserve);
  S.chartW = Math.max(220, Math.min(maxW, Math.round(w)));
  document.documentElement.style.setProperty('--chart-w', S.chartW + 'px');
}

// ---- звук исполнения сделки: клик из терминала (app/sounds/fill.wav)
const fillSounds = [new Audio('/sounds/fill.wav'), new Audio('/sounds/fill.wav'),
                    new Audio('/sounds/fill.wav')];
let fillSndIdx = 0;
let lastSndAt = 0;
function clickSound() {
  if (!S.sound) return;
  // пачка одновременных исполнений — один щелчок, не хор
  const now = performance.now();
  if (now - lastSndAt < 160) return;
  lastSndAt = now;
  try {
    const a = fillSounds[fillSndIdx++ % fillSounds.length];
    a.currentTime = 0;
    a.play().catch(() => {});
  } catch (e) { /* звук недоступен — молчим */ }
}

/** Выставить сжатие везде: все стаканы, движки, шапка, настройки. */
function setGroupValue(g) {
  g = Math.max(1, Math.round(g) || 1);
  S.group = g;
  for (const s of slots) {
    s.view.group = g;
    if (s.player) s.player.riverGroup = g;
  }
  const sel = $('group');
  if (![...sel.options].some((o) => o.value === String(g))) {
    let custom = sel.querySelector('option[data-custom]');
    if (!custom) {
      custom = document.createElement('option');
      custom.dataset.custom = '1';
      sel.appendChild(custom);
    }
    custom.value = String(g);
    custom.textContent = '×' + g;
  }
  sel.value = String(g);
  if ($('set-group').value !== String(g)) $('set-group').value = g;
  saveSettings();
}

// ---------------------------------------------------------------- вкладки

function initTabs() {
  document.querySelectorAll('.tab').forEach((b) => {
    b.onclick = () => {
      document.querySelectorAll('.tab').forEach((x) => x.classList.remove('active'));
      document.querySelectorAll('.tab-page').forEach((x) => x.classList.remove('active'));
      b.classList.add('active');
      $('page-' + b.dataset.tab).classList.add('active');
    };
  });
}

// ---------------------------------------------------------------- сессии

// ---------------------------------------------------------------- ситуации

let seekAfterOpen = null; // {date:'ДД.ММ.ГГГГ', t:'ЧЧ:ММ'} — прыжок к моменту после импорта

function isoDate(d) {
  const m = /^(\d{2})\.(\d{2})\.(\d{4})$/.exec(d);
  return m ? `${m[3]}-${m[2]}-${m[1]}` : '';
}

function initSituations() {
  const el = $('situations-list');
  if (!el || !window.SITUATIONS) return;
  el.innerHTML = '';
  for (const cat of window.SITUATIONS) {
    const h = document.createElement('div');
    h.className = 'sit-cat';
    h.textContent = cat.title;
    el.appendChild(h);
    for (const g of cat.groups) {
      const gh = document.createElement('div');
      gh.className = 'sit-group';
      gh.textContent = g.name;
      el.appendChild(gh);
      for (const it of g.items) {
        const row = document.createElement('div');
        row.className = 'sit-row';
        const iso = isoDate(it.d);
        row.innerHTML = `<span class="sit-sym">${it.s}</span>` +
          `<span class="sit-date">${it.t ? it.t + ' ' : ''}${it.d}</span>` +
          (it.note ? `<span class="sit-note">${it.note}</span>` : '');
        if (iso) {
          row.classList.add('clickable');
          row.onclick = () => loadSituation(it, iso);
        }
        el.appendChild(row);
      }
    }
  }
}

/** Подставить ситуацию в форму импорта и перейти к проверке. */
function loadSituation(it, iso) {
  const ex = it.ex || 'fut';
  $('imp-ex').value = ex;
  loadSymbols(ex);
  const known = symbolsByEx[ex];
  // тикер: как есть, если уже в списке; иначе +USDT (или -USDT-SWAP для okx)
  let sym = it.s;
  if (!(known && known.has(sym))) {
    sym = ex === 'okx' ? `${it.s}-USDT-SWAP` : `${it.s}USDT`;
  }
  $('imp-symbol').value = sym;
  $('imp-date').value = iso;
  seekAfterOpen = it.t ? { iso, t: it.t } : null;
  // перейти на вкладку «Импорт»
  document.querySelector('.tab[data-tab="import"]').click();
  $('imp-symbol').dispatchEvent(new Event('input'));
  setText('imp-status', it.t
    ? `После импорта прыгну к ${it.t} (по UTC; при нужде подкрутите таймлайн).`
    : 'Готово к импорту.');
}

function initImportFile() {
  $('btn-import-file').onclick = () => $('import-file').click();
  $('import-file').onchange = async () => {
    const f = $('import-file').files[0];
    if (!f) return;
    setText('import-file-status', `загрузка ${f.name} (${fmtBytes(f.size)})…`);
    try {
      const r = await fetch('/api/sessions/import', { method: 'POST', body: f });
      const j = await r.json();
      if (j.error) setText('import-file-status', '⚠ ' + j.error);
      else {
        setText('import-file-status', 'Импортировано ✓');
        await refreshSessions();
      }
    } catch (e) {
      setText('import-file-status', '⚠ ' + e.message);
    }
    $('import-file').value = '';
  };
}

async function refreshSessions() {
  const r = await fetch('/api/sessions');
  const list = await r.json();
  const el = $('sessions-list');
  if (!list.length) {
    el.innerHTML = '<div class="hint">Пока нет сессий.<br>Импортируйте день с Binance или запишите живой рынок.</div>';
    return;
  }
  el.innerHTML = '';
  for (const m of list) {
    const div = document.createElement('div');
    div.className = 'sess';
    const dur = m.start && m.end ? fmtDur(m.end - m.start) : '—';
    const badge = m.mode === 'rec'
      ? '<span class="badge rec">запись 1:1</span>'
      : (m.l1 ? '<span class="badge l1">история+L1</span>' : '<span class="badge hist">история ≈</span>');
    const exName = EX_NAMES[m.exchange || 'fut'] || m.exchange;
    div.innerHTML = `<div class="sess-top"><b>${m.symbol}</b> ${badge}</div>` +
      `<div class="sess-sub">${exName} · ${m.date || ''} · ${dur} · ${fmtNum(m.events)} событий</div>`;
    const del = document.createElement('button');
    del.className = 'sess-del';
    del.textContent = '✕';
    del.title = 'Удалить сессию';
    del.onclick = async (e) => {
      e.stopPropagation();
      if (!confirm(`Удалить сессию ${m.symbol} ${m.date || ''}?`)) return;
      await fetch('/api/sessions/' + m.id, { method: 'DELETE' });
      refreshSessions();
    };
    div.appendChild(del);
    const addBtn = document.createElement('button');
    addBtn.className = 'sess-add';
    addBtn.textContent = '+стакан';
    addBtn.title = 'Открыть в новом стакане рядом (до 4)';
    addBtn.onclick = (e) => {
      e.stopPropagation();
      if (slots.length >= MAX_SLOTS) { alert('Максимум 4 стакана'); return; }
      openSession(m.id, createSlot());
    };
    div.appendChild(addBtn);
    const dl = document.createElement('a');
    dl.className = 'sess-dl';
    dl.textContent = '⬇ файл';
    dl.title = 'Скачать запись файлом — можно передать другому';
    dl.href = `/api/sessions/${m.id}/export`;
    dl.download = `${m.id}.playersession`;
    dl.onclick = (e) => e.stopPropagation();
    div.appendChild(dl);
    div.onclick = () => openSession(m.id);
    el.appendChild(div);
  }
}

async function openSession(id, slot) {
  setText('session-title', 'загрузка…');
  const r = await fetch(`/api/sessions/${id}/meta`);
  if (!r.ok) { setText('session-title', 'ошибка загрузки'); return; }
  const meta = await r.json();
  if (!meta.tick) meta.tick = 0.1;

  if (!slot) slot = slots[activeSlot] || createSlot();
  const p = new PlayerEngine.Player(meta, {
    onTrade: (ev) => slot.sim && slot.sim.onTrade(ev),
    onBookChange: () => slot.sim && slot.sim.onBookChange(),
    onAnyTrade: (ev) => { if (slots[activeSlot] === slot) chart.onTrade(ev); },
  });
  p.bigLotUsd = S.bigLot;
  p.hideValueUsd = S.hideValue || 0;
  p.riverFilterUsd = S.tapeFilter;
  p.riverGroup = S.group;
  p.speed = parseFloat($('speed').value) || 1;
  slot.player = p;
  slot.sim = new TradingSim(p, { makerFee: S.feeMaker / 100, takerFee: S.feeTaker / 100 });
  slot.sim.pingMs = S.pingMs || 0;
  slot.sim.hardFill = !!S.hardFill;
  slot.sim.fillChance = Math.max(0.01, (S.fillChance || 8) / 100);
  slot.sim.onFill = () => clickSound();
  slot.klines = null;
  slot.histBase = {};
  slot.head.querySelector('.slot-sym').textContent = meta.symbol;
  fetch(`/api/sessions/${id}/klines`)
    .then((r2) => (r2.ok ? r2.json() : null))
    .then((arr) => {
      slot.klines = arr;
      if (slots[activeSlot] === slot) chart.setBase(arr);
    })
    .catch(() => {});
  await p.init();
  slot.view.recenter(p);
  setActiveSlot(slots.indexOf(slot));
  $('timeline').value = 0;
  $('btn-play').textContent = '▶';
}

// ---------------------------------------------------------------- импорт

function initImport() {
  $('imp-symbol').value = 'BTCUSDT';
  const check = debounce(async () => {
    const s = $('imp-symbol').value.trim().toUpperCase();
    const d = $('imp-date').value;
    const ex = $('imp-ex').value;
    if (!s || !d) return;
    setText('imp-check', 'проверяю наличие…');
    try {
      const r = await fetch(`/api/histcheck?symbol=${encodeURIComponent(s)}&date=${d}&ex=${ex}`);
      const j = await r.json();
      if (j.error) { setText('imp-check', j.error); return; }
      const agg = j.aggTrades != null ? `лента: ${fmtBytes(j.aggTrades)} ✓` : 'лента: нет ✗';
      const bt = ex !== 'fut' ? '' :
        (j.bookTicker != null ? ` · L1: ${fmtBytes(j.bookTicker)} ✓` : ' · L1 (bookTicker): нет');
      setText('imp-check', agg + bt);
      $('imp-l1').disabled = ex !== 'fut' || j.bookTicker == null;
      if ($('imp-l1').disabled) $('imp-l1').checked = false;
    } catch (e) {
      setText('imp-check', 'не удалось проверить: ' + e.message);
    }
  }, 500);
  $('imp-symbol').addEventListener('input', check);
  $('imp-date').addEventListener('change', check);
  $('imp-ex').addEventListener('change', () => {
    loadSymbols($('imp-ex').value);
    $('imp-symbol').value = $('imp-ex').value === 'okx' ? 'BTC-USDT-SWAP' : 'BTCUSDT';
    check();
  });
  check();

  $('btn-import').onclick = async () => {
    const s = $('imp-symbol').value.trim().toUpperCase();
    const d = $('imp-date').value;
    if (!s || !d) return;
    $('btn-import').disabled = true;
    try {
      const r = await fetch('/api/import', {
        method: 'POST',
        body: JSON.stringify({ symbol: s, date: d, l1: $('imp-l1').checked, ex: $('imp-ex').value }),
      });
      const { job, error } = await r.json();
      if (error) { setText('imp-status', error); return; }
      while (true) {
        await sleep(700);
        const st = await (await fetch('/api/import/status?id=' + job)).json();
        if (st.error) { setText('imp-status', '⚠ ' + st.error); break; }
        setText('imp-status', `${st.status} ${Math.round(st.progress || 0)}%`);
        if (st.session) {
          setText('imp-status', 'Готово ✓');
          await refreshSessions();
          await openSession(st.session);
          // прыжок к моменту ситуации (HH:MM по UTC выбранного дня)
          if (seekAfterOpen && player) {
            const [Y, M, D] = seekAfterOpen.iso.split('-').map(Number);
            const [hh, mm] = seekAfterOpen.t.split(':').map(Number);
            let target = Date.UTC(Y, M - 1, D, hh, mm) - 120000; // за 2 мин до события
            target = Math.max(player.meta.start, Math.min(target, player.meta.end));
            chart.reset();
            await player.seek(target);
            view.recenter(player);
          }
          seekAfterOpen = null;
          break;
        }
      }
    } finally {
      $('btn-import').disabled = false;
    }
  };
}

// ---------------------------------------------------------------- запись

function initRecord() {
  $('rec-symbol').value = 'BTCUSDT';
  $('rec-ex').addEventListener('change', () => {
    loadSymbols($('rec-ex').value);
    $('rec-symbol').value = $('rec-ex').value === 'okx' ? 'BTC-USDT-SWAP' : 'BTCUSDT';
  });
  const renderStatus = () => {
    if (!recorders.length) return;
    const parts = recorders.map((r) =>
      `${r.symbol}: ${r.state === 'recording' ? '●' : '…'} ${fmtNum(r.nTrades)} тр · ${fmtBytes(r.bytes)}`);
    const dur = recorders[0].start_ts && recorders[0].last_ts
      ? fmtDur(recorders[0].last_ts - recorders[0].start_ts) : '0м';
    setText('rec-status', `${dur} · ` + parts.join('  |  '));
  };
  $('btn-rec').onclick = async () => {
    if (recorders.length) {
      $('btn-rec').disabled = true;
      setText('rec-status', 'сохраняю…');
      const ids = await Promise.all(recorders.map((r) => r.stop().catch(() => null)));
      recorders = [];
      $('btn-rec').disabled = false;
      $('btn-rec').textContent = '⏺ Начать запись';
      $('btn-rec').classList.remove('recording');
      setText('rec-status', 'сессии сохранены');
      await refreshSessions();
      const first = ids.find(Boolean);
      if (first) openSession(first);
      return;
    }
    // несколько монет через запятую или пробел
    const ex = $('rec-ex').value;
    await loadSymbols(ex);
    const exMap = symbolsByEx[ex] || new Map();
    const list = [...new Set($('rec-symbol').value.toUpperCase().split(/[\s,;]+/).filter(Boolean))];
    if (!list.length) return;
    if (list.length > 8) { setText('rec-status', 'не больше 8 монет за раз'); return; }
    const bad = list.find((s) => !exMap.get(s));
    if (bad) { setText('rec-status', 'неизвестный символ: ' + bad); return; }
    for (const s of list) {
      const info = exMap.get(s);
      const rec = new LiveRecorder(ex, s, info.tick, info.step, renderStatus);
      recorders.push(rec);
      rec.start();
    }
    $('btn-rec').textContent = `⏹ Остановить и сохранить (${list.length})`;
    $('btn-rec').classList.add('recording');
  };
  setInterval(() => { if (recorders.length) renderStatus(); }, 1000);
  window.addEventListener('beforeunload', (e) => {
    if (recorders.some((r) => r.state === 'recording')) {
      e.preventDefault();
      e.returnValue = 'Идёт запись — закрыть?';
    }
  });
}

// ---------------------------------------------------------------- управление плеером

function initControls() {
  $('btn-play').onclick = togglePlay;
  $('speed').innerHTML = SPEEDS.map((s) => `<option value="${s}" ${s === 1 ? 'selected' : ''}>${s}×</option>`).join('');
  $('speed').onchange = () => {
    const sp = parseFloat($('speed').value);
    for (const s of slots) if (s.player) s.player.speed = sp;
  };
  $('group').onchange = () => setGroupValue(parseInt($('group').value, 10));
  $('set-group').onchange = () => setGroupValue(parseInt($('set-group').value, 10));
  $('tape-filter').onchange = () => {
    S.tapeFilter = parseFloat($('tape-filter').value) || 0;
    for (const s of slots) if (s.player) s.player.setRiverFilter(S.tapeFilter);
    saveSettings();
  };
  $('vol-unit').onchange = () => {
    S.volUnit = $('vol-unit').value;
    forEachView((v) => { v.unitUsd = S.volUnit === 'usd'; });
    saveSettings();
  };
  $('btn-chart').onclick = () => {
    document.querySelector('main').classList.toggle('no-chart');
    forEachView((v) => v.resize());
    chart.resize();
  };
  $('btn-right').onclick = () => {
    document.querySelector('main').classList.toggle('no-right');
    forEachView((v) => v.resize());
    chart.resize();
  };
  document.querySelectorAll('.tf[data-tf]').forEach((b) => {
    b.onclick = () => {
      document.querySelectorAll('.tf[data-tf]').forEach((x) => x.classList.remove('active'));
      b.classList.add('active');
      const sec = parseInt(b.dataset.tf, 10);
      chart.setTf(sec);
      ensureHist(sec);
      if (sec < 60) ensureHist(60); // минутная история — контекст слева на секундных ТФ
    };
  });

  // ---- инструменты рисования на графике
  const toolBtns = { h: $('tool-h'), t: $('tool-t') };
  const refreshTools = () => {
    toolBtns.h.classList.toggle('active', chart.tool === 'h');
    toolBtns.t.classList.toggle('active', chart.tool === 't');
    $('tool-magnet').classList.toggle('active', chart.magnet > 0);
    $('chart-canvas').style.cursor = chart.tool ? 'crosshair' : '';
  };
  chart.onToolDone = refreshTools;
  chart.magnet = S.magnetMode;
  const magnetLabel = () => {
    $('tool-magnet').textContent = chart.magnet === 2 ? '🧲²' : chart.magnet === 1 ? '🧲' : '🧲✕';
    $('tool-magnet').title = chart.magnet === 2 ? 'Магнит: сильный (клик — слабый)'
      : chart.magnet === 1 ? 'Магнит: слабый (клик — выключить)' : 'Магнит: выключен (клик — сильный)';
  };
  magnetLabel();
  toolBtns.h.onclick = () => { chart.tool = chart.tool === 'h' ? null : 'h'; chart._pendingLine = null; refreshTools(); };
  toolBtns.t.onclick = () => { chart.tool = chart.tool === 't' ? null : 't'; chart._pendingLine = null; refreshTools(); };
  $('tool-magnet').onclick = () => {
    chart.magnet = chart.magnet === 2 ? 1 : chart.magnet === 1 ? 0 : 2;
    S.magnetMode = chart.magnet;
    saveSettings();
    magnetLabel();
    refreshTools();
  };
  $('tool-clear').onclick = () => {
    if (chart.drawings.length && !confirm('Удалить все линии на графике?')) return;
    chart.drawings = [];
    chart._pendingLine = null;
    chart._saveDrawings();
  };
  $('btn-center').onclick = () => player && view.recenter(player);
  $('btn-back').onclick = () => jump(-10000);
  $('btn-fwd').onclick = () => jump(10000);

  const tl = $('timeline');
  tl.addEventListener('input', () => {
    draggingTimeline = true;
    if (player) {
      const ts = player.meta.start + (tl.value / 1000) * (player.meta.end - player.meta.start);
      setText('time-label', fmtTime(ts));
    }
  });
  tl.addEventListener('change', async () => {
    draggingTimeline = false;
    if (player) {
      const ts = player.meta.start + (tl.value / 1000) * (player.meta.end - player.meta.start);
      if (sim) sim.cancelAll();
      chart.reset();
      await player.seek(ts);
      view.recenter(player);
    }
  });

  $('fee-maker').onchange = $('fee-taker').onchange = () => {
    S.feeMaker = parseFloat($('fee-maker').value) || 0;
    S.feeTaker = parseFloat($('fee-taker').value) || 0;
    if (sim) {
      sim.makerFee = S.feeMaker / 100;
      sim.takerFee = S.feeTaker / 100;
    }
    saveSettings();
  };
  $('big-lot').onchange = () => {
    S.bigLot = parseFloat($('big-lot').value) || 0;
    for (const s of slots) if (s.player) s.player.bigLotUsd = S.bigLot;
    saveSettings();
  };
  $('hide-value').onchange = () => {
    S.hideValue = parseFloat($('hide-value').value) || 0;
    for (const s of slots) if (s.player) s.player.hideValueUsd = S.hideValue;
    saveSettings();
  };
}

function togglePlay() {
  if (!player) return;
  const newPaused = !player.paused;
  // пауза/пуск действуют на все стаканы синхронно
  for (const s of slots) if (s.player) s.player.paused = newPaused;
  $('btn-play').textContent = newPaused ? '▶' : '⏸';
}

async function jump(ms) {
  if (!player) return;
  if (sim) sim.cancelAll();
  chart.reset();
  await player.seek(player.simTime + ms);
  view.recenter(player);
}

function initKeys() {
  window.addEventListener('keydown', (e) => {
    // режим назначения бинда: следующая клавиша становится биндом
    if (capturingBind) {
      e.preventDefault();
      if (e.code !== 'Escape') {
        S.binds[capturingBind] = e.code;
        saveSettings();
      }
      capturingBind = null;
      renderBinds();
      return;
    }
    if (e.target.tagName === 'INPUT' || e.target.tagName === 'SELECT') return;
    if (!player) return;
    if (e.code === S.binds.close) { if (sim) sim.flatten(); return; }
    if (e.code === S.binds.center) { view.recenter(player); return; }
    if (e.code === S.binds.cancelAll) { if (sim) sim.cancelAll(); return; }
    if (e.code === S.binds.buy) { if (sim) sim.marketDelayed('B', qty()); return; }
    if (e.code === S.binds.sell) { if (sim) sim.marketDelayed('S', qty()); return; }
    if (e.code === S.binds.limitLong) { if (sim) sim.placeLimitAtTouch('B', qty()); return; }
    if (e.code === S.binds.limitShort) { if (sim) sim.placeLimitAtTouch('S', qty()); return; }
    switch (e.code) {
      case 'ArrowLeft': e.preventDefault(); jump(-10000); break;
      case 'ArrowRight': e.preventDefault(); jump(10000); break;
      case 'ArrowUp': e.preventDefault(); stepSpeed(1); break;
      case 'ArrowDown': e.preventDefault(); stepSpeed(-1); break;
    }
  });
}

function stepSpeed(dir) {
  const i = SPEEDS.indexOf(player.speed);
  const ni = Math.max(0, Math.min(SPEEDS.length - 1, (i === -1 ? 2 : i) + dir));
  for (const s of slots) if (s.player) s.player.speed = SPEEDS[ni];
  $('speed').value = String(SPEEDS[ni]);
}

// ---------------------------------------------------------------- торговля

function initTrading() {
  document.querySelectorAll('.usd-preset').forEach((b) => {
    const i = parseInt(b.dataset.i, 10);
    b.onclick = () => {
      S.usdSel = S.usdPresets[i];
      saveSettings();
      refreshUsdPresets();
    };
    // двойной клик — задать свой объём для этой кнопки
    b.ondblclick = (e) => {
      e.preventDefault();
      const cur = S.usdPresets[i];
      const inp = prompt('Объём кнопки, $:', cur);
      const v = parseFloat(inp);
      if (!inp || !(v > 0)) return;
      const wasSelected = S.usdSel === cur;
      S.usdPresets[i] = v;
      if (wasSelected) S.usdSel = v;
      saveSettings();
      refreshUsdPresets();
    };
  });
  $('btn-x10').onclick = () => {
    usdMult = usdMult === 1 ? 10 : 1;
    $('btn-x10').classList.toggle('active', usdMult === 10);
  };
  // ручной ввод объёма отключает долларовый пресет
  $('qty').addEventListener('input', () => {
    S.usdSel = null;
    saveSettings();
    refreshUsdPresets();
  });
  $('btn-buy').onclick = () => sim && sim.marketDelayed('B', qty());
  $('btn-sell').onclick = () => sim && sim.marketDelayed('S', qty());
  $('btn-flat').onclick = () => sim && sim.flatten();
  $('btn-cancel-all').onclick = () => sim && sim.cancelAll();
}

function refreshUsdPresets() {
  document.querySelectorAll('.usd-preset').forEach((b) => {
    const v = S.usdPresets[parseInt(b.dataset.i, 10)];
    b.textContent = '$ ' + (v >= 1000 ? v.toLocaleString('ru-RU') : v);
    b.classList.toggle('active', S.usdSel === v);
  });
}

/** Объём заявки: активный $-пресет пересчитывается по текущей цене. */
function qty() {
  if (S.usdSel && player && player.lastPrice) {
    const step = player.meta.step || 0.001;
    const q = (S.usdSel * usdMult) / player.lastPrice;
    return Math.max(step, Math.round(q / step) * step);
  }
  return parseFloat($('qty').value) || 0;
}

// ---------------------------------------------------------------- главный цикл

function loop(ts) {
  const dt = Math.min(ts - lastFrame || 16, 200);
  lastFrame = ts;
  for (const s of slots) {
    if (!s.player) continue;
    s.player.advance(dt);
    s.view.draw(s.player, s.sim);
  }
  if (player) {
    chart.draw(player, sim);
    if (ts - tapeAt > 80) {
      tapeAt = ts;
      updateHud();
    }
  }
  requestAnimationFrame(loop);
}

function updateHud() {
  if (!player) return;
  if (!draggingTimeline) {
    setText('time-label', fmtTime(player.simTime));
    const f = (player.simTime - player.meta.start) / Math.max(1, player.meta.end - player.meta.start);
    $('timeline').value = Math.round(f * 1000);
  }
  if (player.ended) $('btn-play').textContent = '▶';
  if (player.waiting) setText('time-label', fmtTime(player.simTime) + ' ⏳');

  // активный $-пресет: показываем объём в монетах по текущей цене
  if (S.usdSel && player.lastPrice && document.activeElement !== $('qty')) {
    $('qty').value = +qty().toFixed(8);
  }
  if (sim) {
    const dec = Math.max(0, -Math.floor(Math.log10(player.tick) + 1e-9));
    const u = sim.unrealized();
    // панель позиции над стаканом
    const bar = $('pos-bar');
    if (sim.pos === 0) {
      bar.classList.add('hidden');
    } else {
      const notional = Math.abs(sim.pos) * sim.avg;
      const pct = notional > 0 ? (u / notional) * 100 : 0;
      bar.classList.remove('hidden');
      bar.classList.toggle('loss', u < 0);
      setText('pb-side', (sim.pos > 0 ? 'ЛОНГ ' : 'ШОРТ ') + Math.abs(+sim.pos.toFixed(6)));
      setText('pb-entry', sim.avg.toFixed(dec));
      setText('pb-size', (notional >= 1
        ? notional.toLocaleString('ru-RU', { maximumFractionDigits: 2 })
        : notional.toFixed(4)) + ' $');
      setText('pb-pnl', `${pct >= 0 ? '+' : ''}${pct.toFixed(2)} % · ${u >= 0 ? '+' : ''}${u.toFixed(2)} $`);
    }
    setText('pos-line', sim.pos === 0 ? 'нет позиции'
      : `${sim.pos > 0 ? 'ЛОНГ' : 'ШОРТ'} ${Math.abs(sim.pos)} @ ${sim.avg.toFixed(dec)}`);
    $('pos-line').className = 'stat ' + (sim.pos > 0 ? 'green' : sim.pos < 0 ? 'red' : '');
    setText('upnl-line', `нереализ.: ${u >= 0 ? '+' : ''}${u.toFixed(2)} USDT`);
    $('upnl-line').className = 'stat ' + (u > 0 ? 'green' : u < 0 ? 'red' : '');
    setText('rpnl-line', `реализ.: ${sim.realized >= 0 ? '+' : ''}${sim.realized.toFixed(2)} USDT · комиссии: ${sim.feesPaid.toFixed(2)}`);
    $('rpnl-line').className = 'stat ' + (sim.realized > 0 ? 'green' : sim.realized < 0 ? 'red' : '');
    const total = sim.wins + sim.losses;
    setText('stats-line', total ? `сделок: ${total} · в плюс: ${sim.wins} · винрейт: ${Math.round(100 * sim.wins / total)}%` : 'сделок пока нет');
    // список закрытых сделок: сторона · % · монета · профит $
    $('trades-list').innerHTML = sim.trades.slice(-40).reverse().map((tr) =>
      `<div class="trade ${tr.pnl >= 0 ? 'win' : 'loss'}">` +
      `<span>${tr.side}</span><span>${tr.pct >= 0 ? '+' : ''}${tr.pct.toFixed(2)}%</span>` +
      `<span>${player.meta.symbol}</span>` +
      `<span>${tr.pnl >= 0 ? '+' : ''}${tr.pnl.toFixed(2)}$</span></div>`).join('');
  }
  const d = player.delta;
  $('vol-line').innerHTML =
    `Σ ${DomUI.fmtQty(player.sessionVolume)} · Δ <span style="color:var(--${d >= 0 ? 'bid' : 'ask'})">${d >= 0 ? '+' : '−'}${DomUI.fmtQty(Math.abs(d))}</span>`;
}

// ---------------------------------------------------------------- утилиты

function setText(id, t) { $(id).textContent = t; }
function sleep(ms) { return new Promise((r) => setTimeout(r, ms)); }
function debounce(fn, ms) {
  let t;
  return (...a) => { clearTimeout(t); t = setTimeout(() => fn(...a), ms); };
}
function fmtTime(ts) {
  const d = new Date(ts);
  return d.toTimeString().slice(0, 8) + '.' + String(d.getMilliseconds()).padStart(3, '0').slice(0, 1);
}
function fmtDur(ms) {
  const m = Math.round(ms / 60000);
  return m >= 60 ? `${Math.floor(m / 60)}ч ${m % 60}м` : `${m}м`;
}
function fmtNum(n) {
  if (n == null) return '—';
  if (n >= 1e6) return (n / 1e6).toFixed(1) + ' млн';
  if (n >= 1e3) return (n / 1e3).toFixed(0) + ' тыс';
  return String(n);
}
function fmtBytes(b) {
  if (b >= 1e9) return (b / 1e9).toFixed(1) + ' ГБ';
  if (b >= 1e6) return (b / 1e6).toFixed(0) + ' МБ';
  if (b >= 1e3) return (b / 1e3).toFixed(0) + ' КБ';
  return b + ' Б';
}
