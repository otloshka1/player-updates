// Запись живого рынка: полный стакан + лента сделок.
// Биржи: Binance фьючерсы (fut), Binance спот (spot), Bybit перпы, OKX свопы.
// Пишем чанками по 60 секунд; каждый чанк начинается со снимка книги.
'use strict';

class Recorder {
  constructor(exchange, symbol, tick, step, onStatus) {
    this.ex = exchange;
    this.symbol = symbol.toUpperCase();
    this.tick = tick; this.step = step;
    this.onStatus = onStatus || (() => {});
    this.book = new PlayerEngine.Book(tick);
    this.lines = [];
    this.chunks = [];
    this.seq = 0;
    this.chunkStart = null;
    this.start_ts = null;
    this.last_ts = null;
    this.bytes = 0;
    this.nTrades = 0; this.nDepth = 0;
    this.state = 'idle';
    this._depthBuf = [];
    this._lastU = null;
    this._synced = false;
    this._stopRequested = false;
    const d = new Date();
    const pad = (x) => String(x).padStart(2, '0');
    const exTag = exchange === 'fut' ? '' : exchange + '-';
    this.id = `rec-${exTag}${this.symbol.replace(/[^A-Za-z0-9_.-]/g, '')}-`
      + `${d.getFullYear()}${pad(d.getMonth() + 1)}${pad(d.getDate())}-`
      + `${pad(d.getHours())}${pad(d.getMinutes())}${pad(d.getSeconds())}`;
    this.dateStr = `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
  }

  start() {
    this.state = 'syncing';
    this._status('подключение…');
    this._closeSockets();
    const s = this.symbol.toLowerCase();
    if (this.ex === 'fut') {
      // у Binance-фьючерсов потоки разнесены по маршрутам /public и /market
      this.wsPub = this._connect(
        `wss://fstream.binance.com/public/stream?streams=${s}@depth@100ms`, () => this._sync());
      this.wsMkt = this._connect(
        `wss://fstream.binance.com/market/stream?streams=${s}@aggTrade`);
    } else if (this.ex === 'spot') {
      this.wsPub = this._connect(
        `wss://stream.binance.com:9443/stream?streams=${s}@depth@100ms/${s}@aggTrade`,
        () => this._sync());
    } else if (this.ex === 'bybit') {
      this.wsPub = this._connect('wss://stream.bybit.com/v5/public/linear', () => {
        this.wsPub.send(JSON.stringify({
          op: 'subscribe',
          args: [`orderbook.500.${this.symbol}`, `publicTrade.${this.symbol}`],
        }));
        this._status('жду снимок стакана…');
      });
      this._pingTimer = setInterval(() => {
        try { this.wsPub.send(JSON.stringify({ op: 'ping' })); } catch (e) {}
      }, 20000);
    } else if (this.ex === 'okx') {
      this.wsPub = this._connect('wss://ws.okx.com:8443/ws/v5/public', () => {
        this.wsPub.send(JSON.stringify({
          op: 'subscribe',
          args: [{ channel: 'books', instId: this.symbol },
                 { channel: 'trades', instId: this.symbol }],
        }));
        this._status('жду снимок стакана…');
      });
      this._pingTimer = setInterval(() => {
        try { this.wsPub.send('ping'); } catch (e) {}
      }, 25000);
    }
    if (!this._statTimer) {
      this._statTimer = setInterval(() => {
        if (this.state === 'recording') this._status('запись идёт');
      }, 1000);
    }
  }

  _connect(url, onOpen) {
    const ws = new WebSocket(url);
    ws.onopen = () => { if (onOpen) onOpen(); };
    ws.onmessage = (m) => {
      if (m.data === 'pong') return;
      try { this._onMsg(JSON.parse(m.data)); } catch (e) {}
    };
    ws.onerror = () => { if (this.state !== 'stopped') this._status('ошибка WebSocket, жду переподключения…'); };
    ws.onclose = () => {
      if (this._stopRequested || this.state === 'stopped') return;
      this._status('связь оборвалась, переподключаюсь…');
      this._synced = false; this._depthBuf = []; this._lastU = null;
      this.state = 'syncing';
      setTimeout(() => { if (!this._stopRequested) this.start(); }, 1500);
    };
    return ws;
  }

  _closeSockets() {
    for (const w of [this.wsPub, this.wsMkt]) {
      if (w) { w.onclose = null; w.onmessage = null; try { w.close(); } catch (e) {} }
    }
    this.wsPub = this.wsMkt = null;
    if (this._pingTimer) { clearInterval(this._pingTimer); this._pingTimer = null; }
  }

  // ---- снапшот для Binance (fut/spot) через REST-прокси
  async _sync() {
    try {
      const r = await fetch(`/api/depth?symbol=${encodeURIComponent(this.symbol)}&ex=${this.ex}`);
      if (!r.ok) throw new Error('snapshot ' + r.status);
      this._snapshot = await r.json();
      this._trySync();
    } catch (e) {
      this.state = 'error';
      this._status('не удалось получить снимок стакана: ' + e.message);
      this._closeSockets();
    }
  }

  _trySync() {
    const snap = this._snapshot;
    if (!snap) return;
    const lid = snap.lastUpdateId;
    this._depthBuf = this._depthBuf.filter((ev) => ev.u > lid);
    const first = this._depthBuf.length ? this._depthBuf[0] : null;
    const ok = this.ex === 'fut'
      ? first && first.U <= lid && lid <= first.u
      : first && first.U <= lid + 1 && lid + 1 <= first.u;
    if (!ok && this._depthBuf.length > 0 && first.U > lid + 1) {
      // снапшот устарел относительно буфера — берём заново
      this._snapshot = null;
      this._sync();
      return;
    }
    if (!first) return; // ждём событие для стыковки
    const t = snap.T || snap.E || Date.now();
    this.book.applySnapshot(snap.bids, snap.asks);
    this.start_ts = this.start_ts || t;
    this.chunkStart = t;
    this._push({ t, y: 's', b: snap.bids.map(([p, q]) => [+p, +q]), a: snap.asks.map(([p, q]) => [+p, +q]) });
    let prev = null;
    for (const ev of this._depthBuf) {
      this._applyDepthBinance(ev);
      prev = ev.u;
    }
    this._lastU = prev !== null ? prev : lid;
    this._depthBuf = [];
    this._synced = true;
    this.state = 'recording';
    this._status('запись идёт');
    this._snapshot = null;
  }

  _onMsg(msg) {
    if (this.ex === 'fut' || this.ex === 'spot') return this._onBinance(msg);
    if (this.ex === 'bybit') return this._onBybit(msg);
    if (this.ex === 'okx') return this._onOkx(msg);
  }

  // ---- Binance fut/spot
  _onBinance(msg) {
    const d = msg.data;
    if (!d || !d.e) return;
    if (d.e === 'depthUpdate') {
      if (!this._synced) {
        this._depthBuf.push(d);
        if (this._depthBuf.length > 2000) this._depthBuf.splice(0, 1000);
        this._trySync();
        return;
      }
      const cont = this.ex === 'fut' ? d.pu === this._lastU : d.U === this._lastU + 1;
      if (this._lastU !== null && !cont) {
        this._synced = false; this._depthBuf = [d]; this._lastU = null;
        this._status('разрыв потока, пересинхронизация…');
        this._sync();
        return;
      }
      this._lastU = d.u;
      this._applyDepthBinance(d);
    } else if (d.e === 'aggTrade') {
      if (!this._synced) return;
      this.nTrades++;
      this._push({ t: d.T, y: 't', p: +d.p, q: +d.q, m: d.m ? 1 : 0 });
      this._maybeFlush(d.T);
    }
  }

  _applyDepthBinance(d) {
    const b = d.b.map(([p, q]) => [+p, +q]), a = d.a.map(([p, q]) => [+p, +q]);
    this.book.applyDiff(b, a);
    this.nDepth++;
    const t = d.T || d.E;
    this._push({ t, y: 'd', b, a });
    this._maybeFlush(t);
  }

  // ---- Bybit: снапшот и дельты в одном потоке
  _onBybit(msg) {
    if (!msg.topic) return;
    const t = msg.ts || Date.now();
    if (msg.topic.startsWith('orderbook.')) {
      const d = msg.data;
      const b = (d.b || []).map(([p, q]) => [+p, +q]);
      const a = (d.a || []).map(([p, q]) => [+p, +q]);
      if (msg.type === 'snapshot') {
        this.book.applySnapshot(b, a);
        if (!this._synced) {
          this._synced = true;
          this.state = 'recording';
          this.start_ts = this.start_ts || t;
          this.chunkStart = this.chunkStart === null ? t : this.chunkStart;
          this._status('запись идёт');
        }
        this._push({ t, y: 's', b, a });
      } else {
        if (!this._synced) return;
        this.book.applyDiff(b, a);
        this._push({ t, y: 'd', b, a });
      }
      this.nDepth++;
      this._maybeFlush(t);
    } else if (msg.topic.startsWith('publicTrade.')) {
      if (!this._synced) return;
      for (const tr of msg.data || []) {
        this.nTrades++;
        this._push({ t: tr.T, y: 't', p: +tr.p, q: +tr.v, m: tr.S === 'Sell' ? 1 : 0 });
      }
      this._maybeFlush(t);
    }
  }

  // ---- OKX: books (снапшот + апдейты) и trades
  _onOkx(msg) {
    if (!msg.arg || !msg.data) return;
    if (msg.arg.channel === 'books') {
      const d = msg.data[0];
      if (!d) return;
      const t = +d.ts || Date.now();
      const b = (d.bids || []).map((r) => [+r[0], +r[1]]);
      const a = (d.asks || []).map((r) => [+r[0], +r[1]]);
      if (msg.action === 'snapshot') {
        this.book.applySnapshot(b, a);
        if (!this._synced) {
          this._synced = true;
          this.state = 'recording';
          this.start_ts = this.start_ts || t;
          this.chunkStart = this.chunkStart === null ? t : this.chunkStart;
          this._status('запись идёт');
        }
        this._push({ t, y: 's', b, a });
      } else {
        if (!this._synced) return;
        this.book.applyDiff(b, a);
        this._push({ t, y: 'd', b, a });
      }
      this.nDepth++;
      this._maybeFlush(t);
    } else if (msg.arg.channel === 'trades') {
      if (!this._synced) return;
      for (const tr of msg.data) {
        const t = +tr.ts;
        this.nTrades++;
        this._push({ t, y: 't', p: +tr.px, q: +tr.sz, m: tr.side === 'sell' ? 1 : 0 });
        this._maybeFlush(t);
      }
    }
  }

  // ---- общее: буфер, чанки, сохранение
  _push(ev) {
    const line = JSON.stringify(ev);
    this.lines.push(line);
    this.bytes += line.length;
    this.last_ts = ev.t;
  }

  _maybeFlush(t) {
    if (this.chunkStart !== null && t - this.chunkStart >= 60000) this._flush(t);
  }

  async _flush(nextStart) {
    if (!this.lines.length) return;
    const text = this.lines.join('\n') + '\n';
    const startTs = this.chunkStart;
    const seq = this.seq++;
    this.lines = [];
    this.chunkStart = nextStart;
    if (nextStart !== null) {
      const snap = this._bookSnapshot(nextStart);
      const line = JSON.stringify(snap);
      this.lines.push(line);
      this.bytes += line.length;
    }
    this.chunks.push({ seq, start: startTs });
    try {
      let body, gz = false;
      if (typeof CompressionStream !== 'undefined') {
        body = await new Response(
          new Blob([text]).stream().pipeThrough(new CompressionStream('gzip'))
        ).arrayBuffer();
        gz = true;
      } else {
        body = text;
      }
      const r = await fetch(`/api/sessions/${this.id}/chunks/${seq}`, {
        method: 'POST',
        headers: gz ? { 'X-Gzip': '1' } : {},
        body,
      });
      if (!r.ok) throw new Error('HTTP ' + r.status);
    } catch (e) {
      this._status('ошибка сохранения чанка: ' + e.message);
    }
  }

  _bookSnapshot(t) {
    const b = [], a = [];
    for (const [i, q] of this.book.bids) b.push([i * this.tick, q]);
    for (const [i, q] of this.book.asks) a.push([i * this.tick, q]);
    b.sort((x, y) => y[0] - x[0]); a.sort((x, y) => x[0] - y[0]);
    return { t, y: 's', b: b.slice(0, 1000), a: a.slice(0, 1000) };
  }

  async stop() {
    this._stopRequested = true;
    this.state = 'stopped';
    if (this._statTimer) { clearInterval(this._statTimer); this._statTimer = null; }
    this._closeSockets();
    await this._flush(null);
    if (!this.chunks.length) { this._status('нечего сохранять'); return null; }
    const meta = {
      symbol: this.symbol, mode: 'rec', date: this.dateStr, l1: true,
      exchange: this.ex,
      start: this.start_ts, end: this.last_ts,
      chunks: this.chunks, tick: this.tick, step: this.step,
      events: this.nTrades + this.nDepth,
    };
    const r = await fetch(`/api/sessions/${this.id}/finish`, {
      method: 'POST', body: JSON.stringify(meta),
    });
    if (!r.ok) { this._status('не удалось сохранить сессию'); return null; }
    this._status('сессия сохранена');
    return this.id;
  }

  _status(msg) { this.onStatus(msg, this); }
}

window.LiveRecorder = Recorder;
