// Свечной график: предрассчитанные свечи сессии (минутки + секунды) и живая
// свеча из ленты. ТФ 1с–1ч, пан перетаскиванием, зум колесом, маркеры сделок.
'use strict';

class ChartView {
  constructor(canvas) {
    this.canvas = canvas;
    this.ctx = canvas.getContext('2d');
    this.tfSec = 60;        // таймфрейм, секунд
    this.baseM = null;      // минутки всей сессии [[t,o,h,l,c,v],...]
    this.baseS = null;      // секундные свечи всей сессии
    this.candlesM = [];     // фолбэк-история, если base не загрузился
    this.candlesS = [];
    this.liveM = null;      // текущая незавершённая минутка
    this.liveS = null;      // текущая незавершённая секунда
    this.candleW = 7;       // зум: ширина свечи, px
    this.offset = 0;        // пан: на сколько свечей отъехали от правого края
    this.yScale = 1;        // вертикальное сжатие шкалы цены (1 = автоподбор)
    this.histBase = {};     // tfSec -> свечи истории до начала сессии (ТФ от 1м)
    this.sessionStart = 0;  // начало сессии — свечи истории не пересекают его
    this.tool = null;       // инструмент рисования: 'h' | 't' | null
    this.magnet = 2;        // магнит: 0 выкл, 1 слабый, 2 сильный
    this.drawings = [];     // {type:'h',p} | {type:'t',t1,p1,t2,p2}
    this.symbol = null;     // для сохранения линий по символу
    this._pendingLine = null;
    this._mouse = null;
    this._xmap = null;      // координатные преобразования последнего кадра
    this._lastTotal = 0;
    this._dpr = 1;
    this._bindEvents();
  }

  setSymbol(sym) {
    this.symbol = sym;
    this.histBase = {};
    try {
      this.drawings = JSON.parse(localStorage.getItem('playerDrawings:' + sym) || '[]');
    } catch (e) { this.drawings = []; }
    this._pendingLine = null;
  }

  _saveDrawings() {
    if (!this.symbol) return;
    try {
      localStorage.setItem('playerDrawings:' + this.symbol, JSON.stringify(this.drawings));
    } catch (e) {}
  }

  resize() {
    const r = this.canvas.parentElement.getBoundingClientRect();
    this._dpr = window.devicePixelRatio || 1;
    this.canvas.width = Math.floor(r.width * this._dpr);
    this.canvas.height = Math.floor(r.height * this._dpr);
    this.canvas.style.width = r.width + 'px';
    this.canvas.style.height = r.height + 'px';
  }

  setBase(data) {
    if (!data) { this.baseM = this.baseS = null; return; }
    if (Array.isArray(data)) { this.baseM = data.length ? data : null; this.baseS = null; }
    else {
      this.baseM = data.m && data.m.length ? data.m : null;
      this.baseS = data.s && data.s.length ? data.s : null;
    }
  }

  setTf(sec) { this.tfSec = sec; this.offset = 0; }

  reset() {
    this.candlesM = [];
    this.candlesS = [];
    this.liveM = null;
    this.liveS = null;
    this.offset = 0;
  }

  // ---- координаты кадра (заполняются в draw)
  _pxToPrice(y) {
    const m = this._xmap;
    return m ? m.lo + (1 - y / m.plotH) * (m.hi - m.lo) : 0;
  }
  _pxToCandle(x) {
    const m = this._xmap;
    if (!m || !m.cs.length) return null;
    const i = Math.max(0, Math.min(m.cs.length - 1, Math.round((x - m.xoff - m.cw / 2) / m.cw)));
    return { i, t: m.cs[i].t, x: m.xoff + i * m.cw + m.cw / 2 };
  }
  _tToX(t) {
    const m = this._xmap;
    if (!m || !m.cs.length) return null;
    // линейная интерполяция по индексу ближайшей свечи
    let lo = 0, hi = m.cs.length - 1;
    while (lo < hi) { const mid = (lo + hi) >> 1; if (m.cs[mid].t < t) lo = mid + 1; else hi = mid; }
    const i = lo + (t - m.cs[lo].t) / m.tfMs;
    return m.xoff + i * m.cw + m.cw / 2;
  }

  /** Точка размещения с учётом магнита: прилипает к хай/лоу ближайшей свечи.
   *  Слабый магнит — радиус 14px, сильный — 48px. */
  _snapPoint(x, y) {
    const m = this._xmap;
    const cnd = this._pxToCandle(x);
    let p = this._pxToPrice(y);
    let t = cnd ? cnd.t : 0;
    if (this.magnet > 0 && cnd && m) {
      const radius = this.magnet === 2 ? 48 : 14;
      const py = (pp) => m.plotH - ((pp - m.lo) / (m.hi - m.lo)) * m.plotH;
      // сильный магнит смотрит и на соседние свечи
      const span = this.magnet === 2 ? 2 : 0;
      let best = null;
      for (let di = -span; di <= span; di++) {
        const i = cnd.i + di;
        if (i < 0 || i >= m.cs.length) continue;
        const c = m.cs[i];
        for (const pp of [c.h, c.l]) {
          const d = Math.abs(py(pp) - y) + Math.abs(di) * 4;
          if (d < radius && (!best || d < best.d)) best = { d, p: pp, i };
        }
      }
      if (best) {
        p = best.p;
        t = m.cs[best.i].t;
        return { t, p, x: m.xoff + best.i * m.cw + m.cw / 2 };
      }
    }
    return { t, p, x: cnd ? cnd.x : x };
  }

  /** Удалить линию рядом с точкой (правый клик). Вернёт true, если удалили. */
  _deleteNear(x, y) {
    const m = this._xmap;
    if (!m) return false;
    const py = (pp) => m.plotH - ((pp - m.lo) / (m.hi - m.lo)) * m.plotH;
    for (let i = this.drawings.length - 1; i >= 0; i--) {
      const d = this.drawings[i];
      let dist = Infinity;
      if (d.type === 'h') dist = Math.abs(py(d.p) - y);
      else {
        const x1 = this._tToX(d.t1), x2 = this._tToX(d.t2);
        const y1 = py(d.p1), y2 = py(d.p2);
        if (x1 != null && x2 != null && Math.abs(x2 - x1) > 1) {
          const k = (y2 - y1) / (x2 - x1);
          const yl = y1 + k * (x - x1);
          dist = Math.abs(yl - y);
        }
      }
      if (dist < 8) {
        this.drawings.splice(i, 1);
        this._saveDrawings();
        return true;
      }
    }
    return false;
  }

  _bindEvents() {
    const c = this.canvas;
    let dragging = false, moved = false, startX = 0, startY = 0, startOffset = 0, startYScale = 1;
    this.measure = null; // линейка процентов: зажать колёсико и тянуть
    c.addEventListener('mousedown', (e) => {
      if (e.button === 1) { // средняя кнопка — измерение процентов
        e.preventDefault();
        const r = c.getBoundingClientRect();
        this.measure = { y0: e.clientY - r.top, y1: e.clientY - r.top };
        return;
      }
      if (e.button !== 0) return;
      dragging = true; moved = false;
      startX = e.clientX; startY = e.clientY;
      startOffset = this.offset; startYScale = this.yScale;
    });
    c.addEventListener('click', (e) => {
      if (moved || !this.tool) return;
      const r = c.getBoundingClientRect();
      const pt = this._snapPoint(e.clientX - r.left, e.clientY - r.top);
      if (!pt.t && pt.p === 0) return;
      if (this.tool === 'h') {
        // лучевой уровень: от точки установки только вправо
        this.drawings.push({ type: 'h', p: pt.p, t: pt.t });
        this.tool = null;
      } else if (this.tool === 't') {
        if (!this._pendingLine) {
          this._pendingLine = { t1: pt.t, p1: pt.p };
        } else {
          this.drawings.push({ type: 't', t1: this._pendingLine.t1, p1: this._pendingLine.p1,
                               t2: pt.t, p2: pt.p });
          this._pendingLine = null;
          this.tool = null;
        }
      }
      this._saveDrawings();
      if (this.onToolDone) this.onToolDone();
    });
    c.addEventListener('contextmenu', (e) => {
      e.preventDefault();
      const r = c.getBoundingClientRect();
      if (this.tool) { this.tool = null; this._pendingLine = null; if (this.onToolDone) this.onToolDone(); return; }
      this._deleteNear(e.clientX - r.left, e.clientY - r.top);
    });
    c.addEventListener('auxclick', (e) => e.preventDefault());
    window.addEventListener('mousemove', (e) => {
      const r = c.getBoundingClientRect();
      this._mouse = { x: e.clientX - r.left, y: e.clientY - r.top };
      if (this.measure) {
        this.measure.y1 = e.clientY - r.top;
        return;
      }
      if (!dragging) return;
      if (Math.abs(e.clientX - startX) + Math.abs(e.clientY - startY) > 3) moved = true;
      if (this.tool) return; // в режиме рисования не панорамируем
      // горизонталь — прокрутка истории (вправо — пустое поле), вертикаль — сжатие цены
      const d = (e.clientX - startX) / this.candleW;
      const minOff = -Math.floor((this._nVis || 40) * 0.7); // запас пустого поля справа
      this.offset = Math.max(minOff, Math.min(this._lastTotal - 5, Math.round(startOffset + d)));
      const dy = e.clientY - startY;
      this.yScale = Math.max(1, Math.min(10, startYScale * Math.exp(dy / 140)));
    });
    window.addEventListener('mouseup', (e) => {
      if (e.button === 1) this.measure = null;
      dragging = false;
    });
    c.addEventListener('dblclick', () => { this.offset = 0; this.yScale = 1; });
    c.addEventListener('wheel', (e) => {
      e.preventDefault();
      const k = e.deltaY < 0 ? 1.15 : 1 / 1.15;
      this.candleW = Math.max(3, Math.min(22, this.candleW * k));
    }, { passive: false });
  }

  onTrade(ev) {
    const st = Math.floor(ev.t / 1000) * 1000;
    const mt = Math.floor(ev.t / 60000) * 60000;
    if (!this.liveS || this.liveS.t !== st) {
      if (this.liveS && !this.baseS) {
        if (st < this.liveS.t) this.candlesS = [];
        else {
          this.candlesS.push(this.liveS);
          if (this.candlesS.length > 6000) this.candlesS.splice(0, 2000);
        }
      }
      this.liveS = { t: st, o: ev.p, h: ev.p, l: ev.p, c: ev.p, v: 0 };
    }
    if (!this.liveM || this.liveM.t !== mt) {
      if (this.liveM && !this.baseM) {
        if (mt < this.liveM.t) this.candlesM = [];
        else {
          this.candlesM.push(this.liveM);
          if (this.candlesM.length > 3000) this.candlesM.splice(0, 1000);
        }
      }
      this.liveM = { t: mt, o: ev.p, h: ev.p, l: ev.p, c: ev.p, v: 0 };
    }
    for (const c of [this.liveS, this.liveM]) {
      if (ev.p > c.h) c.h = ev.p;
      if (ev.p < c.l) c.l = ev.p;
      c.c = ev.p;
      c.v += ev.q;
    }
  }

  /** Источник данных под текущий ТФ: предрассчитанная база или фолбэк. */
  _feed() {
    if (this.tfSec < 60) {
      if (this.baseS) return { arr: this.baseS, unit: 1000, live: this.liveS, isArr: true };
      return { arr: this.candlesS, unit: 1000, live: this.liveS, isArr: false };
    }
    if (this.baseM) return { arr: this.baseM, unit: 60000, live: this.liveM, isArr: true };
    return { arr: this.candlesM, unit: 60000, live: this.liveM, isArr: false };
  }

  /** Последние maxCount бакетов ТФ на момент simTime, без будущего. */
  _buckets(player, maxCount) {
    const tf = this.tfSec * 1000;
    const now = player.simTime;
    const { arr, unit, live, isArr } = this._feed();
    const minT = Math.floor(now / tf) * tf - maxCount * tf;
    // бинарный поиск первого элемента с t >= minT
    let lo = 0, hi = arr.length;
    const tAt = (i) => (isArr ? arr[i][0] : arr[i].t);
    while (lo < hi) { const mid = (lo + hi) >> 1; if (tAt(mid) < minT) lo = mid + 1; else hi = mid; }
    const out = new Map();
    // история до начала сессии с Binance — на всех ТФ от 1 минуты
    if (this.tfSec >= 60 && this.histBase[this.tfSec]) {
      for (const k of this.histBase[this.tfSec]) {
        // свечи, пересекающие старт сессии, не берём — их строит сама сессия
        if (this.sessionStart && k[0] + tf > this.sessionStart) continue;
        out.set(k[0], { t: k[0], o: k[1], h: k[2], l: k[3], c: k[4], v: k[5] });
      }
    }
    const put = (t, o, h, l, c, v) => {
      const bt = Math.floor(t / tf) * tf;
      const b = out.get(bt);
      if (!b) out.set(bt, { t: bt, o, h, l, c, v });
      else {
        if (h > b.h) b.h = h;
        if (l < b.l) b.l = l;
        b.c = c; b.v += v;
      }
    };
    for (let i = lo; i < arr.length; i++) {
      const t = tAt(i);
      if (t + unit > now) break; // только завершённые периоды
      if (isArr) put(t, arr[i][1], arr[i][2], arr[i][3], arr[i][4], arr[i][5]);
      else put(t, arr[i].o, arr[i].h, arr[i].l, arr[i].c, arr[i].v);
    }
    // живая свеча — незавершённый период (если база её ещё не покрыла)
    if (live && live.t >= minT && live.t + unit > now - unit) put(live.t, live.o, live.h, live.l, live.c, live.v);
    let res = [...out.values()].sort((a, b) => a.t - b.t);
    // секундные ТФ: до начала сессии субминутных данных нет — подмешиваем
    // минутную историю слева как контекст, когда окно дотянулось до старта
    if (this.tfSec < 60 && this.histBase[60] && this.sessionStart) {
      const earliest = res.length ? res[0].t : now;
      if (earliest <= this.sessionStart + 5 * tf) {
        const hist = this.histBase[60].filter((k) => k[0] < this.sessionStart);
        const need = Math.max(0, maxCount - res.length);
        const tail = need > 0 ? hist.slice(-need) : [];
        const bars = tail.map((k) => ({ t: k[0], o: k[1], h: k[2], l: k[3], c: k[4], v: k[5] }));
        res = bars.concat(res);
      }
    }
    return res;
  }

  draw(player, sim) {
    const ctx = this.ctx, dpr = this._dpr;
    const W = this.canvas.width / dpr, H = this.canvas.height / dpr;
    ctx.save();
    ctx.scale(dpr, dpr);
    ctx.clearRect(0, 0, W, H);

    const css = getComputedStyle(document.documentElement);
    const C = (n) => css.getPropertyValue(n).trim();
    const cUp = C('--bid'), cDown = C('--ask'), cDim = C('--dim'), cGrid = C('--grid');

    const axisW = 64, axisH = 18;
    const plotW = W - axisW, volH = Math.floor(H * 0.16);
    const plotH = H - volH - axisH;

    const cw = this.candleW;
    const bodyW = Math.max(1, Math.round(cw * 0.7));
    const nVis = Math.max(10, Math.floor(plotW / cw));
    this._nVis = nVis;
    const all = this._buckets(player, nVis + Math.max(0, this.offset) + 2);
    this._lastTotal = all.length;
    // offset < 0 — отъехали правее «сейчас», справа пустое поле
    const endIdx = all.length - this.offset;
    const emptyRight = Math.max(0, endIdx - all.length);
    const cs = all.slice(Math.max(0, endIdx - nVis), Math.min(endIdx, all.length));
    if (!cs.length) {
      ctx.fillStyle = cDim;
      ctx.font = '12px -apple-system, sans-serif';
      ctx.textAlign = 'center';
      ctx.fillText('график построится по ходу реплея', W / 2, H / 2);
      ctx.restore();
      return;
    }

    let hi = -Infinity, lo = Infinity, maxV = 0;
    for (const c of cs) { hi = Math.max(hi, c.h); lo = Math.min(lo, c.l); maxV = Math.max(maxV, c.v); }
    const pad = (hi - lo) * 0.06 || hi * 0.001 || 1;
    hi += pad; lo -= pad;
    if (this.yScale > 1) { // вертикальное сжатие: расширяем диапазон вокруг середины
      const mid = (hi + lo) / 2, half = ((hi - lo) / 2) * this.yScale;
      hi = mid + half; lo = mid - half;
    }
    const py = (p) => plotH - ((p - lo) / (hi - lo)) * plotH;
    const xoff = plotW - (cs.length + emptyRight) * cw;
    const xOf = (i) => xoff + i * cw;
    this._xmap = { cs, xoff, cw, lo, hi, plotH, plotW, tfMs: this.tfSec * 1000 };

    // сетка и шкала цены
    ctx.font = '10px "SF Mono", Menlo, monospace';
    ctx.textBaseline = 'middle';
    const steps = 6;
    for (let i = 0; i <= steps; i++) {
      const p = lo + ((hi - lo) * i) / steps;
      const y = py(p);
      ctx.strokeStyle = cGrid;
      ctx.beginPath(); ctx.moveTo(0, y + 0.5); ctx.lineTo(plotW, y + 0.5); ctx.stroke();
      ctx.fillStyle = cDim;
      ctx.textAlign = 'left';
      ctx.fillText(fmtPx(p, player.tick), plotW + 4, y);
    }

    // свечи + объёмы
    const labelEvery = Math.max(1, Math.ceil(64 / cw));
    for (let i = 0; i < cs.length; i++) {
      const c = cs[i];
      const x = xOf(i);
      if (x < -cw) continue;
      const up = c.c >= c.o;
      ctx.strokeStyle = ctx.fillStyle = up ? cUp : cDown;
      const mid = x + cw / 2 - 0.5;
      ctx.beginPath();
      ctx.moveTo(mid, py(c.h));
      ctx.lineTo(mid, py(c.l));
      ctx.stroke();
      const yo = py(c.o), yc = py(c.c);
      ctx.fillRect(x + (cw - bodyW) / 2, Math.min(yo, yc), bodyW, Math.max(1, Math.abs(yc - yo)));
      if (maxV > 0 && c.v > 0) {
        const vh = Math.max(1, (c.v / maxV) * (volH - 4));
        ctx.globalAlpha = 0.55;
        ctx.fillRect(x + (cw - bodyW) / 2, plotH + volH - vh, bodyW, vh);
        ctx.globalAlpha = 1;
      }
      if (i % labelEvery === 0) {
        const d = new Date(c.t);
        ctx.fillStyle = cDim;
        ctx.textAlign = 'center';
        const lbl = this.tfSec >= 86400
          ? `${String(d.getDate()).padStart(2, '0')}.${String(d.getMonth() + 1).padStart(2, '0')}`
          : this.tfSec < 60 ? d.toTimeString().slice(0, 8) : d.toTimeString().slice(0, 5);
        ctx.fillText(lbl, Math.max(20, mid), H - axisH / 2);
      }
    }

    // мои сделки: ▲ покупка, ▼ продажа
    if (sim && sim.fills.length) {
      const tf = this.tfSec * 1000;
      const idxOf = new Map();
      for (let i = 0; i < cs.length; i++) idxOf.set(cs[i].t, i);
      ctx.lineWidth = 1;
      for (const f of sim.fills.slice(-300)) {
        const i = idxOf.get(Math.floor(f.t / tf) * tf);
        if (i == null) continue;
        const x = xOf(i) + cw / 2 - 0.5;
        const y = Math.max(4, Math.min(plotH - 4, py(f.price)));
        ctx.fillStyle = f.side === 'B' ? cUp : cDown;
        ctx.strokeStyle = '#0c0e12';
        ctx.beginPath();
        if (f.side === 'B') {
          ctx.moveTo(x, y - 6); ctx.lineTo(x - 4.5, y + 2); ctx.lineTo(x + 4.5, y + 2);
        } else {
          ctx.moveTo(x, y + 6); ctx.lineTo(x - 4.5, y - 2); ctx.lineTo(x + 4.5, y - 2);
        }
        ctx.closePath();
        ctx.fill();
        ctx.stroke();
      }
    }

    // линия и метка последней цены (в режиме слежения)
    if (this.offset <= 0 && player.lastPrice > 0
        && player.lastPrice >= lo && player.lastPrice <= hi) {
      const y = py(player.lastPrice);
      const last = cs[cs.length - 1];
      const up = last.c >= last.o;
      ctx.strokeStyle = up ? cUp : cDown;
      ctx.setLineDash([3, 3]);
      ctx.beginPath(); ctx.moveTo(0, y + 0.5); ctx.lineTo(plotW, y + 0.5); ctx.stroke();
      ctx.setLineDash([]);
      ctx.fillStyle = up ? cUp : cDown;
      ctx.fillRect(plotW, y - 8, axisW, 16);
      ctx.fillStyle = '#0c0e12';
      ctx.textAlign = 'left';
      ctx.font = 'bold 10px "SF Mono", Menlo, monospace';
      ctx.fillText(fmtPx(player.lastPrice, player.tick), plotW + 4, y);
    }
    // ---- уровни и наклонные линии пользователя
    if (this.drawings.length || this._pendingLine || this.tool) {
      ctx.save();
      ctx.beginPath();
      ctx.rect(0, 0, plotW, plotH);
      ctx.clip();
      const cDraw = C('--last');
      ctx.font = 'bold 10px "SF Mono", Menlo, monospace';
      for (const d of this.drawings) {
        ctx.strokeStyle = cDraw;
        ctx.lineWidth = 1;
        if (d.type === 'h') {
          const y = py(d.p);
          if (y < -20 || y > plotH + 20) continue;
          // луч: от точки установки только вправо
          let x1 = 0;
          if (d.t) {
            const xx = this._tToX(d.t);
            if (xx != null) x1 = Math.max(0, xx);
          }
          if (x1 > plotW) continue;
          ctx.beginPath(); ctx.moveTo(x1, y + 0.5); ctx.lineTo(plotW, y + 0.5); ctx.stroke();
          ctx.fillStyle = cDraw;
          ctx.beginPath();
          ctx.arc(Math.max(x1, 2), y + 0.5, 2.5, 0, Math.PI * 2);
          ctx.fill();
          const lbl = fmtPx(d.p, player.tick);
          ctx.fillRect(plotW - ctx.measureText(lbl).width - 10, y - 7, ctx.measureText(lbl).width + 8, 14);
          ctx.fillStyle = '#0c0e12';
          ctx.textAlign = 'left';
          ctx.fillText(lbl, plotW - ctx.measureText(lbl).width - 6, y);
        } else {
          const x1 = this._tToX(d.t1), x2 = this._tToX(d.t2);
          if (x1 == null || x2 == null || x1 === x2) continue;
          const y1 = py(d.p1), y2 = py(d.p2);
          ctx.beginPath(); ctx.moveTo(x1, y1); ctx.lineTo(x2, y2); ctx.stroke();
          // продление наклонной до правого края пунктиром
          const k = (y2 - y1) / (x2 - x1);
          const xe = plotW, ye = y2 + k * (xe - x2);
          ctx.setLineDash([4, 4]);
          ctx.beginPath(); ctx.moveTo(x2, y2); ctx.lineTo(xe, ye); ctx.stroke();
          ctx.setLineDash([]);
        }
      }
      // незавершённая наклонная — от первой точки к курсору
      if (this._pendingLine && this._mouse) {
        const x1 = this._tToX(this._pendingLine.t1);
        if (x1 != null) {
          const pt = this._snapPoint(this._mouse.x, this._mouse.y);
          ctx.strokeStyle = cDraw;
          ctx.setLineDash([3, 3]);
          ctx.beginPath();
          ctx.moveTo(x1, py(this._pendingLine.p1));
          ctx.lineTo(pt.x, py(pt.p));
          ctx.stroke();
          ctx.setLineDash([]);
        }
      }
      // призрак уровня под курсором: видно, куда встанет
      if (this.tool && this._mouse) {
        const pt = this._snapPoint(this._mouse.x, this._mouse.y);
        const y = py(pt.p);
        ctx.fillStyle = cDraw;
        ctx.beginPath();
        ctx.arc(pt.x, y, 3.5, 0, Math.PI * 2);
        ctx.fill();
        if (this.tool === 'h') {
          ctx.globalAlpha = 0.55;
          ctx.strokeStyle = cDraw;
          ctx.setLineDash([5, 4]);
          ctx.beginPath(); ctx.moveTo(pt.x, y + 0.5); ctx.lineTo(plotW, y + 0.5); ctx.stroke();
          ctx.setLineDash([]);
          const lbl = fmtPx(pt.p, player.tick);
          ctx.fillStyle = cDraw;
          ctx.fillRect(plotW - ctx.measureText(lbl).width - 10, y - 7,
                       ctx.measureText(lbl).width + 8, 14);
          ctx.fillStyle = '#0c0e12';
          ctx.textAlign = 'left';
          ctx.fillText(lbl, plotW - ctx.measureText(lbl).width - 6, y);
          ctx.globalAlpha = 1;
        }
      }
      ctx.restore();
    }

    // ---- линейка процентов (зажато колёсико)
    if (this.measure) {
      const yToPrice = (y) => lo + (1 - y / plotH) * (hi - lo);
      const p0 = yToPrice(this.measure.y0);
      const p1 = yToPrice(Math.min(this.measure.y1, plotH));
      const pct = p0 !== 0 ? ((p1 - p0) / p0) * 100 : 0;
      const col = pct >= 0 ? cUp : cDown;
      ctx.globalAlpha = 0.12;
      ctx.fillStyle = col;
      ctx.fillRect(0, Math.min(this.measure.y0, this.measure.y1),
                   plotW, Math.abs(this.measure.y1 - this.measure.y0));
      ctx.globalAlpha = 1;
      ctx.strokeStyle = col;
      ctx.setLineDash([4, 3]);
      for (const yy of [this.measure.y0, this.measure.y1]) {
        ctx.beginPath(); ctx.moveTo(0, yy + 0.5); ctx.lineTo(plotW, yy + 0.5); ctx.stroke();
      }
      ctx.setLineDash([]);
      const label = `${pct >= 0 ? '+' : ''}${pct.toFixed(2)}%  (${fmtPx(p0, player.tick)} → ${fmtPx(p1, player.tick)})`;
      ctx.font = 'bold 11px "SF Mono", Menlo, monospace';
      const tw = ctx.measureText(label).width + 12;
      const bx = Math.max(4, Math.min(plotW - tw - 4, plotW / 2 - tw / 2));
      const by = Math.max(4, this.measure.y1 - 24);
      ctx.fillStyle = 'rgba(12, 14, 18, 0.92)';
      ctx.strokeStyle = col;
      ctx.beginPath();
      ctx.roundRect(bx, by, tw, 18, 4);
      ctx.fill();
      ctx.stroke();
      ctx.fillStyle = col;
      ctx.textAlign = 'left';
      ctx.textBaseline = 'middle';
      ctx.fillText(label, bx + 6, by + 9.5);
    }

    // индикатор отъезда от «сейчас»
    if (this.offset > 0) {
      ctx.fillStyle = cDim;
      ctx.font = '10px -apple-system, sans-serif';
      ctx.textAlign = 'right';
      ctx.fillText('история · двойной клик — к текущему', plotW - 6, 12);
    }
    ctx.restore();
  }
}

function fmtPx(p, tick) {
  const dec = Math.max(0, -Math.floor(Math.log10(tick || 0.1) + 1e-9));
  return p.toFixed(Math.min(dec, 6));
}

window.ChartUI = { ChartView };
