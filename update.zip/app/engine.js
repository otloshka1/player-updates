// Движок реплея: книга заявок, часы симуляции, ленивая подгрузка чанков.
'use strict';

/** Книга заявок. Цены храним целыми индексами тика: idx = round(price / tick). */
class Book {
  constructor(tick) {
    this.tick = tick;
    this.bids = new Map(); // idx -> qty
    this.asks = new Map();
    this.bestBid = -1;
    this.bestAsk = -1;
    this.real = false;     // true = реальная глубина (записанная сессия)
  }
  px(idx) { return idx * this.tick; }
  idx(price) { return Math.round(price / this.tick); }

  clear() {
    this.bids.clear(); this.asks.clear();
    this.bestBid = -1; this.bestAsk = -1;
  }

  applySnapshot(b, a) {
    this.clear();
    this.real = true;
    for (const [p, q] of b) this._set(this.bids, this.idx(+p), +q);
    for (const [p, q] of a) this._set(this.asks, this.idx(+p), +q);
    this.bestBid = this.bids.size ? Math.max(...this.bids.keys()) : -1;
    this.bestAsk = this.asks.size ? Math.min(...this.asks.keys()) : -1;
  }

  applyDiff(b, a) {
    for (const [p, q] of b) {
      const i = this.idx(+p), qq = +q;
      this._set(this.bids, i, qq);
      if (qq > 0 && i > this.bestBid) this.bestBid = i;
      if (qq === 0 && i === this.bestBid) this.bestBid = this._scanDown(this.bids, i);
    }
    for (const [p, q] of a) {
      const i = this.idx(+p), qq = +q;
      this._set(this.asks, i, qq);
      if (qq > 0 && (this.bestAsk === -1 || i < this.bestAsk)) this.bestAsk = i;
      if (qq === 0 && i === this.bestAsk) this.bestAsk = this._scanUp(this.asks, i);
    }
  }

  /** Псевдо-L1 для исторического режима (по принтам / bookTicker). */
  setEstL1(bidIdx, askIdx, bidQty, askQty) {
    this.real = false;
    this.bestBid = bidIdx; this.bestAsk = askIdx;
    this.estBidQty = bidQty || 0; this.estAskQty = askQty || 0;
  }

  qtyAt(side, idx) {
    if (!this.real) {
      if (side === 'B') return idx === this.bestBid ? this.estBidQty : 0;
      return idx === this.bestAsk ? this.estAskQty : 0;
    }
    return (side === 'B' ? this.bids : this.asks).get(idx) || 0;
  }

  _set(map, idx, qty) { qty > 0 ? map.set(idx, qty) : map.delete(idx); }
  _scanDown(map, from) {
    for (let i = from - 1; i > from - 5000; i--) if (map.has(i)) return i;
    return map.size ? Math.max(...map.keys()) : -1;
  }
  _scanUp(map, from) {
    for (let i = from + 1; i < from + 5000; i++) if (map.has(i)) return i;
    return map.size ? Math.min(...map.keys()) : -1;
  }
}

/** Ленивая подгрузка чанков сессии с сервера. */
class ChunkSource {
  constructor(meta) {
    this.meta = meta;
    this.cache = new Map();   // seq -> events[]
    this.loading = new Map(); // seq -> Promise
  }
  chunkIdxForTime(ts) {
    const cs = this.meta.chunks;
    let lo = 0, hi = cs.length - 1, ans = 0;
    while (lo <= hi) {
      const mid = (lo + hi) >> 1;
      if (cs[mid].start <= ts) { ans = mid; lo = mid + 1; } else hi = mid - 1;
    }
    return ans;
  }
  async get(seq) {
    if (seq < 0 || seq >= this.meta.chunks.length) return null;
    if (this.cache.has(seq)) return this.cache.get(seq);
    if (!this.loading.has(seq)) {
      this.loading.set(seq, (async () => {
        const r = await fetch(`/api/sessions/${this.meta.id}/chunks/${this.meta.chunks[seq].seq}`);
        if (!r.ok) throw new Error('чанк не загрузился: ' + r.status);
        const text = await r.text();
        const events = [];
        let s = 0;
        while (s < text.length) {
          let e = text.indexOf('\n', s);
          if (e === -1) e = text.length;
          if (e > s + 1) events.push(JSON.parse(text.slice(s, e)));
          s = e + 1;
        }
        this.cache.set(seq, events);
        this.loading.delete(seq);
        // держим максимум 6 чанков
        if (this.cache.size > 6) {
          const keys = [...this.cache.keys()].sort((a, b) => a - b);
          for (const k of keys) {
            if (this.cache.size <= 6) break;
            if (k !== seq && Math.abs(k - seq) > 1) this.cache.delete(k);
          }
        }
        return events;
      })());
    }
    return this.loading.get(seq);
  }
  prefetch(seq) {
    if (seq < this.meta.chunks.length && !this.cache.has(seq) && !this.loading.has(seq))
      this.get(seq).catch(() => {});
  }
}

/** Плеер: продвигает время симуляции и применяет события. */
class Player {
  constructor(meta, hooks) {
    this.meta = meta;
    this.hooks = hooks;           // { onTrade(ev), onBookChange() }
    this.src = new ChunkSource(meta);
    this.tick = meta.tick || 0.1;
    this.book = new Book(this.tick);
    this.profile = new Map();     // idx -> {b, s}
    // Река принтов — «змейка»: каждый принт занимает свой слот, новые входят
    // справа и толкают всю ленту влево. Скорость = поток сделок.
    this.river = [];              // хронологически, новые в конце
    this.riverPending = 0;        // невыбранный сдвиг ленты, px (плавно гасится)
    this.riverGroup = 1;          // сжатие стакана — для агрегации по уровню
    this.riverFilterUsd = 0;      // фильтр принтов по объёму, $ (0 = все)
    this.bigLotUsd = 5000;        // порог крупного принта (круглый пузырь), $
    this.delta = 0;               // кумулятивная дельта (покупки - продажи)
    this.simTime = meta.start;
    this.speed = 1;
    this.paused = true;
    this.ended = false;
    this.lastPrice = 0;
    this.lastIdx = -1;
    this.cur = { seq: -1, events: null, ptr: 0 };
    this.waiting = false;
    this.recorded = meta.mode === 'rec';
    this.sessionVolume = 0;
  }

  price(idx) { return idx * this.tick; }

  async init() {
    await this._loadChunk(0);
    // прокрутить до первого события, чтобы стакан/цена сразу появились
    this._fastForward(this.meta.start + 1);
  }

  async _loadChunk(seq) {
    this.waiting = true;
    const events = await this.src.get(seq);
    this.waiting = false;
    if (!events) { this.ended = true; return false; }
    this.cur = { seq, events, ptr: 0 };
    this.src.prefetch(seq + 1);
    return true;
  }

  /** Применить события до момента ts (без ограничения на кадр). */
  _fastForward(ts) {
    while (true) {
      const c = this.cur;
      if (!c.events) return;
      while (c.ptr < c.events.length && c.events[c.ptr].t <= ts) {
        this.apply(c.events[c.ptr++], true);
      }
      if (c.ptr < c.events.length) break;
      const next = c.seq + 1;
      if (next >= this.meta.chunks.length) { this.ended = true; break; }
      if (!this.src.cache.has(next)) { // нужен асинхронный догруз — выходим
        this._pendingFF = ts;
        this._loadChunk(next).then(() => {
          if (this._pendingFF != null) { const t = this._pendingFF; this._pendingFF = null; this._fastForward(t); }
        });
        return;
      }
      this.cur = { seq: next, events: this.src.cache.get(next), ptr: 0 };
      this.src.prefetch(next + 1);
    }
    this.simTime = ts;
  }

  /** Шаг часов: dtMs реального времени. Вызывается из rAF. */
  advance(dtMs) {
    if (this.paused || this.ended || this.waiting || this._pendingFF != null) return;
    // плавный сдвиг змейки: гасим накопленный сдвиг экспоненциально —
    // чем плотнее поток сделок, тем быстрее едет лента.
    // Кап не даёт свежим принтам спрятаться за правым краем при шквале.
    if (this.riverPending > 0.5) {
      this.riverPending = Math.min(
        this.riverPending * Math.exp(-(dtMs * this.speed) / 120), 60);
    } else {
      this.riverPending = 0;
    }
    const target = Math.min(this.simTime + dtMs * this.speed, this.meta.end);
    const c = this.cur;
    if (!c.events) return;
    let budget = 200000; // защита от зависания кадра
    while (c.ptr < c.events.length && c.events[c.ptr].t <= target && budget-- > 0) {
      this.apply(c.events[c.ptr++], false);
    }
    if (c.ptr >= c.events.length) {
      const next = c.seq + 1;
      if (next >= this.meta.chunks.length) {
        this.ended = true; this.simTime = this.meta.end; return;
      }
      if (this.src.cache.has(next)) {
        this.cur = { seq: next, events: this.src.cache.get(next), ptr: 0 };
        this.src.prefetch(next + 1);
      } else {
        this._loadChunk(next); // waiting=true до загрузки
        return;
      }
    }
    // упреждающая подгрузка
    if (c.events.length - c.ptr < 2000) this.src.prefetch(c.seq + 1);
    this.simTime = budget > 0 ? target : c.events[Math.min(c.ptr, c.events.length - 1)].t;
  }

  apply(ev, silent) {
    switch (ev.y) {
      case 't': {
        const idx = this.book.idx(ev.p);
        this.lastPrice = ev.p; this.lastIdx = idx;
        this.sessionVolume += ev.q;
        this.delta += ev.m ? -ev.q : ev.q;
        let pr = this.profile.get(idx);
        if (!pr) { pr = { b: 0, s: 0 }; this.profile.set(idx, pr); }
        ev.m ? pr.s += ev.q : pr.b += ev.q;
        const usd = ev.p * ev.q;
        if (usd >= this.riverFilterUsd) this._riverAdd(ev, idx, usd);
        if (this.hooks.onAnyTrade) this.hooks.onAnyTrade(ev);
        if (!this.recorded && !this.meta.l1) {
          // синтетический L1: бид следует за продажами, аск — за покупками,
          // разрыв спреда виден. Принт сквозь чужую сторону протягивает её.
          const b = this.book;
          if (ev.m) { // агрессивная продажа — бьёт в бид
            let ask = b.bestAsk;
            if (ask === -1 || idx >= ask) ask = idx + 1;
            b.setEstL1(idx, ask);
          } else {    // агрессивная покупка — снимает аск
            let bid = b.bestBid;
            if (bid === -1 || idx <= bid) bid = idx - 1;
            b.setEstL1(bid, idx);
          }
        }
        if (!silent) this.hooks.onTrade(ev);
        break;
      }
      case 'd': this.book.applyDiff(ev.b, ev.a); if (!silent) this.hooks.onBookChange(ev); break;
      case 's': this.book.applySnapshot(ev.b, ev.a); break;
      case 'q': {
        const b = this.book;
        b.setEstL1(b.idx(ev.bp), b.idx(ev.ap), +ev.bq, +ev.aq);
        if (!silent) this.hooks.onBookChange(ev);
        break;
      }
    }
  }

  /** Добавить принт в змейку. Всплеск одной стороны на одном уровне (с учётом
   *  сжатия) агрегируется в один растущий принт. */
  _riverAdd(ev, idx, usd) {
    const g = Math.max(1, this.riverGroup);
    const last = this.river[this.river.length - 1];
    if (last && last.m === ev.m &&
        Math.floor(last.idx / g) === Math.floor(idx / g) &&
        ev.t - last.tEnd <= 250 && ev.t - last.t <= 1500) {
      this.riverPending -= last.w;
      last.usd += usd; last.q += ev.q;
      last.idx = idx; last.tEnd = ev.t;
      last.w = this._slotW(last.usd);
      this.riverPending += last.w;
      return;
    }
    const w = this._slotW(usd);
    this.river.push({ t: ev.t, tEnd: ev.t, idx, usd, q: ev.q, m: ev.m, w });
    this.riverPending += w + 3;
    if (this.river.length > 600) this.river.splice(0, 200);
  }

  /** Ширина слота принта в змейке, px. */
  _slotW(usd) {
    if (this.bigLotUsd > 0 && usd >= this.bigLotUsd) {
      const r = Math.min(16, 9 + 2.5 * Math.log10(usd / this.bigLotUsd + 1));
      return 2 * r;
    }
    const chars = usd >= 1e5 ? 4 : usd >= 1e4 ? 3 : usd >= 1e3 ? 4
      : usd >= 100 ? 3 : usd >= 10 ? 2 : 1;
    return chars * 5.6 + 8;
  }

  /** Смена фильтра: убираем из змейки уже добавленные мелкие принты. */
  setRiverFilter(usd) {
    this.riverFilterUsd = usd;
    if (usd > 0) this.river = this.river.filter((b) => b.usd >= usd);
  }

  async seek(ts) {
    ts = Math.max(this.meta.start, Math.min(ts, this.meta.end));
    const seq = this.src.chunkIdxForTime(ts);
    const wasPaused = this.paused;
    this.paused = true;
    this.ended = false;
    this._pendingFF = null;
    // сбрасываем производное состояние
    this.book.clear();
    this.profile.clear();
    this.river.length = 0;
    this.riverPending = 0;
    this.sessionVolume = 0;
    this.delta = 0;
    await this._loadChunk(seq);
    this._fastForward(ts);
    this.simTime = ts;
    this.paused = wasPaused;
  }
}

window.PlayerEngine = { Book, ChunkSource, Player };
