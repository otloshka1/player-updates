// Запись живого рынка: полный стакан (depth@100ms) + лента (aggTrade) с Binance Futures.
// Пишем чанками по 60 секунд на сервер; каждый чанк начинается со снимка книги.
'use strict';

class Recorder {
  constructor(symbol, tick, step, onStatus) {
    this.symbol = symbol.toUpperCase();
    this.tick = tick; this.step = step;
    this.onStatus = onStatus || (() => {});
    this.book = new PlayerEngine.Book(tick);
    this.lines = [];
    this.chunks = [];
    this.seq = 0;
    this.chunkStart = null;
    this.start_ts = null;
    this.last_ts = null;
    this.bytes = 0;
    this.nTrades = 0; this.nDepth = 0;
    this.state = 'idle'; // idle | syncing | recording | stopped | error
    this._depthBuf = [];
    this._lastU = null;
    this._synced = false;
    this._stopRequested = false;
    const d = new Date();
    const pad = (x) => String(x).padStart(2, '0');
    this.id = `rec-${this.symbol}-${d.getFullYear()}${pad(d.getMonth() + 1)}${pad(d.getDate())}-${pad(d.getHours())}${pad(d.getMinutes())}${pad(d.getSeconds())}`;
    this.dateStr = `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
  }

  start() {
    // с 2026 г. фьючерсные потоки Binance разнесены по маршрутам:
    // @depth — /public, @aggTrade — /market; нужны два соединения
    const s = this.symbol.toLowerCase();
    this.state = 'syncing';
    this._status('подключение…');
    this._closeSockets();
    this.wsPub = this._connect(
      `wss://fstream.binance.com/public/stream?streams=${s}@depth@100ms`, true);
    this.wsMkt = this._connect(
      `wss://fstream.binance.com/market/stream?streams=${s}@aggTrade`, false);
    if (!this._statTimer) {
      this._statTimer = setInterval(() => {
        if (this.state === 'recording') this._status('запись идёт');
      }, 1000);
    }
  }

  _connect(url, isPublic) {
    const ws = new WebSocket(url);
    ws.onopen = () => { if (isPublic) { this._status('синхронизация стакана…'); this._sync(); } };
    ws.onmessage = (m) => this._onMsg(JSON.parse(m.data));
    ws.onerror = () => { if (this.state !== 'stopped') this._status('ошибка WebSocket, жду переподключения…'); };
    ws.onclose = () => {
      if (this._stopRequested || this.state === 'stopped') return;
      this._status('связь оборвалась, переподключаюсь…');
      this._synced = false; this._depthBuf = []; this._lastU = null;
      this.state = 'syncing';
      setTimeout(() => { if (!this._stopRequested) this.start(); }, 1500);
    };
    return ws;
  }

  _closeSockets() {
    for (const w of [this.wsPub, this.wsMkt]) {
      if (w) { w.onclose = null; w.onmessage = null; try { w.close(); } catch (_) {} }
    }
    this.wsPub = this.wsMkt = null;
  }

  async _sync() {
    try {
      const r = await fetch(`/api/depth?symbol=${this.symbol}`);
      if (!r.ok) throw new Error('snapshot ' + r.status);
      const snap = await r.json();
      this._snapshot = snap;
      // отбрасываем устаревшие события и ищем стыковку
      this._trySync();
    } catch (e) {
      this.state = 'error';
      this._status('не удалось получить снимок стакана: ' + e.message);
      this._closeSockets();
    }
  }

  _trySync() {
    const snap = this._snapshot;
    if (!snap) return;
    const lid = snap.lastUpdateId;
    this._depthBuf = this._depthBuf.filter(ev => ev.u >= lid);
    const first = this._depthBuf.find(ev => ev.U <= lid && lid <= ev.u);
    if (!first) return; // ждём подходящее событие
    const t = snap.T || snap.E || Date.now();
    this.book.applySnapshot(snap.bids, snap.asks);
    this.start_ts = this.start_ts || t;
    this.chunkStart = t;
    this._push({ t, y: 's', b: snap.bids.map(([p, q]) => [+p, +q]), a: snap.asks.map(([p, q]) => [+p, +q]) });
    let prev = null;
    for (const ev of this._depthBuf) {
      if (ev.u < lid) continue;
      if (prev !== null && ev.pu !== prev) { /* разрыв — редкий случай, продолжаем */ }
      this._applyDepth(ev);
      prev = ev.u;
    }
    this._lastU = prev !== null ? prev : lid;
    this._depthBuf = [];
    this._synced = true;
    this.state = 'recording';
    this._status('запись идёт');
    this._snapshot = null;
  }

  _onMsg(msg) {
    const d = msg.data;
    if (!d || !d.e) return;
    if (d.e === 'depthUpdate') {
      if (!this._synced) {
        this._depthBuf.push(d);
        if (this._depthBuf.length > 2000) this._depthBuf.splice(0, 1000);
        this._trySync();
        return;
      }
      if (this._lastU !== null && d.pu !== this._lastU) {
        // разрыв потока — пересинхронизация
        this._synced = false; this._depthBuf = [d]; this._lastU = null;
        this._status('разрыв потока, пересинхронизация…');
        this._sync();
        return;
      }
      this._lastU = d.u;
      this._applyDepth(d);
    } else if (d.e === 'aggTrade') {
      if (!this._synced) return;
      const t = d.T;
      this.nTrades++;
      this._push({ t, y: 't', p: +d.p, q: +d.q, m: d.m ? 1 : 0 });
      this._maybeFlush(t);
    }
  }

  _applyDepth(d) {
    const b = d.b.map(([p, q]) => [+p, +q]), a = d.a.map(([p, q]) => [+p, +q]);
    this.book.applyDiff(b, a);
    this.nDepth++;
    const t = d.T || d.E;
    this._push({ t, y: 'd', b, a });
    this._maybeFlush(t);
  }

  _push(ev) {
    const line = JSON.stringify(ev);
    this.lines.push(line);
    this.bytes += line.length;
    this.last_ts = ev.t;
  }

  _maybeFlush(t) {
    if (this.chunkStart !== null && t - this.chunkStart >= 60000) this._flush(t);
  }

  async _flush(nextStart) {
    if (!this.lines.length) return;
    const text = this.lines.join('\n') + '\n';
    const startTs = this.chunkStart;
    const seq = this.seq++;
    this.lines = [];
    this.chunkStart = nextStart;
    // новый чанк начинаем со снимка текущей книги
    if (nextStart !== null) {
      const snap = this._bookSnapshot(nextStart);
      const line = JSON.stringify(snap);
      this.lines.push(line);
      this.bytes += line.length;
    }
    this.chunks.push({ seq, start: startTs });
    try {
      let body, gz = false;
      if (typeof CompressionStream !== 'undefined') {
        body = await new Response(
          new Blob([text]).stream().pipeThrough(new CompressionStream('gzip'))
        ).arrayBuffer();
        gz = true;
      } else {
        body = text;
      }
      const r = await fetch(`/api/sessions/${this.id}/chunks/${seq}`, {
        method: 'POST',
        headers: gz ? { 'X-Gzip': '1' } : {},
        body,
      });
      if (!r.ok) throw new Error('HTTP ' + r.status);
    } catch (e) {
      this._status('ошибка сохранения чанка: ' + e.message);
    }
  }

  _bookSnapshot(t) {
    const b = [], a = [];
    for (const [i, q] of this.book.bids) b.push([i * this.tick, q]);
    for (const [i, q] of this.book.asks) a.push([i * this.tick, q]);
    b.sort((x, y) => y[0] - x[0]); a.sort((x, y) => x[0] - y[0]);
    return { t, y: 's', b: b.slice(0, 1000), a: a.slice(0, 1000) };
  }

  async stop() {
    this._stopRequested = true;
    this.state = 'stopped';
    if (this._statTimer) { clearInterval(this._statTimer); this._statTimer = null; }
    this._closeSockets();
    await this._flush(null);
    if (!this.chunks.length) { this._status('нечего сохранять'); return null; }
    const meta = {
      symbol: this.symbol, mode: 'rec', date: this.dateStr, l1: true,
      start: this.start_ts, end: this.last_ts,
      chunks: this.chunks, tick: this.tick, step: this.step,
      events: this.nTrades + this.nDepth,
    };
    const r = await fetch(`/api/sessions/${this.id}/finish`, {
      method: 'POST', body: JSON.stringify(meta),
    });
    if (!r.ok) { this._status('не удалось сохранить сессию'); return null; }
    this._status('сессия сохранена');
    return this.id;
  }

  _status(msg) { this.onStatus(msg, this); }
}

window.LiveRecorder = Recorder;
