// Отрисовка DOM-стакана в стиле Vataga: [профиль] [трейл пузырей] [мои ордера] [размер] [цена]
// + полноширинные маркеры лучших bid/ask с долларовым объёмом.
'use strict';

const ROW_H = 16;
const W_PROFILE = 58, W_ORDERS = 40, W_SIZE = 88, W_PRICE = 70;

class DomView {
  constructor(canvas) {
    this.canvas = canvas;
    this.ctx = canvas.getContext('2d');
    this.centerIdx = -1;
    this.autoCenter = true;
    this.autoCenterEnabled = true; // настройка: следовать ли за ценой
    this.group = 1;
    this.flashMs = 700;
    this.unitUsd = true;   // объём в пузырях/ленте: $ или монеты
    this.hover = null;     // позиция курсора для подсказки с процентом
    this.scaleUsd = 0;     // полная шкала гистограммы уровня, $ (0 = авто)
    this.dens1Usd = 0;     // фильтр плотностей 1: подсветка уровней от X $
    this.dens1Clr = '#f5a623';
    this.dens2Usd = 0;     // фильтр плотностей 2 (крупнее)
    this.dens2Clr = '#c544f0';
    // тема стакана: фон, зоны покупок/продаж, цвет кластера (гистограммы), цвет цифр
    this.theme = { bg: null, zoneAsk: null, zoneBid: null, bar: null, digits: null };
    this.clrPrintBuy = '';  // цвета принтов в реке (пусто = цвета покупок/продаж)
    this.clrPrintSell = '';
    this.getLevels = null; // () => уровни с графика для отображения в стакане
    this._dpr = 1;
  }

  resize() {
    const r = this.canvas.parentElement.getBoundingClientRect();
    this._dpr = window.devicePixelRatio || 1;
    this.canvas.width = Math.floor(r.width * this._dpr);
    this.canvas.height = Math.floor(r.height * this._dpr);
    this.canvas.style.width = r.width + 'px';
    this.canvas.style.height = r.height + 'px';
  }

  rows() { return Math.floor(this.canvas.height / this._dpr / ROW_H); }
  gOf(idx) { return Math.floor(idx / this.group); }
  gBase(gIdx) { return gIdx * this.group; }

  _xs() {
    const W = this.canvas.width / this._dpr;
    const xPrice = W - W_PRICE;
    const xSize = xPrice - W_SIZE;
    const xOrders = xSize - W_ORDERS;
    return { W, xProfile: 0, xTrail: W_PROFILE, xOrders, xSize, xPrice };
  }

  hitTest(x, y) {
    const row = Math.floor(y / ROW_H);
    const gi = this.gOf(this.centerIdx) + (this.rows() >> 1) - row;
    const idx = this.gBase(gi);
    const { xOrders, xSize, xPrice } = this._xs();
    let col = 'trail';
    if (x >= xPrice) col = 'price';
    else if (x >= xSize) col = 'size';
    else if (x >= xOrders) col = 'orders';
    else if (x < W_PROFILE) col = 'profile';
    return { col, gIdx: gi, idx };
  }

  scroll(deltaRows) {
    this.autoCenter = false;
    this.centerIdx += deltaRows * this.group;
  }
  recenter(player) {
    this.autoCenter = true;
    if (player.lastIdx > 0) this.centerIdx = player.lastIdx;
  }

  draw(player, sim) {
    const ctx = this.ctx, dpr = this._dpr;
    const { W, xTrail, xOrders, xSize, xPrice } = this._xs();
    const H = this.canvas.height / dpr;
    ctx.save();
    ctx.scale(dpr, dpr);
    ctx.clearRect(0, 0, W, H);
    if (this.theme.bg) {
      ctx.fillStyle = this.theme.bg;
      ctx.fillRect(0, 0, W, H);
    }

    const css = getComputedStyle(document.documentElement);
    const C = (n) => css.getPropertyValue(n).trim();
    const cBid = C('--bid'), cAsk = C('--ask'), cText = C('--text'),
          cDim = C('--dim'), cGrid = C('--grid'), cProfile = C('--profile');

    const book = player.book, tick = player.tick, g = this.group;
    if (this.centerIdx < 0 && player.lastIdx > 0) this.centerIdx = player.lastIdx;
    if (this.autoCenter && this.autoCenterEnabled && player.lastIdx > 0) {
      const drift = Math.abs(player.lastIdx - this.centerIdx);
      if (drift > (this.rows() * g) / 6) this.centerIdx = player.lastIdx;
    }
    if (this.centerIdx < 0) { ctx.restore(); return; }

    const n = this.rows();
    const topG = this.gOf(this.centerIdx) + (n >> 1);
    const dec = Math.max(0, -Math.floor(Math.log10(tick * g) + 1e-9));
    const bestBidG = book.bestBid >= 0 ? this.gOf(book.bestBid) : null;
    const bestAskG = book.bestAsk >= 0 ? this.gOf(book.bestAsk) : null;

    // агрегация уровней видимого диапазона
    const lvls = [];
    let maxQty = 0, maxProf = 0;
    for (let r = 0; r < n; r++) {
      const gi = topG - r;
      let bq = 0, aq = 0, pb = 0, ps = 0;
      for (let k = 0; k < g; k++) {
        const i = gi * g + k;
        if (book.real) {
          bq += book.bids.get(i) || 0;
          aq += book.asks.get(i) || 0;
        } else {
          if (i === book.bestBid) bq += book.estBidQty || 0;
          if (i === book.bestAsk) aq += book.estAskQty || 0;
        }
        const pr = player.profile.get(i);
        if (pr) { pb += pr.b; ps += pr.s; }
      }
      lvls.push({ gi, bq, aq, pb, ps });
      maxQty = Math.max(maxQty, bq, aq);
      maxProf = Math.max(maxProf, pb + ps);
    }

    ctx.font = '11px "SF Mono", Menlo, monospace';
    ctx.textBaseline = 'middle';

    const myOrders = new Map();
    for (const o of sim.orders) {
      const gi = this.gOf(o.idx);
      if (!myOrders.has(gi)) myOrders.set(gi, []);
      myOrders.get(gi).push(o);
    }
    const myStops = new Map();
    for (const s of sim.stops) {
      const gi = this.gOf(s.idx);
      if (!myStops.has(gi)) myStops.set(gi, []);
      myStops.get(gi).push(s);
    }
    const myPendings = new Map();
    for (const o of sim.pendings) {
      const gi = this.gOf(o.idx);
      if (!myPendings.has(gi)) myPendings.set(gi, []);
      myPendings.get(gi).push(o);
    }
    const posG = sim.pos !== 0 && sim.avg > 0 ? this.gOf(book.idx(sim.avg)) : null;

    // ---- зона PnL: от цены входа до текущей цены, зелёная в плюсе / красная в минусе
    if (posG !== null && player.lastIdx >= 0) {
      const rowEntry = topG - posG;
      const rowLast = topG - this.gOf(player.lastIdx);
      let yTop = (Math.min(rowEntry, rowLast) + 1) * ROW_H;
      let yBot = Math.max(rowEntry, rowLast) * ROW_H;
      yTop = Math.max(0, yTop);
      yBot = Math.min(H, yBot);
      if (yBot > yTop) {
        const u = sim.unrealized();
        ctx.globalAlpha = 0.30;
        ctx.fillStyle = u >= 0 ? C('--pnl-green') : cAsk;
        ctx.fillRect(xSize, yTop, W - xSize, yBot - yTop);
        ctx.globalAlpha = 1;
      }
    }

    for (let r = 0; r < n; r++) {
      const L = lvls[r], y = r * ROW_H, cy = y + ROW_H / 2;
      const isBestAsk = bestAskG !== null && L.gi === bestAskG;
      const isBestBid = bestBidG !== null && L.gi === bestBidG && !isBestAsk;
      const isAskSide = bestAskG !== null && L.gi >= bestAskG;
      const isLast = player.lastIdx >= 0 && this.gOf(player.lastIdx) === L.gi;

      // ---- профиль объёма сессии (текст + полоска)
      if (L.pb + L.ps > 0 && maxProf > 0) {
        const w = Math.max(1, (W_PROFILE - 4) * (L.pb + L.ps) / maxProf);
        ctx.fillStyle = cProfile;
        ctx.fillRect(2, y + 2, w, ROW_H - 4);
        ctx.fillStyle = cDim;
        ctx.textAlign = 'left';
        ctx.fillText(fmtQty(L.pb + L.ps), 4, cy);
      }

      // ---- цветные зоны сторон (тема): аски и биды подкрашены фоном
      if (this.theme.zoneAsk && bestAskG !== null && L.gi >= bestAskG) {
        ctx.fillStyle = this.theme.zoneAsk;
        ctx.fillRect(xSize, y, W - xSize, ROW_H);
      } else if (this.theme.zoneBid && bestBidG !== null && L.gi <= bestBidG) {
        ctx.fillStyle = this.theme.zoneBid;
        ctx.fillRect(xSize, y, W - xSize, ROW_H);
      }

      {
        // ---- размер уровня (шкала: авто или фиксированная в $)
        const qy = isAskSide ? L.aq : L.bq;
        if (qy > 0 && maxQty > 0) {
          const lvlUsd = qy * this.gBase(L.gi) * tick;
          const frac = this.scaleUsd > 0
            ? Math.min(1, lvlUsd / this.scaleUsd)
            : Math.min(1, qy / maxQty);
          const w = Math.max(1, (W_SIZE - 6) * frac);
          // фильтры плотностей: крупные лимитные объёмы — своим цветом
          let dens = null;
          if (this.dens2Usd > 0 && lvlUsd >= this.dens2Usd) dens = this.dens2Clr;
          else if (this.dens1Usd > 0 && lvlUsd >= this.dens1Usd) dens = this.dens1Clr;
          if (dens) {
            ctx.fillStyle = dens;
            ctx.fillRect(xSize, y + 1, W_SIZE, ROW_H - 2);
            ctx.fillStyle = '#0c0e12';
            ctx.font = 'bold 11px "SF Mono", Menlo, monospace';
            ctx.textAlign = 'left';
            ctx.fillText(fmtQty(qy), xSize + 4, cy);
            ctx.font = '11px "SF Mono", Menlo, monospace';
          } else {
            // кластер (гистограмма): цвет из темы или цвет стороны
            ctx.fillStyle = this.theme.bar || (isAskSide ? cAsk : cBid);
            ctx.globalAlpha = this.theme.bar ? 0.75 : 0.15;
            ctx.fillRect(xSize, y + 1, w, ROW_H - 2);
            ctx.globalAlpha = 1;
            ctx.fillStyle = this.theme.digits || (isAskSide ? cAsk : cBid);
            ctx.textAlign = 'left';
            ctx.fillText(fmtQty(qy), xSize + 4, cy);
          }
        }

        // ---- цена
        ctx.textAlign = 'right';
        ctx.fillStyle = isLast ? C('--last') : (this.theme.digits || cDim);
        ctx.fillText((this.gBase(L.gi) * tick).toFixed(dec), xPrice + W_PRICE - 6, cy);
      }

      // ---- мои отложки: пунктирный контур (активация при касании цены)
      const pp = myPendings.get(L.gi);
      if (pp) {
        const bp = pp.filter(o => o.side === 'B').reduce((a, o) => a + o.qty, 0);
        const sp = pp.filter(o => o.side === 'S').reduce((a, o) => a + o.qty, 0);
        ctx.lineWidth = 1.5;
        ctx.setLineDash([3, 2]);
        ctx.font = 'bold 9px "SF Mono", Menlo, monospace';
        ctx.textAlign = 'center';
        if (bp > 0) {
          ctx.strokeStyle = cBid;
          ctx.strokeRect(xOrders + 2.5, y + 2.5, W_ORDERS - 7, ROW_H - 5);
          ctx.fillStyle = cBid;
          ctx.fillText('О·' + fmtQty(bp), xOrders + W_ORDERS / 2 - 1, cy);
        }
        if (sp > 0) {
          ctx.strokeStyle = cAsk;
          ctx.strokeRect(xOrders + 2.5, y + 2.5, W_ORDERS - 7, ROW_H - 5);
          ctx.fillStyle = cAsk;
          ctx.fillText('О·' + fmtQty(sp), xOrders + W_ORDERS / 2 - 1, cy);
        }
        ctx.setLineDash([]);
        ctx.lineWidth = 1;
        ctx.font = '11px "SF Mono", Menlo, monospace';
      }

      // ---- мои стопы: контурные блоки
      const ss = myStops.get(L.gi);
      if (ss) {
        const bq2 = ss.filter(s => s.side === 'B').reduce((a, s) => a + s.qty, 0);
        const sq2 = ss.filter(s => s.side === 'S').reduce((a, s) => a + s.qty, 0);
        ctx.lineWidth = 1.5;
        ctx.font = 'bold 9px "SF Mono", Menlo, monospace';
        ctx.textAlign = 'center';
        if (bq2 > 0) {
          ctx.strokeStyle = cBid;
          ctx.strokeRect(xOrders + 2.5, y + 2.5, W_ORDERS - 7, ROW_H - 5);
          ctx.fillStyle = cBid;
          ctx.fillText('S·' + fmtQty(bq2), xOrders + W_ORDERS / 2 - 1, cy);
        }
        if (sq2 > 0) {
          ctx.strokeStyle = cAsk;
          ctx.strokeRect(xOrders + 2.5, y + 2.5, W_ORDERS - 7, ROW_H - 5);
          ctx.fillStyle = cAsk;
          ctx.fillText('S·' + fmtQty(sq2), xOrders + W_ORDERS / 2 - 1, cy);
        }
        ctx.lineWidth = 1;
        ctx.font = '11px "SF Mono", Menlo, monospace';
      }

      // ---- мои ордера
      const oo = myOrders.get(L.gi);
      if (oo) {
        const buy = oo.filter(o => o.side === 'B').reduce((s, o) => s + o.qty - o.filled, 0);
        const sell = oo.filter(o => o.side === 'S').reduce((s, o) => s + o.qty - o.filled, 0);
        ctx.textAlign = 'right';
        ctx.font = 'bold 10px "SF Mono", Menlo, monospace';
        if (buy > 0) {
          ctx.fillStyle = cBid;
          ctx.fillRect(xOrders + 2, y + 2, W_ORDERS - 6, ROW_H - 4);
          ctx.fillStyle = '#06262d';
          ctx.fillText(fmtQty(buy), xOrders + W_ORDERS - 6, cy);
        }
        if (sell > 0) {
          ctx.fillStyle = cAsk;
          ctx.fillRect(xOrders + 2, y + 2, W_ORDERS - 6, ROW_H - 4);
          ctx.fillStyle = '#2d0a10';
          ctx.fillText(fmtQty(sell), xOrders + W_ORDERS - 6, cy);
        }
        ctx.font = '11px "SF Mono", Menlo, monospace';
      }
      if (posG === L.gi) {
        // позиция: линия входа через стакан + блок PnL (зелёный плюс/красный минус)
        const u = sim.unrealized();
        const cPnl = u >= 0 ? C('--pnl-green') : cAsk;
        ctx.globalAlpha = 0.55;
        ctx.fillStyle = cPnl;
        ctx.fillRect(0, y + ROW_H - 1, W, 1);
        ctx.globalAlpha = 1;
        ctx.fillStyle = cPnl;
        ctx.fillRect(xOrders + 1, y + 1, W_ORDERS - 2, ROW_H - 2);
        ctx.fillStyle = '#0c0e12';
        ctx.textAlign = 'center';
        ctx.font = 'bold 9px "SF Mono", Menlo, monospace';
        const au = Math.abs(u);
        const pnlTxt = (u >= 0 ? '+' : '−') + (au < 100 ? au.toFixed(1) : fmtCompact(au));
        ctx.fillText(pnlTxt, xOrders + W_ORDERS / 2, cy);
        ctx.font = '11px "SF Mono", Menlo, monospace';
      }
    }

    // ---- лучшие bid/ask: каждая сторона — ровно одна полная плашка.
    // Если сжатие схлопывает их в одну строку, бид рисуем строкой ниже —
    // размер плашек постоянный, разрыв спреда всегда виден по реальным ценам.
    if (book.bestAsk >= 0 && book.bestBid >= 0) {
      const tickDec = Math.max(0, -Math.floor(Math.log10(tick) + 1e-9));
      const showUsd = book.real || player.meta.l1;
      const askRow = topG - this.gOf(book.bestAsk);
      let bidRow = topG - this.gOf(book.bestBid);
      if (bidRow <= askRow) bidRow = askRow + 1;
      const drawSpreadBar = (row, color, usd, px) => {
        if (row < 0 || row >= n) return;
        const yy = row * ROW_H;
        ctx.fillStyle = color;
        ctx.fillRect(xSize, yy + 1, W - xSize, ROW_H - 2);
        ctx.fillStyle = '#0c0e12';
        ctx.font = 'bold 11px "SF Mono", Menlo, monospace';
        ctx.textAlign = 'right';
        ctx.fillText((showUsd ? fmtUsd(usd) + '  ' : '') + px.toFixed(tickDec),
                     xPrice + W_PRICE - 6, yy + ROW_H / 2);
      };
      const askPx = book.bestAsk * tick, bidPx = book.bestBid * tick;
      drawSpreadBar(askRow, cAsk,
        (book.real ? (book.asks.get(book.bestAsk) || 0) : (book.estAskQty || 0)) * askPx, askPx);
      drawSpreadBar(bidRow, cBid,
        (book.real ? (book.bids.get(book.bestBid) || 0) : (book.estBidQty || 0)) * bidPx, bidPx);
      ctx.font = '11px "SF Mono", Menlo, monospace';
    }

    // ---- змейка принтов: жёсткий «поезд» слотов, новые входят справа
    // и толкают всю ленту влево; наложения исключены по построению
    const xRight = xOrders - 4, xLeft = W_PROFILE + 2;
    if (xRight - xLeft > 40 && player.river.length) {
      ctx.save();
      ctx.beginPath();
      ctx.rect(xLeft, 0, xRight - xLeft, H);
      ctx.clip();
      const drawList = []; // от новых к старым
      // визуальный сдвиг ограничен, чтобы свежие принты не прятались за краем
      let edge = xRight + Math.min(player.riverPending, 60);
      for (let i = player.river.length - 1; i >= 0; i--) {
        const b = player.river[i];
        const right = edge, left = edge - b.w;
        edge = left - 3;
        if (right < xLeft) break;
        const row = topG - this.gOf(b.idx);
        if (row < -2 || row > n + 2) continue;
        drawList.push({ b, xc: (left + right) / 2, cy: row * ROW_H + ROW_H / 2 });
      }
      // нить пути цены сквозь принты (хронологически)
      if (drawList.length > 1) {
        ctx.strokeStyle = 'rgba(220, 228, 240, 0.22)';
        ctx.lineWidth = 1;
        ctx.beginPath();
        ctx.moveTo(drawList[drawList.length - 1].xc, drawList[drawList.length - 1].cy);
        for (let i = drawList.length - 2; i >= 0; i--) ctx.lineTo(drawList[i].xc, drawList[i].cy);
        ctx.stroke();
      }
      ctx.font = 'bold 9px "SF Mono", Menlo, monospace';
      ctx.textAlign = 'center';
      const printBuy = this.clrPrintBuy || cBid;
      const printSell = this.clrPrintSell || cAsk;
      const hideUsd = player.hideValueUsd || 0;
      for (const { b, xc, cy } of drawList) {
        ctx.fillStyle = b.m ? printSell : printBuy;
        // мелкие принты: кружок (продажа) / квадратик (покупка) без цифр
        if (hideUsd > 0 && b.usd < hideUsd) {
          if (b.m) {
            ctx.beginPath();
            ctx.arc(xc, cy, 4, 0, Math.PI * 2);
            ctx.fill();
          } else {
            ctx.fillRect(xc - 3.5, cy - 3.5, 7, 7);
          }
          continue;
        }
        const label = this.unitUsd ? fmtCompact(b.usd) : fmtQty(b.q);
        const big = player.bigLotUsd > 0 && b.usd >= player.bigLotUsd;
        if (big) {
          ctx.beginPath();
          ctx.arc(xc, cy, b.w / 2, 0, Math.PI * 2);
          ctx.fill();
        } else {
          ctx.fillRect(xc - b.w / 2, cy - 6, b.w, 12);
        }
        ctx.fillStyle = '#0c0e12';
        ctx.fillText(label, xc, cy + 0.5);
      }
      ctx.restore();
      ctx.font = '11px "SF Mono", Menlo, monospace';
    }

    // ---- сетка
    ctx.strokeStyle = cGrid;
    ctx.lineWidth = 1;
    for (const x of [W_PROFILE, xOrders, xSize, xPrice]) {
      ctx.beginPath(); ctx.moveTo(x + 0.5, 0); ctx.lineTo(x + 0.5, H); ctx.stroke();
    }

    // ---- уровни, поставленные на графике, видны и в стакане
    if (this.getLevels) {
      const lvls2 = this.getLevels();
      if (lvls2 && lvls2.length) {
        ctx.strokeStyle = C('--last');
        ctx.lineWidth = 1;
        ctx.setLineDash([5, 4]);
        for (const d of lvls2) {
          if (d.type !== 'h') continue;
          const row = topG - this.gOf(Math.round(d.p / tick));
          if (row < 0 || row >= n) continue;
          const yy = row * ROW_H + ROW_H / 2;
          ctx.beginPath();
          ctx.moveTo(W_PROFILE, yy + 0.5);
          ctx.lineTo(W, yy + 0.5);
          ctx.stroke();
        }
        ctx.setLineDash([]);
      }
    }

    if (!book.real) {
      ctx.fillStyle = cDim;
      ctx.textAlign = 'left';
      ctx.font = '10px -apple-system, sans-serif';
      ctx.fillText('≈ стакан приблизительный (история)', 6, H - 9);
    }

    // ---- наведение: процент от текущей цены до уровня под курсором
    if (this.hover && player.lastPrice > 0) {
      const row = Math.floor(this.hover.y / ROW_H);
      const gi = topG - row;
      const hp = this.gBase(gi) * tick;
      const pct = ((hp - player.lastPrice) / player.lastPrice) * 100;
      const label = `${pct >= 0 ? '+' : ''}${pct.toFixed(2)}%`;
      ctx.font = 'bold 11px "SF Mono", Menlo, monospace';
      const tw = ctx.measureText(label).width + 12;
      let bx = Math.min(this.hover.x + 14, W - tw - 4);
      let by = Math.max(4, this.hover.y - 24);
      ctx.fillStyle = 'rgba(12, 14, 18, 0.92)';
      ctx.strokeStyle = pct >= 0 ? cBid : cAsk;
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.roundRect(bx, by, tw, 18, 4);
      ctx.fill();
      ctx.stroke();
      ctx.fillStyle = pct >= 0 ? cBid : cAsk;
      ctx.textAlign = 'left';
      ctx.fillText(label, bx + 6, by + 9.5);
      // подсветка строки под курсором
      ctx.globalAlpha = 0.06;
      ctx.fillStyle = '#ffffff';
      ctx.fillRect(0, row * ROW_H, W, ROW_H);
      ctx.globalAlpha = 1;
    }
    ctx.restore();
  }
}

function fmtQty(q) {
  if (q >= 1e6) return (q / 1e6).toFixed(1) + 'M';
  if (q >= 1e4) return Math.round(q / 1e3) + 'K';
  if (q >= 1e3) return (q / 1e3).toFixed(1) + 'K';
  if (q >= 100) return Math.round(q).toString();
  if (q >= 1) return (+q.toFixed(2)).toString();
  return (+q.toFixed(4)).toString();
}

function fmtUsd(v) {
  if (v >= 1e6) return (v / 1e6).toFixed(1) + 'M$';
  if (v >= 1e3) return Math.round(v / 1e3) + 'K$';
  return Math.round(v) + '$';
}

function fmtCompact(v) {
  if (v >= 1e6) return (v / 1e6).toFixed(1) + 'M';
  if (v >= 1e4) return Math.round(v / 1e3) + 'K';
  if (v >= 1e3) return (v / 1e3).toFixed(1) + 'K';
  return String(Math.round(v));
}

window.DomUI = { DomView, fmtQty, fmtUsd, fmtCompact };
