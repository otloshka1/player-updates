#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Плеер — локальный сервер тренажёра реплея рынка (аналог Player из Tiger Trade).
Только стандартная библиотека Python, без зависимостей.

Запуск:  python3 server.py   (или двойной клик по Плеер.command)
"""
import csv
import gzip
import io
import json
import os
import re
import shutil
import socket
import sys
import threading
import time
import urllib.request
import urllib.error
import webbrowser
import zipfile
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse, parse_qs

ROOT = os.path.dirname(os.path.abspath(__file__))
APP_DIR = os.path.join(ROOT, "app")
# внутри .app-бандла данные храним в пользовательской папке, иначе рядом
if ".app/Contents/" in ROOT and sys.platform == "darwin":
    DATA_DIR = os.path.expanduser("~/Library/Application Support/PlayerTrainer")
else:
    DATA_DIR = os.path.join(ROOT, "data")
SESS_DIR = os.path.join(DATA_DIR, "sessions")
CACHE_DIR = os.path.join(DATA_DIR, "cache")

BINANCE_VISION = "https://data.binance.vision/data/futures/um/daily"
FAPI = "https://fapi.binance.com"

VERSION = "2.6.0"
# URL манифеста обновлений (version.json: {"version": "...", "zip": "...", "notes": "..."}).
UPDATE_MANIFEST = "https://raw.githubusercontent.com/otloshka1/player-updates/main/version.json"

CHUNK_MS = 5 * 60 * 1000  # размер чанка исторической сессии

MIME = {
    ".html": "text/html; charset=utf-8",
    ".js": "text/javascript; charset=utf-8",
    ".css": "text/css; charset=utf-8",
    ".json": "application/json; charset=utf-8",
    ".png": "image/png",
    ".svg": "image/svg+xml",
    ".wav": "audio/wav",
}

jobs = {}      # id -> {"status": "...", "progress": 0..100, "error": str|None, "session": id|None}
jobs_lock = threading.Lock()
_exchange_info_cache = {"ts": 0, "data": None}


def ensure_dirs():
    for d in (DATA_DIR, SESS_DIR, CACHE_DIR):
        os.makedirs(d, exist_ok=True)


def http_get(url, timeout=120):
    req = urllib.request.Request(url, headers={"User-Agent": "player-macbook/1.0"})
    return urllib.request.urlopen(req, timeout=timeout)


def http_post(url, payload, timeout=30):
    data = json.dumps(payload).encode()
    req = urllib.request.Request(url, data=data, method="POST",
                                 headers={"User-Agent": "player-macbook/1.0",
                                          "Content-Type": "application/json"})
    return urllib.request.urlopen(req, timeout=timeout)


def http_head_size(url):
    """Возвращает размер файла по URL или None, если файла нет."""
    try:
        req = urllib.request.Request(url, method="HEAD",
                                     headers={"User-Agent": "player-macbook/1.0"})
        with urllib.request.urlopen(req, timeout=30) as r:
            return int(r.headers.get("Content-Length") or 0)
    except urllib.error.HTTPError:
        return None
    except Exception:
        return None


def download_to(url, dest, job_id=None, p_from=0, p_to=50):
    """Скачивает файл с прогрессом в jobs[job_id]['progress']."""
    tmp = dest + ".part"
    with http_get(url, timeout=600) as r:
        total = int(r.headers.get("Content-Length") or 0)
        done = 0
        with open(tmp, "wb") as f:
            while True:
                buf = r.read(1024 * 256)
                if not buf:
                    break
                f.write(buf)
                done += len(buf)
                if job_id and total:
                    set_job(job_id, progress=p_from + (p_to - p_from) * done / total)
    os.replace(tmp, dest)


def set_job(job_id, **kw):
    with jobs_lock:
        jobs.setdefault(job_id, {})
        jobs[job_id].update(kw)


def get_exchange_info():
    """Список USDT-M перпетуалов с шагом цены/лота. Кэш 12 часов."""
    now = time.time()
    cache_file = os.path.join(CACHE_DIR, "exchangeInfo.json")
    if _exchange_info_cache["data"] and now - _exchange_info_cache["ts"] < 12 * 3600:
        return _exchange_info_cache["data"]
    raw = None
    try:
        with http_get(FAPI + "/fapi/v1/exchangeInfo", timeout=30) as r:
            raw = json.loads(r.read().decode())
        with open(cache_file, "w") as f:
            json.dump(raw, f)
    except Exception:
        if os.path.exists(cache_file):
            with open(cache_file) as f:
                raw = json.load(f)
        else:
            raise
    out = []
    for s in raw.get("symbols", []):
        if s.get("contractType") != "PERPETUAL":
            continue
        tick = step = None
        for flt in s.get("filters", []):
            if flt.get("filterType") == "PRICE_FILTER":
                tick = float(flt["tickSize"])
            if flt.get("filterType") == "LOT_SIZE":
                step = float(flt["stepSize"])
        out.append({"symbol": s["symbol"], "tick": tick, "step": step,
                    "status": s.get("status")})
    out.sort(key=lambda x: x["symbol"])
    _exchange_info_cache["data"] = out
    _exchange_info_cache["ts"] = now
    return out


def find_tick(symbol):
    try:
        for s in get_exchange_info():
            if s["symbol"] == symbol:
                return s["tick"], s["step"]
    except Exception:
        pass
    return None, None


# ---------------------------------------------------------------- биржи
# ex: 'fut' (Binance фьючерсы), 'spot' (Binance спот), 'bybit' (перпы), 'okx' (свопы)

_ex_symbols_cache = {}

# все поддерживаемые биржи; только первые 4 умеют импорт дня (есть публичные дампы)
ALL_EX = ("fut", "spot", "bybit", "okx", "okxs", "bybits",
          "aster", "mexc", "gate", "bitget", "kucoin", "hl",
          "gates", "bitgets", "kucoins")
IMPORT_EX = ("fut", "spot", "bybit", "okx", "bybits", "okxs")


def get_symbols_ex(ex):
    """Список инструментов биржи: [{symbol, tick, step}]. Кэш 12ч."""
    now = time.time()
    c = _ex_symbols_cache.get(ex)
    if c and now - c["ts"] < 12 * 3600:
        return c["data"]
    out = []
    if ex == "fut":
        out = get_exchange_info()
    elif ex == "spot":
        with http_get("https://api.binance.com/api/v3/exchangeInfo", timeout=30) as r:
            raw = json.loads(r.read().decode())
        for s in raw.get("symbols", []):
            if s.get("status") != "TRADING":
                continue
            tick = step = None
            for flt in s.get("filters", []):
                if flt.get("filterType") == "PRICE_FILTER":
                    tick = float(flt["tickSize"])
                if flt.get("filterType") == "LOT_SIZE":
                    step = float(flt["stepSize"])
            out.append({"symbol": s["symbol"], "tick": tick, "step": step})
    elif ex == "bybit":
        cursor = ""
        for _ in range(5):
            url = ("https://api.bybit.com/v5/market/instruments-info"
                   f"?category=linear&limit=1000&cursor={cursor}")
            with http_get(url, timeout=30) as r:
                raw = json.loads(r.read().decode())
            res = raw.get("result", {})
            for s in res.get("list", []):
                if s.get("status") != "Trading":
                    continue
                out.append({"symbol": s["symbol"],
                            "tick": float(s["priceFilter"]["tickSize"]),
                            "step": float(s["lotSizeFilter"]["qtyStep"])})
            cursor = res.get("nextPageCursor") or ""
            if not cursor:
                break
    elif ex in ("okx", "okxs"):
        it = "SWAP" if ex == "okx" else "SPOT"
        with http_get(f"https://www.okx.com/api/v5/public/instruments?instType={it}",
                      timeout=30) as r:
            raw = json.loads(r.read().decode())
        for s in raw.get("data", []):
            if s.get("state") != "live":
                continue
            out.append({"symbol": s["instId"], "tick": float(s["tickSz"]),
                        "step": float(s["lotSz"]), "mult": 1})
    elif ex == "bybits":
        cursor = ""
        for _ in range(3):
            url = ("https://api.bybit.com/v5/market/instruments-info"
                   f"?category=spot&limit=1000&cursor={cursor}")
            with http_get(url, timeout=30) as r:
                raw = json.loads(r.read().decode())
            res = raw.get("result", {})
            for s in res.get("list", []):
                if s.get("status") != "Trading":
                    continue
                out.append({"symbol": s["symbol"],
                            "tick": float(s["priceFilter"]["tickSize"]),
                            "step": float(s["lotSizeFilter"]["basePrecision"])})
            cursor = res.get("nextPageCursor") or ""
            if not cursor:
                break
    elif ex == "aster":
        with http_get("https://fapi.asterdex.com/fapi/v1/exchangeInfo", timeout=30) as r:
            raw = json.loads(r.read().decode())
        for s in raw.get("symbols", []):
            if s.get("contractType") != "PERPETUAL" or s.get("status") != "TRADING":
                continue
            tick = step = None
            for flt in s.get("filters", []):
                if flt.get("filterType") == "PRICE_FILTER":
                    tick = float(flt["tickSize"])
                if flt.get("filterType") == "LOT_SIZE":
                    step = float(flt["stepSize"])
            out.append({"symbol": s["symbol"], "tick": tick, "step": step})
    elif ex == "mexc":
        with http_get("https://contract.mexc.com/api/v1/contract/detail", timeout=30) as r:
            raw = json.loads(r.read().decode())
        for s in raw.get("data", []):
            cs = float(s.get("contractSize") or 1)
            out.append({"symbol": s["symbol"], "tick": float(s["priceUnit"]),
                        "step": cs, "mult": cs})
    elif ex == "gate":
        with http_get("https://api.gateio.ws/api/v4/futures/usdt/contracts", timeout=30) as r:
            raw = json.loads(r.read().decode())
        for s in raw:
            if s.get("in_delisting"):
                continue
            qm = float(s.get("quanto_multiplier") or 1) or 1
            out.append({"symbol": s["name"], "tick": float(s["order_price_round"]),
                        "step": qm, "mult": qm})
    elif ex == "bitget":
        with http_get("https://api.bitget.com/api/v2/mix/market/contracts?productType=usdt-futures",
                      timeout=30) as r:
            raw = json.loads(r.read().decode())
        for s in raw.get("data", []):
            pp = int(s.get("pricePlace") or 0)
            step_end = float(s.get("priceEndStep") or 1)
            out.append({"symbol": s["symbol"], "tick": step_end * (10 ** -pp),
                        "step": float(s.get("sizeMultiplier") or 0.001), "mult": 1})
    elif ex == "kucoin":
        with http_get("https://api-futures.kucoin.com/api/v1/contracts/active", timeout=30) as r:
            raw = json.loads(r.read().decode())
        for s in raw.get("data", []):
            m = float(s.get("multiplier") or 1)
            out.append({"symbol": s["symbol"], "tick": float(s["tickSize"]),
                        "step": abs(m), "mult": abs(m)})
    elif ex == "gates":
        with http_get("https://api.gateio.ws/api/v4/spot/currency_pairs", timeout=30) as r:
            raw = json.loads(r.read().decode())
        for s in raw:
            if s.get("trade_status") != "tradable" or s.get("quote") != "USDT":
                continue
            pp = int(s.get("precision") or 4)
            ap = int(s.get("amount_precision") or 4)
            out.append({"symbol": s["id"], "tick": 10 ** -pp,
                        "step": 10 ** -ap, "mult": 1})
    elif ex == "bitgets":
        with http_get("https://api.bitget.com/api/v2/spot/public/symbols", timeout=30) as r:
            raw = json.loads(r.read().decode())
        for s in raw.get("data", []):
            if s.get("status") != "online":
                continue
            pp = int(s.get("pricePrecision") or 2)
            qp = int(s.get("quantityPrecision") or 4)
            out.append({"symbol": s["symbol"], "tick": 10 ** -pp,
                        "step": 10 ** -qp, "mult": 1})
    elif ex == "kucoins":
        with http_get("https://api.kucoin.com/api/v1/symbols", timeout=30) as r:
            raw = json.loads(r.read().decode())
        for s in raw.get("data", []):
            if not s.get("enableTrading"):
                continue
            out.append({"symbol": s["symbol"],
                        "tick": float(s.get("priceIncrement") or 0.0001),
                        "step": float(s.get("baseIncrement") or 0.0001), "mult": 1})
    elif ex == "hl":
        with http_post("https://api.hyperliquid.xyz/info", {"type": "meta"}) as r:
            meta = json.loads(r.read().decode())
        mids = {}
        try:
            with http_post("https://api.hyperliquid.xyz/info", {"type": "allMids"}) as r:
                mids = json.loads(r.read().decode())
        except Exception:
            pass
        for s in meta.get("universe", []):
            if s.get("isDelisted"):
                continue
            name = s["name"]
            px = float(mids.get(name) or 0)
            tick = 0.0001
            if px > 0:
                import math
                tick = 10 ** (math.floor(math.log10(px)) - 4)  # ~5 значащих цифр
            step = 10 ** (-int(s.get("szDecimals", 3)))
            out.append({"symbol": name, "tick": tick, "step": step, "mult": 1})
    out.sort(key=lambda x: x["symbol"])
    _ex_symbols_cache[ex] = {"ts": now, "data": out}
    return out


def fetch_histklines(ex, symbol, tf, end):
    """До ~3000 свечей ТФ до момента end (мс) с выбранной биржи."""
    out = []
    if ex in ("fut", "spot"):
        base = (f"{FAPI}/fapi/v1/klines" if ex == "fut"
                else "https://api.binance.com/api/v3/klines")
        cursor = end - 1
        for _ in range(3):
            url = f"{base}?symbol={symbol}&interval={tf}&endTime={cursor}&limit=1000"
            with http_get(url, timeout=30) as r:
                page = json.loads(r.read().decode())
            if not page:
                break
            out = [[k[0], float(k[1]), float(k[2]), float(k[3]),
                    float(k[4]), float(k[5])] for k in page] + out
            cursor = page[0][0] - 1
            if len(page) < 1000:
                break
    elif ex in ("bybit", "bybits"):
        iv = {"1m": "1", "5m": "5", "15m": "15", "30m": "30",
              "1h": "60", "4h": "240", "1d": "D"}[tf]
        cat = "spot" if ex == "bybits" else "linear"
        cursor = end - 1
        for _ in range(3):
            url = (f"https://api.bybit.com/v5/market/kline?category={cat}"
                   f"&symbol={symbol}&interval={iv}&end={cursor}&limit=1000")
            with http_get(url, timeout=30) as r:
                page = json.loads(r.read().decode()).get("result", {}).get("list", [])
            if not page:
                break
            page = sorted(page, key=lambda k: int(k[0]))  # bybit отдаёт по убыванию
            out = [[int(k[0]), float(k[1]), float(k[2]), float(k[3]),
                    float(k[4]), float(k[5])] for k in page] + out
            cursor = int(page[0][0]) - 1
            if len(page) < 1000:
                break
    elif ex in ("okx", "okxs"):
        bar = {"1m": "1m", "5m": "5m", "15m": "15m", "30m": "30m",
               "1h": "1H", "4h": "4H", "1d": "1Dutc"}[tf]
        cursor = end
        for _ in range(10):  # okx отдаёт максимум по 100
            url = ("https://www.okx.com/api/v5/market/history-candles"
                   f"?instId={symbol}&bar={bar}&after={cursor}&limit=100")
            with http_get(url, timeout=30) as r:
                page = json.loads(r.read().decode()).get("data", [])
            if not page:
                break
            page = sorted(page, key=lambda k: int(k[0]))
            out = [[int(k[0]), float(k[1]), float(k[2]), float(k[3]),
                    float(k[4]), float(k[5])] for k in page] + out
            cursor = int(page[0][0])
            if len(page) < 100:
                break
    return out


def find_tick_ex(ex, symbol):
    try:
        for s in get_symbols_ex(ex):
            if s["symbol"] == symbol:
                return s["tick"], s["step"]
    except Exception:
        pass
    return None, None


# ---------------------------------------------------------------- импорт истории

def hist_source_url(ex, symbol, date):
    """URL дневного файла сделок для биржи."""
    if ex == "fut":
        return f"{BINANCE_VISION}/aggTrades/{symbol}/{symbol}-aggTrades-{date}.zip"
    if ex == "spot":
        return ("https://data.binance.vision/data/spot/daily/aggTrades/"
                f"{symbol}/{symbol}-aggTrades-{date}.zip")
    if ex == "bybit":
        return f"https://public.bybit.com/trading/{symbol}/{symbol}{date}.csv.gz"
    if ex == "bybits":
        return f"https://public.bybit.com/spot/{symbol}/{symbol}_{date}.csv.gz"
    if ex in ("okx", "okxs"):
        d8 = date.replace("-", "")
        return ("https://static.okx.com/cdn/okex/traderecords/trades/daily/"
                f"{d8}/{symbol}-trades-{date}.zip")
    raise RuntimeError("неизвестная биржа")


def import_job(job_id, symbol, date, with_l1, ex="fut"):
    try:
        set_job(job_id, status="Скачиваю ленту сделок…", progress=1, error=None, session=None)
        url = hist_source_url(ex, symbol, date)
        fname = os.path.basename(url)
        src = os.path.join(CACHE_DIR, f"{ex}-{fname}")
        if not os.path.exists(src):
            if http_head_size(url) is None:
                raise RuntimeError(f"Нет данных {symbol} за {date} на бирже "
                                   f"({url.split('/')[2]})")
            download_to(url, src, job_id, 1, 45)

        bt_zip = None
        if with_l1 and ex == "fut":
            set_job(job_id, status="Проверяю bookTicker (реальный спред)…", progress=45)
            bt_url = f"{BINANCE_VISION}/bookTicker/{symbol}/{symbol}-bookTicker-{date}.zip"
            bt_path = os.path.join(CACHE_DIR, f"{symbol}-bookTicker-{date}.zip")
            if os.path.exists(bt_path):
                bt_zip = bt_path
            elif http_head_size(bt_url) is not None:
                set_job(job_id, status="Скачиваю bookTicker (большой файл)…")
                download_to(bt_url, bt_path, job_id, 45, 70)
                bt_zip = bt_path

        set_job(job_id, status="Конвертирую в сессию…",
                progress=70 if bt_zip else 45)
        if ex == "fut":
            stream = iter_trades(src)
        elif ex == "spot":
            stream = iter_trades_spot(src)
        elif ex in ("bybit", "bybits"):
            stream = iter_trades_bybit(src)
        else:  # okx, okxs
            stream = iter_trades_okx(src)
        if bt_zip:
            stream = merge_streams(stream, iter_l1(bt_zip))
        prefix = "hist" if ex == "fut" else f"hist-{ex}"
        session_id = f"{prefix}-{symbol}-{date}"
        convert_hist(job_id, session_id, symbol, date, stream,
                     os.path.getsize(src) * 14, ex, bool(bt_zip))
        set_job(job_id, status="Готово", progress=100, session=session_id)
    except Exception as e:
        set_job(job_id, status="Ошибка", error=str(e))


def iter_csv_rows(zip_path):
    """Итератор строк CSV внутри zip (берёт первый файл в архиве)."""
    with zipfile.ZipFile(zip_path) as z:
        name = z.namelist()[0]
        with z.open(name) as raw:
            text = io.TextIOWrapper(raw, encoding="utf-8", newline="")
            reader = csv.reader(text)
            for row in reader:
                yield row


def iter_trades(zip_path):
    """aggTrades: agg_trade_id, price, quantity, first_id, last_id, time, is_buyer_maker"""
    for row in iter_csv_rows(zip_path):
        if not row or not row[0].isdigit():
            continue  # заголовок
        t = int(row[5])
        m = 1 if row[6].strip().lower() in ("true", "1") else 0
        yield (t, '{"t":%d,"y":"t","p":%s,"q":%s,"m":%d}' % (t, row[1], row[2], m),
               float(row[1]), float(row[2]))


def iter_trades_spot(zip_path):
    """Binance spot aggTrades: id, price, qty, f, l, time, isBuyerMaker, isBestMatch.
    Время с 2025 года в микросекундах — нормализуем в мс."""
    for row in iter_csv_rows(zip_path):
        if not row or not row[0].isdigit():
            continue
        t = int(row[5])
        if t > 10 ** 14:
            t //= 1000
        m = 1 if row[6].strip().lower() in ("true", "1") else 0
        yield (t, '{"t":%d,"y":"t","p":%s,"q":%s,"m":%d}' % (t, row[1], row[2], m),
               float(row[1]), float(row[2]))


def iter_trades_bybit(gz_path):
    """Bybit csv.gz. Перпы: timestamp(сек),symbol,side,size,price.
    Спот: id,timestamp(мс),price,volume,side. Колонки и масштаб времени
    определяем по заголовку. Порядок строк не гарантирован — сортируем."""
    rows = []
    with gzip.open(gz_path, "rt") as f:
        reader = csv.reader(f)
        header = next(reader, None)
        idx = {name.strip().lower(): i for i, name in enumerate(header or [])}
        it = idx.get("timestamp", 0)
        isd = idx.get("side", 2)
        isz = idx["size"] if "size" in idx else idx.get("volume", 3)
        ipx = idx.get("price", 4)
        for row in reader:
            try:
                tv = float(row[it])
                t = int(tv) if tv >= 1e12 else int(tv * 1000)   # мс или сек
                rows.append((t, float(row[ipx]), float(row[isz]),
                             1 if row[isd].lower().startswith("s") else 0))
            except (ValueError, IndexError):
                continue
    rows.sort(key=lambda r: r[0])
    for t, p, q, m in rows:
        yield (t, '{"t":%d,"y":"t","p":%.10g,"q":%.10g,"m":%d}' % (t, p, q, m), p, q)


def iter_trades_okx(zip_path):
    """OKX: zip с CSV instrument,trade_id,side,size,price,created_time(мс)."""
    rows = []
    with zipfile.ZipFile(zip_path) as z:
        name = z.namelist()[0]
        with z.open(name) as raw:
            text = io.TextIOWrapper(raw, encoding="utf-8", errors="replace", newline="")
            reader = csv.reader(text)
            header = next(reader, None)
            cols = [c.strip().lower() for c in (header or [])]
            def col(*names, default=None):
                for n in names:
                    if n in cols:
                        return cols.index(n)
                return default
            isd = col("side", default=2)
            isz = col("size", "sz", default=3)
            ipx = col("price", "px", default=4)
            it = col("created_time", "ts", "timestamp", default=5)
            for row in reader:
                try:
                    t = int(float(row[it]))
                    if t < 10 ** 12:
                        t *= 1000
                    rows.append((t, float(row[ipx]), float(row[isz]),
                                 1 if row[isd].lower().startswith("s") else 0))
                except (ValueError, IndexError):
                    continue
    rows.sort(key=lambda r: r[0])
    for t, p, q, m in rows:
        yield (t, '{"t":%d,"y":"t","p":%.10g,"q":%.10g,"m":%d}' % (t, p, q, m), p, q)


def iter_l1(zip_path, min_interval_ms=100):
    """bookTicker: update_id, bid_p, bid_q, ask_p, ask_q, transaction_time, event_time.
    Прореживаем до одного события в min_interval_ms."""
    last_kept = 0
    for row in iter_csv_rows(zip_path):
        if not row or not row[0].isdigit():
            continue
        t = int(row[5])
        if t - last_kept < min_interval_ms:
            continue
        last_kept = t
        yield (t, '{"t":%d,"y":"q","bp":%s,"bq":%s,"ap":%s,"aq":%s}'
               % (t, row[1], row[2], row[3], row[4]), None, None)


def merge_streams(a, b):
    """Слияние двух отсортированных по времени итераторов (t, line, p, q)."""
    import heapq
    return heapq.merge(a, b, key=lambda x: x[0])


def kline_update(kmap, bucket_ms, t, p, q):
    """Обновить свечу таймфрейма bucket_ms в kmap по принту."""
    m = t // bucket_ms * bucket_ms
    k = kmap.get(m)
    if k is None:
        kmap[m] = [m, p, p, p, p, q]
    else:
        if p > k[2]:
            k[2] = p
        if p < k[3]:
            k[3] = p
        k[4] = p
        k[5] += q


def write_klines(sdir, kmap_m, kmap_s):
    """klines2.json: минутки (для ТФ 1м+) и секундные свечи (для ТФ 1с-30с)."""
    data = {
        "m": [kmap_m[k] for k in sorted(kmap_m)],
        "s": [kmap_s[k] for k in sorted(kmap_s)],
    }
    with open(os.path.join(sdir, "klines2.json"), "w") as f:
        json.dump(data, f)


def build_klines_from_chunks(sdir):
    """Ленивая сборка свечей для сессий без klines2.json (записи, старые импорты)."""
    import glob
    kmap_m, kmap_s = {}, {}
    for fp in sorted(glob.glob(os.path.join(sdir, "chunk-*.ndjson.gz"))):
        with gzip.open(fp, "rt") as f:
            for line in f:
                if '"y":"t"' not in line:
                    continue
                try:
                    d = json.loads(line)
                except ValueError:
                    continue
                p, q = float(d["p"]), float(d["q"])
                kline_update(kmap_m, 60000, d["t"], p, q)
                kline_update(kmap_s, 1000, d["t"], p, q)
    write_klines(sdir, kmap_m, kmap_s)


def convert_hist(job_id, session_id, symbol, date, stream, total_est, ex, has_l1):
    sdir = os.path.join(SESS_DIR, session_id)
    if os.path.exists(sdir):
        shutil.rmtree(sdir)
    os.makedirs(sdir)

    chunks = []
    cur_idx = None
    cur_file = None
    start_ts = end_ts = None
    n_events = 0
    kmap_m, kmap_s = {}, {}

    try:
        for t, line, p, q in stream:
            if start_ts is None:
                start_ts = t
            end_ts = t
            if p is not None:
                kline_update(kmap_m, 60000, t, p, q)
                kline_update(kmap_s, 1000, t, p, q)
            idx = t // CHUNK_MS
            if idx != cur_idx:
                if cur_file:
                    cur_file.close()
                cur_idx = idx
                seq = len(chunks)
                chunks.append({"seq": seq, "start": t})
                cur_file = gzip.open(os.path.join(sdir, f"chunk-{seq:05d}.ndjson.gz"),
                                     "wt", compresslevel=5)
            cur_file.write(line + "\n")
            n_events += 1
            if job_id and n_events % 200000 == 0:
                base = 70 if has_l1 else 45
                set_job(job_id, progress=min(99, base + (100 - base) * n_events / max(total_est, 1)))
    finally:
        if cur_file:
            cur_file.close()

    if not chunks:
        shutil.rmtree(sdir)
        raise RuntimeError("Файл данных пуст")

    write_klines(sdir, kmap_m, kmap_s)
    tick, step = find_tick_ex(ex, symbol)
    meta = {
        "id": session_id, "symbol": symbol, "date": date, "mode": "hist",
        "exchange": ex,
        "l1": has_l1, "start": start_ts, "end": end_ts,
        "events": n_events, "chunks": chunks, "tick": tick, "step": step,
        "created": int(time.time() * 1000),
    }
    with open(os.path.join(sdir, "meta.json"), "w") as f:
        json.dump(meta, f)


# ---------------------------------------------------------------- сессии

SAFE_ID = re.compile(r"^[A-Za-z0-9_.-]+$")


def list_sessions():
    out = []
    if not os.path.isdir(SESS_DIR):
        return out
    for sid in sorted(os.listdir(SESS_DIR)):
        mf = os.path.join(SESS_DIR, sid, "meta.json")
        if os.path.exists(mf):
            try:
                with open(mf) as f:
                    out.append(json.load(f))
            except Exception:
                pass
    out.sort(key=lambda m: m.get("created", 0), reverse=True)
    return out


# ---------------------------------------------------------------- HTTP

class Handler(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"

    def log_message(self, fmt, *args):
        pass  # тишина в консоли

    # --- helpers
    def send_json(self, obj, code=200):
        body = json.dumps(obj, ensure_ascii=False).encode()
        self.send_response(code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def send_err(self, msg, code=400):
        self.send_json({"error": msg}, code)

    def read_body(self):
        n = int(self.headers.get("Content-Length") or 0)
        data = self.rfile.read(n) if n else b""
        if self.headers.get("X-Gzip") == "1":
            data = gzip.decompress(data)
        return data

    def session_dir(self, sid):
        if not SAFE_ID.match(sid):
            return None
        return os.path.join(SESS_DIR, sid)

    # --- GET
    def do_GET(self):
        u = urlparse(self.path)
        q = parse_qs(u.query)
        path = u.path

        try:
            if path == "/api/symbols":
                ex = (q.get("ex") or ["fut"])[0]
                if ex not in ALL_EX:
                    return self.send_err("неизвестная биржа")
                return self.send_json(get_symbols_ex(ex))

            if path == "/api/sessions":
                return self.send_json(list_sessions())

            m = re.match(r"^/api/sessions/([A-Za-z0-9_.-]+)/meta$", path)
            if m:
                mf = os.path.join(SESS_DIR, m.group(1), "meta.json")
                if not os.path.exists(mf):
                    return self.send_err("нет такой сессии", 404)
                with open(mf) as f:
                    return self.send_json(json.load(f))

            m = re.match(r"^/api/sessions/([A-Za-z0-9_.-]+)/klines$", path)
            if m:
                sdir = os.path.join(SESS_DIR, m.group(1))
                if not os.path.isdir(sdir):
                    return self.send_err("нет такой сессии", 404)
                kf = os.path.join(sdir, "klines2.json")
                if not os.path.exists(kf):
                    build_klines_from_chunks(sdir)  # разовая сборка для старых сессий
                with open(kf) as f:
                    body = f.read().encode()
                self.send_response(200)
                self.send_header("Content-Type", "application/json")
                self.send_header("Content-Length", str(len(body)))
                self.end_headers()
                self.wfile.write(body)
                return

            m = re.match(r"^/api/sessions/([A-Za-z0-9_.-]+)/chunks/(\d+)$", path)
            if m:
                fp = os.path.join(SESS_DIR, m.group(1),
                                  f"chunk-{int(m.group(2)):05d}.ndjson.gz")
                if not os.path.exists(fp):
                    return self.send_err("нет чанка", 404)
                size = os.path.getsize(fp)
                self.send_response(200)
                self.send_header("Content-Type", "application/x-ndjson")
                self.send_header("Content-Encoding", "gzip")
                self.send_header("Content-Length", str(size))
                self.end_headers()
                with open(fp, "rb") as f:
                    shutil.copyfileobj(f, self.wfile)
                return

            if path == "/api/import/status":
                jid = (q.get("id") or [""])[0]
                with jobs_lock:
                    job = dict(jobs.get(jid) or {})
                if not job:
                    return self.send_err("нет такой задачи", 404)
                return self.send_json(job)

            if path == "/api/histcheck":
                symbol = (q.get("symbol") or [""])[0].upper()
                date = (q.get("date") or [""])[0]
                ex = (q.get("ex") or ["fut"])[0]
                if not re.match(r"^\d{4}-\d{2}-\d{2}$", date) or not SAFE_ID.match(symbol) \
                        or ex not in IMPORT_EX:
                    return self.send_err("плохие параметры")
                agg = http_head_size(hist_source_url(ex, symbol, date))
                bt = None
                if ex == "fut":
                    bt = http_head_size(f"{BINANCE_VISION}/bookTicker/{symbol}/{symbol}-bookTicker-{date}.zip")
                return self.send_json({"aggTrades": agg, "bookTicker": bt})

            if path == "/api/update/check":
                if not UPDATE_MANIFEST:
                    return self.send_json({"enabled": False, "current": VERSION})
                try:
                    with http_get(UPDATE_MANIFEST, timeout=15) as r:
                        man = json.loads(r.read().decode())
                    return self.send_json({
                        "enabled": True, "current": VERSION,
                        "latest": man.get("version"), "notes": man.get("notes", ""),
                        "zip": man.get("zip", ""),
                        "hasUpdate": man.get("version") != VERSION,
                    })
                except Exception as e:
                    return self.send_json({"enabled": True, "current": VERSION,
                                           "error": str(e)})

            if path == "/api/histklines":
                # история до начала сессии (все ТФ от 1м), с кэшем по точному времени
                symbol = (q.get("symbol") or [""])[0].upper()
                tf = (q.get("tf") or [""])[0]
                end = int((q.get("end") or ["0"])[0])
                ex = (q.get("ex") or ["fut"])[0]
                if tf not in ("1m", "5m", "15m", "30m", "1h", "4h", "1d") \
                        or not SAFE_ID.match(symbol) or end <= 0 \
                        or ex not in ALL_EX:
                    return self.send_err("плохие параметры")
                cf = os.path.join(CACHE_DIR, f"histk-{ex}-{symbol}-{tf}-{end}.json")
                if not os.path.exists(cf):
                    out = []
                    try:
                        out = fetch_histklines(ex, symbol, tf, end)
                    except Exception:
                        pass
                    with open(cf, "w") as f:
                        json.dump(out, f)
                with open(cf) as f:
                    body = f.read().encode()
                self.send_response(200)
                self.send_header("Content-Type", "application/json")
                self.send_header("Content-Length", str(len(body)))
                self.end_headers()
                self.wfile.write(body)
                return

            m = re.match(r"^/api/sessions/([A-Za-z0-9_.-]+)/export$", path)
            if m:
                sdir = os.path.join(SESS_DIR, m.group(1))
                if not os.path.isdir(sdir):
                    return self.send_err("нет такой сессии", 404)
                import tempfile
                tmp = tempfile.NamedTemporaryFile(suffix=".zip", delete=False)
                try:
                    with zipfile.ZipFile(tmp, "w", zipfile.ZIP_STORED) as z:
                        for fn in sorted(os.listdir(sdir)):
                            z.write(os.path.join(sdir, fn), fn)
                    size = os.path.getsize(tmp.name)
                    self.send_response(200)
                    self.send_header("Content-Type", "application/zip")
                    self.send_header("Content-Disposition",
                                     f'attachment; filename="{m.group(1)}.playersession"')
                    self.send_header("Content-Length", str(size))
                    self.end_headers()
                    with open(tmp.name, "rb") as f:
                        shutil.copyfileobj(f, self.wfile)
                finally:
                    os.unlink(tmp.name)
                return

            if path == "/api/depth":
                symbol = (q.get("symbol") or [""])[0].upper()
                ex = (q.get("ex") or ["fut"])[0]
                if not SAFE_ID.match(symbol):
                    return self.send_err("плохой символ")
                if ex == "spot":
                    url = f"https://api.binance.com/api/v3/depth?symbol={symbol}&limit=1000"
                elif ex == "aster":
                    url = f"https://fapi.asterdex.com/fapi/v1/depth?symbol={symbol}&limit=1000"
                else:
                    url = f"{FAPI}/fapi/v1/depth?symbol={symbol}&limit=1000"
                with http_get(url, timeout=30) as r:
                    body = r.read()
                self.send_response(200)
                self.send_header("Content-Type", "application/json")
                self.send_header("Content-Length", str(len(body)))
                self.end_headers()
                self.wfile.write(body)
                return

            # статика
            rel = "index.html" if path == "/" else path.lstrip("/")
            fp = os.path.normpath(os.path.join(APP_DIR, rel))
            if not fp.startswith(APP_DIR) or not os.path.isfile(fp):
                return self.send_err("not found", 404)
            ext = os.path.splitext(fp)[1]
            self.send_response(200)
            self.send_header("Content-Type", MIME.get(ext, "application/octet-stream"))
            self.send_header("Content-Length", str(os.path.getsize(fp)))
            self.send_header("Cache-Control", "no-store")
            self.end_headers()
            with open(fp, "rb") as f:
                shutil.copyfileobj(f, self.wfile)
        except BrokenPipeError:
            pass
        except Exception as e:
            try:
                self.send_err(f"server error: {e}", 500)
            except Exception:
                pass

    # --- POST
    def do_POST(self):
        u = urlparse(self.path)
        path = u.path
        q = parse_qs(u.query)
        try:
            if path == "/api/kucoin-token":
                # публичный токен KuCoin для WebSocket (bullet-public)
                # market=spot → спотовый хост, иначе фьючерсный
                host = ("https://api.kucoin.com" if (q.get("market") or [""])[0] == "spot"
                        else "https://api-futures.kucoin.com")
                try:
                    with http_post(host + "/api/v1/bullet-public",
                                   {}, timeout=20) as r:
                        d = json.loads(r.read().decode())
                    srv = d["data"]["instanceServers"][0]
                    return self.send_json({
                        "token": d["data"]["token"],
                        "endpoint": srv["endpoint"],
                        "pingInterval": srv.get("pingInterval", 18000),
                    })
                except Exception as e:
                    return self.send_err("KuCoin token: " + str(e))

            if path == "/api/import":
                body = json.loads(self.read_body() or b"{}")
                symbol = str(body.get("symbol", "")).upper()
                date = str(body.get("date", ""))
                with_l1 = bool(body.get("l1"))
                ex = str(body.get("ex", "fut"))
                if not SAFE_ID.match(symbol) or not re.match(r"^\d{4}-\d{2}-\d{2}$", date) \
                        or ex not in IMPORT_EX:
                    return self.send_err("плохие параметры")
                jid = f"{ex}-{symbol}-{date}"
                with jobs_lock:
                    running = jid in jobs and jobs[jid].get("status") not in ("Готово", "Ошибка")
                if not running:
                    set_job(jid, status="Старт…", progress=0, error=None, session=None)
                    threading.Thread(target=import_job,
                                     args=(jid, symbol, date, with_l1, ex),
                                     daemon=True).start()
                return self.send_json({"job": jid})

            m = re.match(r"^/api/sessions/([A-Za-z0-9_.-]+)/chunks/(\d+)$", path)
            if m:
                sdir = self.session_dir(m.group(1))
                if sdir is None:
                    return self.send_err("плохой id")
                os.makedirs(sdir, exist_ok=True)
                data = self.read_body()  # уже распакован, если X-Gzip
                fp = os.path.join(sdir, f"chunk-{int(m.group(2)):05d}.ndjson.gz")
                with gzip.open(fp, "wb", compresslevel=5) as f:
                    f.write(data)
                return self.send_json({"ok": True, "bytes": len(data)})

            if path == "/api/update/apply":
                # самообновление: скачиваем zip обновления и заменяем app/ и server.py
                if not UPDATE_MANIFEST:
                    return self.send_err("обновления не настроены")
                import tempfile
                try:
                    with http_get(UPDATE_MANIFEST, timeout=15) as r:
                        man = json.loads(r.read().decode())
                    zurl = man.get("zip")
                    if not zurl:
                        return self.send_err("в манифесте нет ссылки на архив")
                    tmp = tempfile.NamedTemporaryFile(suffix=".zip", delete=False).name
                    download_to(zurl, tmp)
                    with zipfile.ZipFile(tmp) as z:
                        ok = re.compile(r"^(app/[\w./-]+|server\.py)$")
                        names = [n for n in z.namelist() if not n.endswith("/")]
                        if not all(ok.match(n) for n in names):
                            return self.send_err("архив обновления содержит посторонние файлы")
                        z.extractall(ROOT)
                    os.unlink(tmp)
                    return self.send_json({"ok": True, "version": man.get("version"),
                                           "restart": True})
                except Exception as e:
                    return self.send_err(f"не удалось обновиться: {e}")

            if path == "/api/sessions/import":
                # импорт записи из файла .playersession (zip сессии)
                import tempfile
                n = int(self.headers.get("Content-Length") or 0)
                if n <= 0 or n > 2 * 1024 ** 3:
                    return self.send_err("пустой или слишком большой файл")
                with tempfile.NamedTemporaryFile(suffix=".zip", delete=False) as tmp:
                    left = n
                    while left > 0:
                        buf = self.rfile.read(min(1024 * 256, left))
                        if not buf:
                            break
                        tmp.write(buf)
                        left -= len(buf)
                    tmp_path = tmp.name
                try:
                    with zipfile.ZipFile(tmp_path) as z:
                        names = z.namelist()
                        if "meta.json" not in names:
                            return self.send_err("в файле нет meta.json — это не запись плеера")
                        ok = re.compile(r"^(meta\.json|klines2?\.json|chunk-\d+\.ndjson\.gz)$")
                        if not all(ok.match(nm) for nm in names):
                            return self.send_err("файл содержит посторонние данные")
                        meta = json.loads(z.read("meta.json"))
                        sid = str(meta.get("id", "imported"))
                        if not SAFE_ID.match(sid):
                            sid = "imported-session"
                        base = sid
                        k = 2
                        while os.path.exists(os.path.join(SESS_DIR, sid)):
                            sid = f"{base}-{k}"
                            k += 1
                        sdir = os.path.join(SESS_DIR, sid)
                        os.makedirs(sdir)
                        z.extractall(sdir)
                        meta["id"] = sid
                        with open(os.path.join(sdir, "meta.json"), "w") as f:
                            json.dump(meta, f)
                    return self.send_json({"ok": True, "id": sid})
                except zipfile.BadZipFile:
                    return self.send_err("файл повреждён или не является записью")
                finally:
                    os.unlink(tmp_path)

            m = re.match(r"^/api/sessions/([A-Za-z0-9_.-]+)/finish$", path)
            if m:
                sdir = self.session_dir(m.group(1))
                if sdir is None or not os.path.isdir(sdir):
                    return self.send_err("нет такой сессии", 404)
                meta = json.loads(self.read_body())
                meta["id"] = m.group(1)
                meta["created"] = int(time.time() * 1000)
                with open(os.path.join(sdir, "meta.json"), "w") as f:
                    json.dump(meta, f)
                return self.send_json({"ok": True})

            return self.send_err("not found", 404)
        except Exception as e:
            try:
                self.send_err(f"server error: {e}", 500)
            except Exception:
                pass

    # --- DELETE
    def do_DELETE(self):
        m = re.match(r"^/api/sessions/([A-Za-z0-9_.-]+)$", urlparse(self.path).path)
        if not m:
            return self.send_err("not found", 404)
        sdir = self.session_dir(m.group(1))
        if sdir and os.path.isdir(sdir):
            shutil.rmtree(sdir)
            return self.send_json({"ok": True})
        return self.send_err("нет такой сессии", 404)


def open_app_window(url):
    """Открыть плеер отдельным окном без браузерной обвязки (Chrome --app),
    иначе — обычной вкладкой браузера по умолчанию. Mac и Windows."""
    import subprocess
    if sys.platform == "darwin":
        for app in ("Google Chrome", "Chromium", "Microsoft Edge", "Yandex"):
            if os.path.isdir(f"/Applications/{app}.app"):
                try:
                    subprocess.Popen(["open", "-na", app, "--args",
                                      f"--app={url}", "--window-size=1500,950"])
                    return
                except Exception:
                    break
    elif sys.platform == "win32":
        pf = os.environ.get("ProgramFiles", r"C:\Program Files")
        pf86 = os.environ.get("ProgramFiles(x86)", r"C:\Program Files (x86)")
        local = os.environ.get("LocalAppData", "")
        candidates = [
            os.path.join(pf, "Google", "Chrome", "Application", "chrome.exe"),
            os.path.join(pf86, "Google", "Chrome", "Application", "chrome.exe"),
            os.path.join(local, "Google", "Chrome", "Application", "chrome.exe"),
            os.path.join(pf86, "Microsoft", "Edge", "Application", "msedge.exe"),
            os.path.join(pf, "Microsoft", "Edge", "Application", "msedge.exe"),
        ]
        for exe in candidates:
            if os.path.isfile(exe):
                try:
                    subprocess.Popen([exe, f"--app={url}", "--window-size=1500,950"])
                    return
                except Exception:
                    break
    webbrowser.open(url)


def free_port(start=8765):
    for p in range(start, start + 50):
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            try:
                s.bind(("127.0.0.1", p))
                return p
            except OSError:
                continue
    return start


def main():
    # на Windows консоль может быть не в UTF-8 — не падаем на русских сообщениях
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
        sys.stderr.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass
    ensure_dirs()
    env_port = os.environ.get("PORT")
    port = int(env_port) if env_port else free_port()
    srv = ThreadingHTTPServer(("127.0.0.1", port), Handler)
    url = f"http://127.0.0.1:{port}/"
    print(f"Плеер запущен: {url}")
    print("Не закрывайте это окно, пока работаете с плеером. Ctrl+C — выход.")
    if not env_port:  # при запуске из превью/IDE браузер не открываем
        threading.Timer(0.6, lambda: open_app_window(url)).start()
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        print("\nОстановлено.")


if __name__ == "__main__":
    main()
