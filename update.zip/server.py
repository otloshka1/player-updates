#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Плеер — локальный сервер тренажёра реплея рынка (аналог Player из Tiger Trade).
Только стандартная библиотека Python, без зависимостей.

Запуск:  python3 server.py   (или двойной клик по Плеер.command)
"""
import csv
import gzip
import io
import json
import os
import re
import shutil
import socket
import sys
import threading
import time
import urllib.request
import urllib.error
import webbrowser
import zipfile
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse, parse_qs

ROOT = os.path.dirname(os.path.abspath(__file__))
APP_DIR = os.path.join(ROOT, "app")
# внутри .app-бандла данные храним в пользовательской папке, иначе рядом
if ".app/Contents/" in ROOT and sys.platform == "darwin":
    DATA_DIR = os.path.expanduser("~/Library/Application Support/PlayerTrainer")
else:
    DATA_DIR = os.path.join(ROOT, "data")
SESS_DIR = os.path.join(DATA_DIR, "sessions")
CACHE_DIR = os.path.join(DATA_DIR, "cache")

BINANCE_VISION = "https://data.binance.vision/data/futures/um/daily"
FAPI = "https://fapi.binance.com"

VERSION = "1.1.1"
# URL манифеста обновлений (version.json: {"version": "...", "zip": "...", "notes": "..."}).
UPDATE_MANIFEST = "https://raw.githubusercontent.com/otloshka1/player-updates/main/version.json"

CHUNK_MS = 5 * 60 * 1000  # размер чанка исторической сессии

MIME = {
    ".html": "text/html; charset=utf-8",
    ".js": "text/javascript; charset=utf-8",
    ".css": "text/css; charset=utf-8",
    ".json": "application/json; charset=utf-8",
    ".png": "image/png",
    ".svg": "image/svg+xml",
    ".wav": "audio/wav",
}

jobs = {}      # id -> {"status": "...", "progress": 0..100, "error": str|None, "session": id|None}
jobs_lock = threading.Lock()
_exchange_info_cache = {"ts": 0, "data": None}


def ensure_dirs():
    for d in (DATA_DIR, SESS_DIR, CACHE_DIR):
        os.makedirs(d, exist_ok=True)


def http_get(url, timeout=120):
    req = urllib.request.Request(url, headers={"User-Agent": "player-macbook/1.0"})
    return urllib.request.urlopen(req, timeout=timeout)


def http_head_size(url):
    """Возвращает размер файла по URL или None, если файла нет."""
    try:
        req = urllib.request.Request(url, method="HEAD",
                                     headers={"User-Agent": "player-macbook/1.0"})
        with urllib.request.urlopen(req, timeout=30) as r:
            return int(r.headers.get("Content-Length") or 0)
    except urllib.error.HTTPError:
        return None
    except Exception:
        return None


def download_to(url, dest, job_id=None, p_from=0, p_to=50):
    """Скачивает файл с прогрессом в jobs[job_id]['progress']."""
    tmp = dest + ".part"
    with http_get(url, timeout=600) as r:
        total = int(r.headers.get("Content-Length") or 0)
        done = 0
        with open(tmp, "wb") as f:
            while True:
                buf = r.read(1024 * 256)
                if not buf:
                    break
                f.write(buf)
                done += len(buf)
                if job_id and total:
                    set_job(job_id, progress=p_from + (p_to - p_from) * done / total)
    os.replace(tmp, dest)


def set_job(job_id, **kw):
    with jobs_lock:
        jobs.setdefault(job_id, {})
        jobs[job_id].update(kw)


def get_exchange_info():
    """Список USDT-M перпетуалов с шагом цены/лота. Кэш 12 часов."""
    now = time.time()
    cache_file = os.path.join(CACHE_DIR, "exchangeInfo.json")
    if _exchange_info_cache["data"] and now - _exchange_info_cache["ts"] < 12 * 3600:
        return _exchange_info_cache["data"]
    raw = None
    try:
        with http_get(FAPI + "/fapi/v1/exchangeInfo", timeout=30) as r:
            raw = json.loads(r.read().decode())
        with open(cache_file, "w") as f:
            json.dump(raw, f)
    except Exception:
        if os.path.exists(cache_file):
            with open(cache_file) as f:
                raw = json.load(f)
        else:
            raise
    out = []
    for s in raw.get("symbols", []):
        if s.get("contractType") != "PERPETUAL":
            continue
        tick = step = None
        for flt in s.get("filters", []):
            if flt.get("filterType") == "PRICE_FILTER":
                tick = float(flt["tickSize"])
            if flt.get("filterType") == "LOT_SIZE":
                step = float(flt["stepSize"])
        out.append({"symbol": s["symbol"], "tick": tick, "step": step,
                    "status": s.get("status")})
    out.sort(key=lambda x: x["symbol"])
    _exchange_info_cache["data"] = out
    _exchange_info_cache["ts"] = now
    return out


def find_tick(symbol):
    try:
        for s in get_exchange_info():
            if s["symbol"] == symbol:
                return s["tick"], s["step"]
    except Exception:
        pass
    return None, None


# ---------------------------------------------------------------- импорт истории

def import_job(job_id, symbol, date, with_l1):
    try:
        set_job(job_id, status="Скачиваю ленту сделок…", progress=1, error=None, session=None)
        agg_url = f"{BINANCE_VISION}/aggTrades/{symbol}/{symbol}-aggTrades-{date}.zip"
        agg_zip = os.path.join(CACHE_DIR, f"{symbol}-aggTrades-{date}.zip")
        if not os.path.exists(agg_zip):
            if http_head_size(agg_url) is None:
                raise RuntimeError(f"На Binance нет данных {symbol} за {date} "
                                   f"(файл aggTrades не найден)")
            download_to(agg_url, agg_zip, job_id, 1, 45)

        bt_zip = None
        if with_l1:
            set_job(job_id, status="Проверяю bookTicker (реальный спред)…", progress=45)
            bt_url = f"{BINANCE_VISION}/bookTicker/{symbol}/{symbol}-bookTicker-{date}.zip"
            bt_path = os.path.join(CACHE_DIR, f"{symbol}-bookTicker-{date}.zip")
            if os.path.exists(bt_path):
                bt_zip = bt_path
            elif http_head_size(bt_url) is not None:
                set_job(job_id, status="Скачиваю bookTicker (большой файл)…")
                download_to(bt_url, bt_path, job_id, 45, 70)
                bt_zip = bt_path

        set_job(job_id, status="Конвертирую в сессию…",
                progress=70 if bt_zip else 45)
        session_id = f"hist-{symbol}-{date}"
        convert_hist(job_id, session_id, symbol, date, agg_zip, bt_zip)
        set_job(job_id, status="Готово", progress=100, session=session_id)
    except Exception as e:
        set_job(job_id, status="Ошибка", error=str(e))


def iter_csv_rows(zip_path):
    """Итератор строк CSV внутри zip (берёт первый файл в архиве)."""
    with zipfile.ZipFile(zip_path) as z:
        name = z.namelist()[0]
        with z.open(name) as raw:
            text = io.TextIOWrapper(raw, encoding="utf-8", newline="")
            reader = csv.reader(text)
            for row in reader:
                yield row


def iter_trades(zip_path):
    """aggTrades: agg_trade_id, price, quantity, first_id, last_id, time, is_buyer_maker"""
    for row in iter_csv_rows(zip_path):
        if not row or not row[0].isdigit():
            continue  # заголовок
        t = int(row[5])
        m = 1 if row[6].strip().lower() in ("true", "1") else 0
        yield (t, '{"t":%d,"y":"t","p":%s,"q":%s,"m":%d}' % (t, row[1], row[2], m),
               float(row[1]), float(row[2]))


def iter_l1(zip_path, min_interval_ms=100):
    """bookTicker: update_id, bid_p, bid_q, ask_p, ask_q, transaction_time, event_time.
    Прореживаем до одного события в min_interval_ms."""
    last_kept = 0
    for row in iter_csv_rows(zip_path):
        if not row or not row[0].isdigit():
            continue
        t = int(row[5])
        if t - last_kept < min_interval_ms:
            continue
        last_kept = t
        yield (t, '{"t":%d,"y":"q","bp":%s,"bq":%s,"ap":%s,"aq":%s}'
               % (t, row[1], row[2], row[3], row[4]), None, None)


def merge_streams(a, b):
    """Слияние двух отсортированных по времени итераторов (t, line, p, q)."""
    import heapq
    return heapq.merge(a, b, key=lambda x: x[0])


def kline_update(kmap, bucket_ms, t, p, q):
    """Обновить свечу таймфрейма bucket_ms в kmap по принту."""
    m = t // bucket_ms * bucket_ms
    k = kmap.get(m)
    if k is None:
        kmap[m] = [m, p, p, p, p, q]
    else:
        if p > k[2]:
            k[2] = p
        if p < k[3]:
            k[3] = p
        k[4] = p
        k[5] += q


def write_klines(sdir, kmap_m, kmap_s):
    """klines2.json: минутки (для ТФ 1м+) и секундные свечи (для ТФ 1с-30с)."""
    data = {
        "m": [kmap_m[k] for k in sorted(kmap_m)],
        "s": [kmap_s[k] for k in sorted(kmap_s)],
    }
    with open(os.path.join(sdir, "klines2.json"), "w") as f:
        json.dump(data, f)


def build_klines_from_chunks(sdir):
    """Ленивая сборка свечей для сессий без klines2.json (записи, старые импорты)."""
    import glob
    kmap_m, kmap_s = {}, {}
    for fp in sorted(glob.glob(os.path.join(sdir, "chunk-*.ndjson.gz"))):
        with gzip.open(fp, "rt") as f:
            for line in f:
                if '"y":"t"' not in line:
                    continue
                try:
                    d = json.loads(line)
                except ValueError:
                    continue
                p, q = float(d["p"]), float(d["q"])
                kline_update(kmap_m, 60000, d["t"], p, q)
                kline_update(kmap_s, 1000, d["t"], p, q)
    write_klines(sdir, kmap_m, kmap_s)


def convert_hist(job_id, session_id, symbol, date, agg_zip, bt_zip):
    sdir = os.path.join(SESS_DIR, session_id)
    if os.path.exists(sdir):
        shutil.rmtree(sdir)
    os.makedirs(sdir)

    stream = iter_trades(agg_zip)
    if bt_zip:
        stream = merge_streams(stream, iter_l1(bt_zip))

    chunks = []
    cur_idx = None
    cur_file = None
    start_ts = end_ts = None
    n_events = 0
    kmap_m, kmap_s = {}, {}
    total_est = os.path.getsize(agg_zip) * 14  # грубая оценка строк по размеру

    try:
        for t, line, p, q in stream:
            if start_ts is None:
                start_ts = t
            end_ts = t
            if p is not None:
                kline_update(kmap_m, 60000, t, p, q)
                kline_update(kmap_s, 1000, t, p, q)
            idx = t // CHUNK_MS
            if idx != cur_idx:
                if cur_file:
                    cur_file.close()
                cur_idx = idx
                seq = len(chunks)
                chunks.append({"seq": seq, "start": t})
                cur_file = gzip.open(os.path.join(sdir, f"chunk-{seq:05d}.ndjson.gz"),
                                     "wt", compresslevel=5)
            cur_file.write(line + "\n")
            n_events += 1
            if job_id and n_events % 200000 == 0:
                base = 70 if bt_zip else 45
                set_job(job_id, progress=min(99, base + (100 - base) * n_events / max(total_est, 1)))
    finally:
        if cur_file:
            cur_file.close()

    if not chunks:
        shutil.rmtree(sdir)
        raise RuntimeError("Файл данных пуст")

    write_klines(sdir, kmap_m, kmap_s)
    tick, step = find_tick(symbol)
    meta = {
        "id": session_id, "symbol": symbol, "date": date, "mode": "hist",
        "l1": bool(bt_zip), "start": start_ts, "end": end_ts,
        "events": n_events, "chunks": chunks, "tick": tick, "step": step,
        "created": int(time.time() * 1000),
    }
    with open(os.path.join(sdir, "meta.json"), "w") as f:
        json.dump(meta, f)


# ---------------------------------------------------------------- сессии

SAFE_ID = re.compile(r"^[A-Za-z0-9_.-]+$")


def list_sessions():
    out = []
    if not os.path.isdir(SESS_DIR):
        return out
    for sid in sorted(os.listdir(SESS_DIR)):
        mf = os.path.join(SESS_DIR, sid, "meta.json")
        if os.path.exists(mf):
            try:
                with open(mf) as f:
                    out.append(json.load(f))
            except Exception:
                pass
    out.sort(key=lambda m: m.get("created", 0), reverse=True)
    return out


# ---------------------------------------------------------------- HTTP

class Handler(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"

    def log_message(self, fmt, *args):
        pass  # тишина в консоли

    # --- helpers
    def send_json(self, obj, code=200):
        body = json.dumps(obj, ensure_ascii=False).encode()
        self.send_response(code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def send_err(self, msg, code=400):
        self.send_json({"error": msg}, code)

    def read_body(self):
        n = int(self.headers.get("Content-Length") or 0)
        data = self.rfile.read(n) if n else b""
        if self.headers.get("X-Gzip") == "1":
            data = gzip.decompress(data)
        return data

    def session_dir(self, sid):
        if not SAFE_ID.match(sid):
            return None
        return os.path.join(SESS_DIR, sid)

    # --- GET
    def do_GET(self):
        u = urlparse(self.path)
        q = parse_qs(u.query)
        path = u.path

        try:
            if path == "/api/symbols":
                return self.send_json(get_exchange_info())

            if path == "/api/sessions":
                return self.send_json(list_sessions())

            m = re.match(r"^/api/sessions/([A-Za-z0-9_.-]+)/meta$", path)
            if m:
                mf = os.path.join(SESS_DIR, m.group(1), "meta.json")
                if not os.path.exists(mf):
                    return self.send_err("нет такой сессии", 404)
                with open(mf) as f:
                    return self.send_json(json.load(f))

            m = re.match(r"^/api/sessions/([A-Za-z0-9_.-]+)/klines$", path)
            if m:
                sdir = os.path.join(SESS_DIR, m.group(1))
                if not os.path.isdir(sdir):
                    return self.send_err("нет такой сессии", 404)
                kf = os.path.join(sdir, "klines2.json")
                if not os.path.exists(kf):
                    build_klines_from_chunks(sdir)  # разовая сборка для старых сессий
                with open(kf) as f:
                    body = f.read().encode()
                self.send_response(200)
                self.send_header("Content-Type", "application/json")
                self.send_header("Content-Length", str(len(body)))
                self.end_headers()
                self.wfile.write(body)
                return

            m = re.match(r"^/api/sessions/([A-Za-z0-9_.-]+)/chunks/(\d+)$", path)
            if m:
                fp = os.path.join(SESS_DIR, m.group(1),
                                  f"chunk-{int(m.group(2)):05d}.ndjson.gz")
                if not os.path.exists(fp):
                    return self.send_err("нет чанка", 404)
                size = os.path.getsize(fp)
                self.send_response(200)
                self.send_header("Content-Type", "application/x-ndjson")
                self.send_header("Content-Encoding", "gzip")
                self.send_header("Content-Length", str(size))
                self.end_headers()
                with open(fp, "rb") as f:
                    shutil.copyfileobj(f, self.wfile)
                return

            if path == "/api/import/status":
                jid = (q.get("id") or [""])[0]
                with jobs_lock:
                    job = dict(jobs.get(jid) or {})
                if not job:
                    return self.send_err("нет такой задачи", 404)
                return self.send_json(job)

            if path == "/api/histcheck":
                symbol = (q.get("symbol") or [""])[0].upper()
                date = (q.get("date") or [""])[0]
                if not re.match(r"^\d{4}-\d{2}-\d{2}$", date) or not SAFE_ID.match(symbol):
                    return self.send_err("плохие параметры")
                agg = http_head_size(f"{BINANCE_VISION}/aggTrades/{symbol}/{symbol}-aggTrades-{date}.zip")
                bt = http_head_size(f"{BINANCE_VISION}/bookTicker/{symbol}/{symbol}-bookTicker-{date}.zip")
                return self.send_json({"aggTrades": agg, "bookTicker": bt})

            if path == "/api/update/check":
                if not UPDATE_MANIFEST:
                    return self.send_json({"enabled": False, "current": VERSION})
                try:
                    with http_get(UPDATE_MANIFEST, timeout=15) as r:
                        man = json.loads(r.read().decode())
                    return self.send_json({
                        "enabled": True, "current": VERSION,
                        "latest": man.get("version"), "notes": man.get("notes", ""),
                        "zip": man.get("zip", ""),
                        "hasUpdate": man.get("version") != VERSION,
                    })
                except Exception as e:
                    return self.send_json({"enabled": True, "current": VERSION,
                                           "error": str(e)})

            if path == "/api/histklines":
                # история до начала сессии с Binance (все ТФ от 1м), с кэшем
                symbol = (q.get("symbol") or [""])[0].upper()
                tf = (q.get("tf") or [""])[0]
                end = int((q.get("end") or ["0"])[0])
                if tf not in ("1m", "5m", "15m", "30m", "1h", "4h", "1d") \
                        or not SAFE_ID.match(symbol) or end <= 0:
                    return self.send_err("плохие параметры")
                # ключ кэша — точное время конца, а не день: иначе вторая сессия
                # за день получает утренний кэш и на графике дыра
                cf = os.path.join(CACHE_DIR, f"histk-{symbol}-{tf}-{end}.json")
                if not os.path.exists(cf):
                    out = []
                    cursor = end - 1
                    try:
                        for _ in range(3):  # до 3000 свечей вглубь
                            url = (f"{FAPI}/fapi/v1/klines?symbol={symbol}"
                                   f"&interval={tf}&endTime={cursor}&limit=1000")
                            with http_get(url, timeout=30) as r:
                                page = json.loads(r.read().decode())
                            if not page:
                                break
                            out = [[k[0], float(k[1]), float(k[2]), float(k[3]),
                                    float(k[4]), float(k[5])] for k in page] + out
                            cursor = page[0][0] - 1
                            if len(page) < 1000:
                                break
                    except Exception:
                        pass
                    with open(cf, "w") as f:
                        json.dump(out, f)
                with open(cf) as f:
                    body = f.read().encode()
                self.send_response(200)
                self.send_header("Content-Type", "application/json")
                self.send_header("Content-Length", str(len(body)))
                self.end_headers()
                self.wfile.write(body)
                return

            m = re.match(r"^/api/sessions/([A-Za-z0-9_.-]+)/export$", path)
            if m:
                sdir = os.path.join(SESS_DIR, m.group(1))
                if not os.path.isdir(sdir):
                    return self.send_err("нет такой сессии", 404)
                import tempfile
                tmp = tempfile.NamedTemporaryFile(suffix=".zip", delete=False)
                try:
                    with zipfile.ZipFile(tmp, "w", zipfile.ZIP_STORED) as z:
                        for fn in sorted(os.listdir(sdir)):
                            z.write(os.path.join(sdir, fn), fn)
                    size = os.path.getsize(tmp.name)
                    self.send_response(200)
                    self.send_header("Content-Type", "application/zip")
                    self.send_header("Content-Disposition",
                                     f'attachment; filename="{m.group(1)}.playersession"')
                    self.send_header("Content-Length", str(size))
                    self.end_headers()
                    with open(tmp.name, "rb") as f:
                        shutil.copyfileobj(f, self.wfile)
                finally:
                    os.unlink(tmp.name)
                return

            if path == "/api/depth":
                symbol = (q.get("symbol") or [""])[0].upper()
                if not SAFE_ID.match(symbol):
                    return self.send_err("плохой символ")
                with http_get(f"{FAPI}/fapi/v1/depth?symbol={symbol}&limit=1000",
                              timeout=30) as r:
                    body = r.read()
                self.send_response(200)
                self.send_header("Content-Type", "application/json")
                self.send_header("Content-Length", str(len(body)))
                self.end_headers()
                self.wfile.write(body)
                return

            # статика
            rel = "index.html" if path == "/" else path.lstrip("/")
            fp = os.path.normpath(os.path.join(APP_DIR, rel))
            if not fp.startswith(APP_DIR) or not os.path.isfile(fp):
                return self.send_err("not found", 404)
            ext = os.path.splitext(fp)[1]
            self.send_response(200)
            self.send_header("Content-Type", MIME.get(ext, "application/octet-stream"))
            self.send_header("Content-Length", str(os.path.getsize(fp)))
            self.send_header("Cache-Control", "no-store")
            self.end_headers()
            with open(fp, "rb") as f:
                shutil.copyfileobj(f, self.wfile)
        except BrokenPipeError:
            pass
        except Exception as e:
            try:
                self.send_err(f"server error: {e}", 500)
            except Exception:
                pass

    # --- POST
    def do_POST(self):
        u = urlparse(self.path)
        path = u.path
        q = parse_qs(u.query)
        try:
            if path == "/api/import":
                body = json.loads(self.read_body() or b"{}")
                symbol = str(body.get("symbol", "")).upper()
                date = str(body.get("date", ""))
                with_l1 = bool(body.get("l1"))
                if not SAFE_ID.match(symbol) or not re.match(r"^\d{4}-\d{2}-\d{2}$", date):
                    return self.send_err("плохие параметры")
                jid = f"{symbol}-{date}"
                with jobs_lock:
                    running = jid in jobs and jobs[jid].get("status") not in ("Готово", "Ошибка")
                if not running:
                    set_job(jid, status="Старт…", progress=0, error=None, session=None)
                    threading.Thread(target=import_job,
                                     args=(jid, symbol, date, with_l1),
                                     daemon=True).start()
                return self.send_json({"job": jid})

            m = re.match(r"^/api/sessions/([A-Za-z0-9_.-]+)/chunks/(\d+)$", path)
            if m:
                sdir = self.session_dir(m.group(1))
                if sdir is None:
                    return self.send_err("плохой id")
                os.makedirs(sdir, exist_ok=True)
                data = self.read_body()  # уже распакован, если X-Gzip
                fp = os.path.join(sdir, f"chunk-{int(m.group(2)):05d}.ndjson.gz")
                with gzip.open(fp, "wb", compresslevel=5) as f:
                    f.write(data)
                return self.send_json({"ok": True, "bytes": len(data)})

            if path == "/api/update/apply":
                # самообновление: скачиваем zip обновления и заменяем app/ и server.py
                if not UPDATE_MANIFEST:
                    return self.send_err("обновления не настроены")
                import tempfile
                try:
                    with http_get(UPDATE_MANIFEST, timeout=15) as r:
                        man = json.loads(r.read().decode())
                    zurl = man.get("zip")
                    if not zurl:
                        return self.send_err("в манифесте нет ссылки на архив")
                    tmp = tempfile.NamedTemporaryFile(suffix=".zip", delete=False).name
                    download_to(zurl, tmp)
                    with zipfile.ZipFile(tmp) as z:
                        ok = re.compile(r"^(app/[\w./-]+|server\.py)$")
                        names = [n for n in z.namelist() if not n.endswith("/")]
                        if not all(ok.match(n) for n in names):
                            return self.send_err("архив обновления содержит посторонние файлы")
                        z.extractall(ROOT)
                    os.unlink(tmp)
                    return self.send_json({"ok": True, "version": man.get("version"),
                                           "restart": True})
                except Exception as e:
                    return self.send_err(f"не удалось обновиться: {e}")

            if path == "/api/sessions/import":
                # импорт записи из файла .playersession (zip сессии)
                import tempfile
                n = int(self.headers.get("Content-Length") or 0)
                if n <= 0 or n > 2 * 1024 ** 3:
                    return self.send_err("пустой или слишком большой файл")
                with tempfile.NamedTemporaryFile(suffix=".zip", delete=False) as tmp:
                    left = n
                    while left > 0:
                        buf = self.rfile.read(min(1024 * 256, left))
                        if not buf:
                            break
                        tmp.write(buf)
                        left -= len(buf)
                    tmp_path = tmp.name
                try:
                    with zipfile.ZipFile(tmp_path) as z:
                        names = z.namelist()
                        if "meta.json" not in names:
                            return self.send_err("в файле нет meta.json — это не запись плеера")
                        ok = re.compile(r"^(meta\.json|klines2?\.json|chunk-\d+\.ndjson\.gz)$")
                        if not all(ok.match(nm) for nm in names):
                            return self.send_err("файл содержит посторонние данные")
                        meta = json.loads(z.read("meta.json"))
                        sid = str(meta.get("id", "imported"))
                        if not SAFE_ID.match(sid):
                            sid = "imported-session"
                        base = sid
                        k = 2
                        while os.path.exists(os.path.join(SESS_DIR, sid)):
                            sid = f"{base}-{k}"
                            k += 1
                        sdir = os.path.join(SESS_DIR, sid)
                        os.makedirs(sdir)
                        z.extractall(sdir)
                        meta["id"] = sid
                        with open(os.path.join(sdir, "meta.json"), "w") as f:
                            json.dump(meta, f)
                    return self.send_json({"ok": True, "id": sid})
                except zipfile.BadZipFile:
                    return self.send_err("файл повреждён или не является записью")
                finally:
                    os.unlink(tmp_path)

            m = re.match(r"^/api/sessions/([A-Za-z0-9_.-]+)/finish$", path)
            if m:
                sdir = self.session_dir(m.group(1))
                if sdir is None or not os.path.isdir(sdir):
                    return self.send_err("нет такой сессии", 404)
                meta = json.loads(self.read_body())
                meta["id"] = m.group(1)
                meta["created"] = int(time.time() * 1000)
                with open(os.path.join(sdir, "meta.json"), "w") as f:
                    json.dump(meta, f)
                return self.send_json({"ok": True})

            return self.send_err("not found", 404)
        except Exception as e:
            try:
                self.send_err(f"server error: {e}", 500)
            except Exception:
                pass

    # --- DELETE
    def do_DELETE(self):
        m = re.match(r"^/api/sessions/([A-Za-z0-9_.-]+)$", urlparse(self.path).path)
        if not m:
            return self.send_err("not found", 404)
        sdir = self.session_dir(m.group(1))
        if sdir and os.path.isdir(sdir):
            shutil.rmtree(sdir)
            return self.send_json({"ok": True})
        return self.send_err("нет такой сессии", 404)


def open_app_window(url):
    """Открыть плеер отдельным окном без браузерной обвязки (Chrome --app),
    иначе — обычной вкладкой браузера по умолчанию. Mac и Windows."""
    import subprocess
    if sys.platform == "darwin":
        for app in ("Google Chrome", "Chromium", "Microsoft Edge", "Yandex"):
            if os.path.isdir(f"/Applications/{app}.app"):
                try:
                    subprocess.Popen(["open", "-na", app, "--args",
                                      f"--app={url}", "--window-size=1500,950"])
                    return
                except Exception:
                    break
    elif sys.platform == "win32":
        pf = os.environ.get("ProgramFiles", r"C:\Program Files")
        pf86 = os.environ.get("ProgramFiles(x86)", r"C:\Program Files (x86)")
        local = os.environ.get("LocalAppData", "")
        candidates = [
            os.path.join(pf, "Google", "Chrome", "Application", "chrome.exe"),
            os.path.join(pf86, "Google", "Chrome", "Application", "chrome.exe"),
            os.path.join(local, "Google", "Chrome", "Application", "chrome.exe"),
            os.path.join(pf86, "Microsoft", "Edge", "Application", "msedge.exe"),
            os.path.join(pf, "Microsoft", "Edge", "Application", "msedge.exe"),
        ]
        for exe in candidates:
            if os.path.isfile(exe):
                try:
                    subprocess.Popen([exe, f"--app={url}", "--window-size=1500,950"])
                    return
                except Exception:
                    break
    webbrowser.open(url)


def free_port(start=8765):
    for p in range(start, start + 50):
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            try:
                s.bind(("127.0.0.1", p))
                return p
            except OSError:
                continue
    return start


def main():
    # на Windows консоль может быть не в UTF-8 — не падаем на русских сообщениях
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
        sys.stderr.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass
    ensure_dirs()
    env_port = os.environ.get("PORT")
    port = int(env_port) if env_port else free_port()
    srv = ThreadingHTTPServer(("127.0.0.1", port), Handler)
    url = f"http://127.0.0.1:{port}/"
    print(f"Плеер запущен: {url}")
    print("Не закрывайте это окно, пока работаете с плеером. Ctrl+C — выход.")
    if not env_port:  # при запуске из превью/IDE браузер не открываем
        threading.Timer(0.6, lambda: open_app_window(url)).start()
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        print("\nОстановлено.")


if __name__ == "__main__":
    main()
